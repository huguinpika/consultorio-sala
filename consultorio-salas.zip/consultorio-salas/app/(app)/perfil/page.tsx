import { requireCtx } from '@/lib/auth';
import { ActionForm } from '@/components/ui';
import PasswordForm from '@/components/PasswordForm';
import { updateProfileAction } from '@/app/actions/profile';

export default async function Profile() {
  const { profile } = await requireCtx();
  return (
    <div className="grid max-w-xl gap-8">
      <h1 className="page-title">Meu perfil</h1>
      <section className="card p-5">
        <h2 className="mb-4 font-semibold">Dados cadastrais</h2>
        <ActionForm action={updateProfileAction} success="Dados atualizados." className="grid gap-4">
          <div><label className="label" htmlFor="email">E-mail de acesso</label><input id="email" className="input" value={profile.email} disabled readOnly /></div>
          <div><label className="label" htmlFor="full_name">Nome completo</label><input id="full_name" name="full_name" className="input" defaultValue={profile.full_name} required /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="phone">Telefone</label><input id="phone" name="phone" className="input" defaultValue={profile.phone ?? ''} inputMode="tel" /></div>
            <div><label className="label" htmlFor="reg">Registro profissional (CRP)</label><input id="reg" name="registration_number" className="input" defaultValue={profile.registration_number ?? ''} /></div>
          </div>
        </ActionForm>
      </section>
      <section className="card p-5"><h2 className="mb-4 font-semibold">Alterar senha</h2><PasswordForm /></section>
    </div>
  );
}
