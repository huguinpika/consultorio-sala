import { requireAdmin } from '@/lib/auth';
import { Badge, Empty } from '@/components/badges';
import { ActionForm } from '@/components/ui';
import { resolveRequestAction } from '@/app/actions/booking';
import { fmtDate, fmtDateTime, fmtTime, ymd } from '@/lib/time';

export default async function Requests() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from('booking_requests')
    .select('*, requester:profiles!booking_requests_requested_by_fkey(full_name), booking:bookings(starts_at,ends_at,room:rooms(name)), desired_room:rooms!booking_requests_desired_room_id_fkey(name)')
    .order('created_at', { ascending: false }).limit(60);
  const pending = (data ?? []).filter((r: any) => r.status === 'pending');
  const done = (data ?? []).filter((r: any) => r.status !== 'pending').slice(0, 15);
  const when = (r: any) => r.booking ? `${fmtDate(ymd(r.booking.starts_at))} · ${fmtTime(r.booking.starts_at)}–${fmtTime(r.booking.ends_at)} · ${r.booking.room?.name}` : '—';

  return (
    <div className="grid gap-8">
      <h1 className="page-title">Solicitações</h1>
      <section className="grid gap-3">
        <h2 className="font-semibold">Aguardando resposta</h2>
        {!pending.length ? <div className="card"><Empty title="Nenhuma solicitação pendente." /></div> : pending.map((r: any) => (
          <div key={r.id} className="card grid gap-3 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-medium">{r.requester?.full_name} pede {r.type === 'cancel' ? 'cancelamento' : 'alteração'}</p>
              <span className="text-xs text-mute">{fmtDateTime(r.created_at)}</span>
            </div>
            <p className="text-sm"><span className="text-mute">Reserva atual: </span>{when(r)}</p>
            {r.type === 'change' && <p className="text-sm"><span className="text-mute">Novo horário: </span>{fmtDate(ymd(r.desired_starts_at))} · {fmtTime(r.desired_starts_at)}–{fmtTime(r.desired_ends_at)} · {r.desired_room?.name}</p>}
            {r.reason && <p className="text-sm"><span className="text-mute">Motivo: </span>{r.reason}</p>}
            <div className="grid gap-2 sm:grid-cols-2">
              <ActionForm action={resolveRequestAction.bind(null, r.id, true)} submit="Aprovar" success="Solicitação aprovada." className="flex gap-2"><input name="note" className="input" placeholder="Observação (opcional)" aria-label="Observação" /></ActionForm>
              <ActionForm action={resolveRequestAction.bind(null, r.id, false)} submit="Recusar" success="Solicitação recusada." submitClass="btn-danger" className="flex gap-2"><input name="note" className="input" placeholder="Explique o motivo" aria-label="Motivo da recusa" /></ActionForm>
            </div>
          </div>
        ))}
      </section>
      {!!done.length && (
        <section className="grid gap-3"><h2 className="font-semibold">Respondidas</h2>
          <ul className="card divide-y divide-line">{done.map((r: any) => (
            <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
              <span>{r.requester?.full_name} · {r.type === 'cancel' ? 'cancelamento' : 'alteração'} · {when(r)}</span>
              <Badge tone={r.status === 'approved' ? 'green' : 'red'}>{r.status === 'approved' ? 'Aprovada' : 'Recusada'}</Badge>
            </li>))}</ul></section>
      )}
    </div>
  );
}
