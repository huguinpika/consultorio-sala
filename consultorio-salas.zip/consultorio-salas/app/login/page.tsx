import Link from 'next/link';
import AuthFrame from '@/components/AuthFrame';
import { ActionForm } from '@/components/ui';
import { loginAction } from '@/app/actions/auth';

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const { erro } = await searchParams;
  const aviso = erro === 'inativo' ? 'Sua conta está suspensa. Fale com a administração.' : erro === 'link' ? 'Esse link expirou ou já foi usado. Peça um novo em “Esqueci minha senha”.' : null;
  return (
    <AuthFrame title="Entrar" subtitle="Use o e-mail e a senha fornecidos pela administração.">
      {aviso && <p className="mb-4 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">{aviso}</p>}
      <ActionForm action={loginAction} submit="Entrar" success="Bem-vindo(a)!" className="grid gap-4" submitClass="btn-primary w-full">
        <div><label className="label" htmlFor="email">E-mail</label><input id="email" name="email" type="email" autoComplete="email" required className="input" /></div>
        <div><label className="label" htmlFor="password">Senha</label><input id="password" name="password" type="password" autoComplete="current-password" required className="input" /></div>
      </ActionForm>
      <p className="mt-5 text-center text-sm"><Link href="/esqueci-senha" className="text-brand-700 underline-offset-2 hover:underline">Esqueci minha senha</Link></p>
    </AuthFrame>
  );
}
