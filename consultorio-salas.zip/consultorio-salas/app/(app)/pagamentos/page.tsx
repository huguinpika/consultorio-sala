import { requireCtx } from '@/lib/auth';
import { Empty, PayBadge } from '@/components/badges';
import { brl } from '@/lib/money';
import { METHOD } from '@/lib/labels';
import { fmtDate, fmtDateTime, fmtTime, ymd } from '@/lib/time';

export default async function MyPayments() {
  const { supabase } = await requireCtx();
  const { data: fin } = await supabase
    .from('booking_financials').select('booking_id,starts_at,ends_at,status,amount_cents,due_cents,paid_cents,balance_cents,payment_status,room_id')
    .order('starts_at', { ascending: false }).limit(300);
  const { data: pays } = await supabase.from('payments').select('id,kind,amount_cents,method,paid_at,notes,booking:bookings(starts_at,room:rooms(name))').order('paid_at', { ascending: false }).limit(200);
  const { data: roomRows } = await supabase.from('rooms').select('id,name');
  const roomName = new Map((roomRows ?? []).map((r: any) => [r.id, r.name]));
  const rows = (fin ?? []) as any[];
  const pending = rows.filter((r) => r.status === 'confirmed' && r.balance_cents > 0);
  const totalPending = pending.reduce((s, r) => s + r.balance_cents, 0);
  const totalPaid = rows.reduce((s, r) => s + r.paid_cents, 0);

  return (
    <div className="grid gap-8">
      <h1 className="page-title">Pagamentos</h1>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="card p-4"><p className="text-sm text-mute">Em aberto</p><p className="mt-1 text-2xl font-semibold text-amber-700">{brl(totalPending)}</p><p className="text-xs text-mute">{pending.length} reserva(s) com saldo</p></div>
        <div className="card p-4"><p className="text-sm text-mute">Já pago</p><p className="mt-1 text-2xl font-semibold text-emerald-700">{brl(totalPaid)}</p></div>
      </div>

      <section className="grid gap-3">
        <h2 className="font-semibold">Pendentes</h2>
        <div className="card overflow-x-auto">
          {!pending.length ? <Empty title="Nenhum pagamento pendente." /> : (
            <table className="w-full min-w-[520px]"><thead><tr className="border-b border-line"><th className="th">Reserva</th><th className="th">Valor</th><th className="th">Pago</th><th className="th">Saldo</th><th className="th">Situação</th></tr></thead>
              <tbody className="divide-y divide-line">{pending.map((r) => (
                <tr key={r.booking_id}><td className="td">{fmtDate(ymd(r.starts_at))} · {fmtTime(r.starts_at)}–{fmtTime(r.ends_at)}<br /><span className="text-xs text-mute">{roomName.get(r.room_id)}</span></td>
                  <td className="td">{brl(r.amount_cents)}</td><td className="td">{brl(r.paid_cents)}</td><td className="td font-medium">{brl(r.balance_cents)}</td><td className="td"><PayBadge status={r.payment_status} /></td></tr>))}</tbody></table>
          )}
        </div>
      </section>

      <section className="grid gap-3">
        <h2 className="font-semibold">Histórico de pagamentos</h2>
        <div className="card overflow-x-auto">
          {!pays?.length ? <Empty title="Nenhum pagamento registrado ainda." /> : (
            <table className="w-full min-w-[520px]"><thead><tr className="border-b border-line"><th className="th">Data</th><th className="th">Reserva</th><th className="th">Forma</th><th className="th text-right">Valor</th></tr></thead>
              <tbody className="divide-y divide-line">{pays.map((p: any) => (
                <tr key={p.id}><td className="td">{fmtDateTime(p.paid_at).slice(0, 10)}</td>
                  <td className="td">{p.booking ? `${fmtDate(ymd(p.booking.starts_at))} · ${p.booking.room?.name}` : '—'}</td>
                  <td className="td">{METHOD[p.method] ?? p.method}{p.kind === 'refund' ? ' (estorno)' : ''}</td>
                  <td className={`td text-right font-medium ${p.kind === 'refund' ? 'text-red-700' : ''}`}>{p.kind === 'refund' ? '−' : ''}{brl(p.amount_cents)}</td></tr>))}</tbody></table>
          )}
        </div>
      </section>
    </div>
  );
}
