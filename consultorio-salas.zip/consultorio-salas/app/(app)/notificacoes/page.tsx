import Link from 'next/link';
import { requireCtx } from '@/lib/auth';
import { Empty } from '@/components/badges';
import { ActionButton } from '@/components/ui';
import { markNotificationsReadAction } from '@/app/actions/profile';
import { fmtDateTime } from '@/lib/time';

export default async function Notifications() {
  const { supabase } = await requireCtx();
  const { data } = await supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(60);
  const unread = (data ?? []).filter((n: any) => !n.read_at).length;
  return (
    <div className="grid gap-5">
      <div className="flex items-center justify-between gap-3">
        <h1 className="page-title">Notificações</h1>
        {unread > 0 && <ActionButton action={markNotificationsReadAction} success="Tudo marcado como lido.">Marcar tudo como lido</ActionButton>}
      </div>
      <div className="card divide-y divide-line">
        {!data?.length ? <Empty title="Nenhuma notificação por enquanto." hint="Avisos de reservas, cancelamentos e pagamentos aparecem aqui." />
          : data.map((n: any) => {
            const body = (
              <div className="flex gap-3 px-4 py-3">
                <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${n.read_at ? 'bg-transparent' : 'bg-brand-600'}`} />
                <div className="min-w-0"><p className="text-sm font-medium">{n.title}</p>{n.body && <p className="text-sm text-mute">{n.body}</p>}<p className="mt-0.5 text-xs text-mute">{fmtDateTime(n.created_at)}</p></div>
              </div>
            );
            return n.link ? <Link key={n.id} href={n.link} className="block hover:bg-canvas">{body}</Link> : <div key={n.id}>{body}</div>;
          })}
      </div>
    </div>
  );
}
