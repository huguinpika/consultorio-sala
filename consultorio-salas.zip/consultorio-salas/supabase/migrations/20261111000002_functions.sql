-- =====================================================================
-- 0002 · FUNÇÕES, TRIGGERS E RPCs
-- Toda escrita em reservas/pagamentos/solicitações passa por RPCs
-- (security definer). Erros são códigos curtos (ex.: horario_indisponivel)
-- que o app traduz para mensagens em português.
-- =====================================================================

-- ---------- utilitários ------------------------------------------------
create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin' and is_active);
$$;

create function public.current_user_active() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and is_active);
$$;

create function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

create function public.fmt_local(p_ts timestamptz) returns text
language sql stable security definer set search_path = public as $$
  select to_char(p_ts at time zone (select timezone from public.settings), 'DD/MM/YYYY "às" HH24:MI');
$$;

create function public.notify(p_user uuid, p_title text, p_body text, p_link text default null) returns void
language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body, link) values (p_user, p_title, p_body, p_link);
$$;

create function public.notify_admins(p_title text, p_body text, p_link text default null) returns void
language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body, link)
  select id, p_title, p_body, p_link from public.profiles where role = 'admin' and is_active;
$$;

-- ---------- histórico de alterações (auditoria) ------------------------
create function public.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_log (table_name, record_id, action, actor_id, old_data, new_data)
  values (
    tg_table_name,
    case when tg_op = 'DELETE' then to_jsonb(old) ->> 'id' else to_jsonb(new) ->> 'id' end,
    tg_op, auth.uid(),
    case when tg_op <> 'INSERT' then to_jsonb(old) end,
    case when tg_op <> 'DELETE' then to_jsonb(new) end
  );
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['settings','profiles','rooms','opening_hours','blocks','room_rates',
                           'professional_rates','bookings','payments','booking_requests']
  loop
    execute format('create trigger %I after insert or update or delete on public.%I
                    for each row execute function public.audit_row()', 'audit_' || t, t);
  end loop;
  foreach t in array array['settings','profiles','rooms','bookings']
  loop
    execute format('create trigger %I before update on public.%I
                    for each row execute function public.touch_updated_at()', 'touch_' || t, t);
  end loop;
end $$;

-- ---------- novo usuário no Supabase Auth → cria perfil ----------------
-- O PRIMEIRO usuário criado vira administrador; os demais, profissionais.
-- (Desative o cadastro público no Supabase: Authentication > Sign In / Providers.)
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, role, full_name, email, phone)
  values (
    new.id,
    case when exists (select 1 from public.profiles where role = 'admin') then 'professional'::public.user_role else 'admin'::public.user_role end,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), split_part(new.email, '@', 1)),
    new.email,
    nullif(trim(new.raw_user_meta_data ->> 'phone'), '')
  );
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Profissional não pode promover a si mesmo nem se reativar; sempre deve existir 1 admin ativo.
create function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.role <> old.role or new.is_active <> old.is_active or lower(new.email) <> lower(old.email) then
      raise exception 'sem_permissao';
    end if;
  end if;
  if old.role = 'admin' and old.is_active and (new.role <> 'admin' or not new.is_active)
     and not exists (select 1 from public.profiles where role = 'admin' and is_active and id <> old.id) then
    raise exception 'ultimo_administrador';
  end if;
  return new;
end $$;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.profiles_guard();

-- ---------- tarifas ----------------------------------------------------
-- Prioridade: preço do profissional para a sala > preço do profissional (todas) > preço da sala.
create function public.current_rate_cents(p_room uuid, p_prof uuid, p_at timestamptz default now()) returns int
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select hourly_rate_cents from public.professional_rates
      where professional_id = p_prof and room_id = p_room and valid_from <= p_at order by valid_from desc limit 1),
    (select hourly_rate_cents from public.professional_rates
      where professional_id = p_prof and room_id is null and valid_from <= p_at order by valid_from desc limit 1),
    (select hourly_rate_cents from public.room_rates
      where room_id = p_room and valid_from <= p_at order by valid_from desc limit 1)
  );
$$;

-- ---------- validação central de janela de reserva ---------------------
create function public.validate_booking_window(p_room uuid, p_starts timestamptz, p_ends timestamptz) returns void
language plpgsql stable security definer set search_path = public as $$
declare
  s public.settings; v_ls timestamp; v_le timestamp; v_min int; v_start_min int; v_end_time time;
begin
  select * into s from public.settings;
  if not exists (select 1 from public.rooms where id = p_room and is_active) then raise exception 'sala_indisponivel'; end if;
  if p_ends <= p_starts then raise exception 'duracao_invalida'; end if;

  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;
  if v_min < s.min_duration_minutes or v_min > s.max_duration_minutes or v_min % s.slot_minutes <> 0 then
    raise exception 'duracao_invalida';
  end if;

  v_ls := p_starts at time zone s.timezone;
  v_le := p_ends   at time zone s.timezone;
  v_start_min := extract(hour from v_ls)::int * 60 + extract(minute from v_ls)::int;
  if v_start_min % s.slot_minutes <> 0 or extract(second from v_ls) <> 0 then raise exception 'horario_invalido'; end if;

  if v_le::date <> v_ls::date and not (v_le::date = v_ls::date + 1 and v_le::time = time '00:00') then
    raise exception 'fora_do_expediente';
  end if;
  v_end_time := case when v_le::date > v_ls::date then time '24:00' else v_le::time end;

  if not exists (
    select 1 from public.opening_hours oh
    where oh.room_id = p_room and oh.weekday = extract(dow from v_ls)::int
      and oh.opens_at <= v_ls::time and oh.closes_at >= v_end_time
  ) then raise exception 'fora_do_expediente'; end if;

  if exists (
    select 1 from public.blocks b
    where (b.room_id is null or b.room_id = p_room)
      and tstzrange(b.starts_at, b.ends_at) && tstzrange(p_starts, p_ends)
  ) then raise exception 'horario_bloqueado'; end if;
end $$;

-- Rede de segurança: mesmo escrita direta é validada (conflito = constraint de exclusão).
create function public.bookings_validate() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'confirmed' then
    perform public.validate_booking_window(new.room_id, new.starts_at, new.ends_at);
  end if;
  return new;
end $$;
create trigger bookings_validate_ins before insert on public.bookings
  for each row execute function public.bookings_validate();
create trigger bookings_validate_upd before update of room_id, starts_at, ends_at, status on public.bookings
  for each row when (new.status = 'confirmed' and (
    new.room_id is distinct from old.room_id or new.starts_at is distinct from old.starts_at
    or new.ends_at is distinct from old.ends_at or old.status is distinct from new.status))
  execute function public.bookings_validate();

-- Não permite criar bloqueio sobre reservas confirmadas (cancele/remaneje antes).
create function public.blocks_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from public.bookings b
             where b.status = 'confirmed' and (new.room_id is null or b.room_id = new.room_id)
               and tstzrange(b.starts_at, b.ends_at) && tstzrange(new.starts_at, new.ends_at)) then
    raise exception 'existem_reservas_no_periodo';
  end if;
  return new;
end $$;
create trigger blocks_guard before insert or update of room_id, starts_at, ends_at on public.blocks
  for each row execute function public.blocks_guard();

-- ---------- RPC: estimar valor ----------------------------------------
create function public.estimate_booking(p_room uuid, p_starts timestamptz, p_ends timestamptz, p_professional uuid default null)
returns table (hourly_rate_cents int, duration_minutes int, amount_cents int)
language plpgsql stable security definer set search_path = public as $$
declare v_prof uuid; v_rate int; v_min int;
begin
  if auth.uid() is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  v_prof := case when public.is_admin() then coalesce(p_professional, auth.uid()) else auth.uid() end;
  v_rate := public.current_rate_cents(p_room, v_prof);
  if v_rate is null then raise exception 'tarifa_nao_configurada'; end if;
  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;
  return query select v_rate, v_min, round(v_rate::numeric * v_min / 60)::int;
end $$;

-- ---------- RPC: disponibilidade (sem expor quem reservou) -------------
create function public.get_room_busy(p_room uuid, p_from timestamptz, p_to timestamptz)
returns table (kind text, starts_at timestamptz, ends_at timestamptz, is_mine boolean)
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  return query
    select 'booking'::text, b.starts_at, b.ends_at, (b.professional_id = auth.uid())
    from public.bookings b
    where b.room_id = p_room and b.status = 'confirmed' and tstzrange(b.starts_at, b.ends_at) && tstzrange(p_from, p_to)
    union all
    select 'block'::text, k.starts_at, k.ends_at, false
    from public.blocks k
    where (k.room_id is null or k.room_id = p_room) and tstzrange(k.starts_at, k.ends_at) && tstzrange(p_from, p_to)
    order by 2;
end $$;

-- ---------- RPC: criar reserva -----------------------------------------
create function public.create_booking(
  p_room uuid, p_starts timestamptz, p_ends timestamptz, p_professional uuid default null, p_notes text default null
) returns public.bookings
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid(); v_admin boolean; v_prof uuid; v_rate int; v_min int; v_row public.bookings; v_room text;
begin
  if v_uid is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  v_admin := public.is_admin();
  if not v_admin and p_professional is not null and p_professional <> v_uid then raise exception 'sem_permissao'; end if;
  v_prof := case when v_admin then coalesce(p_professional, v_uid) else v_uid end;
  if not exists (select 1 from public.profiles where id = v_prof and is_active) then raise exception 'profissional_inativo'; end if;
  if p_starts <= now() then raise exception 'horario_no_passado'; end if;

  perform public.validate_booking_window(p_room, p_starts, p_ends);
  v_rate := public.current_rate_cents(p_room, v_prof);
  if v_rate is null then raise exception 'tarifa_nao_configurada'; end if;
  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;

  insert into public.bookings (room_id, professional_id, starts_at, ends_at, hourly_rate_cents, amount_cents, notes, created_by, updated_by)
  values (p_room, v_prof, p_starts, p_ends, v_rate, round(v_rate::numeric * v_min / 60)::int, nullif(trim(p_notes), ''), v_uid, v_uid)
  returning * into v_row;

  select name into v_room from public.rooms where id = p_room;
  if v_prof <> v_uid then
    perform public.notify(v_prof, 'Nova reserva em seu nome', v_room || ' · ' || public.fmt_local(p_starts), '/reservas');
  end if;
  if not v_admin then
    perform public.notify_admins('Nova reserva', (select full_name from public.profiles where id = v_prof) || ' · ' || v_room || ' · ' || public.fmt_local(p_starts), '/admin/reservas');
  end if;
  return v_row;
exception when exclusion_violation then
  raise exception 'horario_indisponivel';
end $$;

-- ---------- internas: cancelar e remanejar -----------------------------
create function public._cancel_booking(p_booking uuid, p_reason text, p_actor uuid) returns public.bookings
language plpgsql security definer set search_path = public as $$
declare v_b public.bookings; v_room text;
begin
  update public.bookings set status = 'cancelled', cancelled_at = now(), cancelled_by = p_actor,
         cancel_reason = nullif(trim(p_reason), ''), updated_by = p_actor
   where id = p_booking returning * into v_b;
  -- Pagamentos existentes NÃO são alterados; o financeiro passa a mostrar 'a_estornar' se houver valor pago.
  update public.booking_requests set status = 'approved', resolved_by = p_actor, resolved_at = now(),
         resolution_note = 'Reserva cancelada'
   where booking_id = p_booking and status = 'pending';
  select name into v_room from public.rooms where id = v_b.room_id;
  if p_actor <> v_b.professional_id then
    perform public.notify(v_b.professional_id, 'Reserva cancelada', v_room || ' · ' || public.fmt_local(v_b.starts_at), '/reservas');
  else
    perform public.notify_admins('Reserva cancelada pelo profissional', v_room || ' · ' || public.fmt_local(v_b.starts_at), '/admin/reservas');
  end if;
  return v_b;
end $$;

create function public._reschedule_booking(p_booking uuid, p_room uuid, p_starts timestamptz, p_ends timestamptz, p_actor uuid)
returns public.bookings
language plpgsql security definer set search_path = public as $$
declare v_b public.bookings; v_rate int; v_min int; v_room text;
begin
  select * into v_b from public.bookings where id = p_booking for update;
  if not found then raise exception 'reserva_nao_encontrada'; end if;
  if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
  if p_starts <= now() then raise exception 'horario_no_passado'; end if;
  perform public.validate_booking_window(p_room, p_starts, p_ends);

  v_rate := case when p_room = v_b.room_id then v_b.hourly_rate_cents else public.current_rate_cents(p_room, v_b.professional_id) end;
  if v_rate is null then raise exception 'tarifa_nao_configurada'; end if;
  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;

  update public.bookings set room_id = p_room, starts_at = p_starts, ends_at = p_ends,
         hourly_rate_cents = v_rate, amount_cents = round(v_rate::numeric * v_min / 60)::int, updated_by = p_actor
   where id = p_booking returning * into v_b;

  select name into v_room from public.rooms where id = p_room;
  if p_actor <> v_b.professional_id then
    perform public.notify(v_b.professional_id, 'Reserva alterada', v_room || ' · ' || public.fmt_local(p_starts), '/reservas');
  end if;
  return v_b;
exception when exclusion_violation then
  raise exception 'horario_indisponivel';
end $$;

-- ---------- RPC: cancelar (regra das 24h, configurável) ---------------
create function public.cancel_booking(p_booking uuid, p_reason text default null) returns public.bookings
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_b public.bookings; v_notice int;
begin
  if v_uid is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  select * into v_b from public.bookings where id = p_booking for update;
  if not found then raise exception 'reserva_nao_encontrada'; end if;
  if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
  if not public.is_admin() then
    if v_b.professional_id <> v_uid then raise exception 'sem_permissao'; end if;
    select cancellation_notice_hours into v_notice from public.settings;
    if v_b.starts_at - make_interval(hours => v_notice) < now() then
      raise exception 'cancelamento_fora_do_prazo';   -- o app oferece "solicitar cancelamento"
    end if;
  end if;
  return public._cancel_booking(p_booking, p_reason, v_uid);
end $$;

-- ---------- RPC: remanejar (somente administradora) --------------------
create function public.reschedule_booking(p_booking uuid, p_room uuid, p_starts timestamptz, p_ends timestamptz)
returns public.bookings
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'sem_permissao'; end if;
  return public._reschedule_booking(p_booking, p_room, p_starts, p_ends, auth.uid());
end $$;

-- ---------- RPC: profissional solicita cancelamento/alteração ----------
create function public.request_booking_change(
  p_booking uuid, p_type public.request_type, p_reason text default null,
  p_room uuid default null, p_starts timestamptz default null, p_ends timestamptz default null
) returns public.booking_requests
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_b public.bookings; v_req public.booking_requests; v_name text;
begin
  if v_uid is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  select * into v_b from public.bookings where id = p_booking;
  if not found or v_b.professional_id <> v_uid then raise exception 'sem_permissao'; end if;
  if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
  if v_b.starts_at <= now() then raise exception 'horario_no_passado'; end if;
  if p_type = 'change' then
    if p_starts is null or p_ends is null then raise exception 'duracao_invalida'; end if;
    perform public.validate_booking_window(coalesce(p_room, v_b.room_id), p_starts, p_ends);
  end if;
  begin
    insert into public.booking_requests (booking_id, requested_by, type, reason, desired_room_id, desired_starts_at, desired_ends_at)
    values (p_booking, v_uid, p_type, nullif(trim(p_reason), ''),
            case when p_type = 'change' then coalesce(p_room, v_b.room_id) end, p_starts, p_ends)
    returning * into v_req;
  exception when unique_violation then raise exception 'solicitacao_pendente';
  end;
  select full_name into v_name from public.profiles where id = v_uid;
  perform public.notify_admins(
    case p_type when 'cancel' then 'Pedido de cancelamento' else 'Pedido de alteração' end,
    v_name || ' · reserva de ' || public.fmt_local(v_b.starts_at), '/admin/solicitacoes');
  return v_req;
end $$;

-- ---------- RPC: administradora resolve solicitação --------------------
create function public.resolve_booking_request(p_request uuid, p_approve boolean, p_note text default null)
returns public.booking_requests
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_req public.booking_requests; v_b public.bookings;
begin
  if not public.is_admin() then raise exception 'sem_permissao'; end if;
  select * into v_req from public.booking_requests where id = p_request for update;
  if not found then raise exception 'solicitacao_nao_encontrada'; end if;
  if v_req.status <> 'pending' then raise exception 'solicitacao_ja_resolvida'; end if;
  select * into v_b from public.bookings where id = v_req.booking_id;

  if p_approve then
    if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
    if v_req.type = 'cancel' then
      perform public._cancel_booking(v_req.booking_id, coalesce(p_note, v_req.reason, 'Cancelamento solicitado pelo profissional'), v_uid);
    else
      perform public._reschedule_booking(v_req.booking_id, coalesce(v_req.desired_room_id, v_b.room_id),
                                          v_req.desired_starts_at, v_req.desired_ends_at, v_uid);
    end if;
  end if;

  update public.booking_requests
     set status = case when p_approve then 'approved'::public.request_status else 'rejected'::public.request_status end,
         resolved_by = v_uid, resolved_at = now(), resolution_note = nullif(trim(p_note), '')
   where id = p_request returning * into v_req;

  perform public.notify(v_req.requested_by,
    case when p_approve then 'Solicitação aprovada' else 'Solicitação recusada' end,
    coalesce(v_req.resolution_note, 'Reserva de ' || public.fmt_local(v_b.starts_at)), '/reservas');
  return v_req;
end $$;

-- ---------- RPC: registrar pagamento/estorno (somente administradora) --
create function public.record_payment(
  p_booking uuid, p_amount_cents int, p_kind public.payment_kind default 'payment',
  p_method public.payment_method default 'pix', p_paid_at timestamptz default now(), p_notes text default null
) returns public.payments
language plpgsql security definer set search_path = public as $$
declare v_b public.bookings; v_net int; v_row public.payments;
begin
  if not public.is_admin() then raise exception 'sem_permissao'; end if;
  if p_amount_cents is null or p_amount_cents <= 0 then raise exception 'valor_invalido'; end if;
  select * into v_b from public.bookings where id = p_booking for update;   -- serializa pagamentos da mesma reserva
  if not found then raise exception 'reserva_nao_encontrada'; end if;
  select coalesce(sum(case kind when 'payment' then amount_cents else -amount_cents end), 0) into v_net
    from public.payments where booking_id = p_booking;

  if p_kind = 'payment' then
    if v_b.status <> 'confirmed' then raise exception 'reserva_cancelada_sem_pagamento'; end if;
    if v_net + p_amount_cents > v_b.amount_cents then raise exception 'pagamento_excede_valor'; end if;
  elsif p_amount_cents > v_net then
    raise exception 'estorno_excede_pago';
  end if;

  insert into public.payments (booking_id, kind, amount_cents, method, paid_at, notes, created_by)
  values (p_booking, p_kind, p_amount_cents, p_method, coalesce(p_paid_at, now()), nullif(trim(p_notes), ''), auth.uid())
  returning * into v_row;

  perform public.notify(v_b.professional_id,
    case p_kind when 'payment' then 'Pagamento registrado' else 'Estorno registrado' end,
    'Reserva de ' || public.fmt_local(v_b.starts_at) || ' · R$ ' || replace(to_char(p_amount_cents / 100.0, 'FM999990.00'), '.', ','), '/pagamentos');
  return v_row;
end $$;

-- ---------- RPC: marcar notificações como lidas -------------------------
create function public.mark_notifications_read(p_ids uuid[] default null) returns void
language sql security definer set search_path = public as $$
  update public.notifications set read_at = now()
   where user_id = auth.uid() and read_at is null and (p_ids is null or id = any (p_ids));
$$;
