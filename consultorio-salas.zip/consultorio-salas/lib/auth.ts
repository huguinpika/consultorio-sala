import { cache } from 'react';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export type Profile = {
  id: string; role: 'admin' | 'professional'; full_name: string; email: string;
  phone: string | null; registration_number: string | null; is_active: boolean;
};

export const getCtx = cache(async () => {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single();
  return { supabase, user, profile: data as Profile | null };
});

export async function requireCtx() {
  const c = await getCtx();
  if (!c) redirect('/login');
  if (!c.profile || !c.profile.is_active) redirect('/sair?erro=inativo');
  return { supabase: c.supabase, user: c.user, profile: c.profile as Profile };
}

export async function requireAdmin() {
  const c = await requireCtx();
  if (c.profile.role !== 'admin') redirect('/agenda');
  return c;
}
