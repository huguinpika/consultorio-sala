import { requireAdmin } from '@/lib/auth';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin(); // bloqueia profissionais em qualquer página /admin
  return children;
}
