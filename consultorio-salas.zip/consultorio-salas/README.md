# Agenda de Salas — sistema de locação e agendamento para consultório

Sistema web para administrar **duas salas** de um consultório: a administradora reserva em nome dos profissionais, os profissionais reservam sozinhos, e o valor é calculado **por hora utilizada**. Funciona no computador, tablet e celular.

Tecnologias: Next.js 15, TypeScript, Tailwind CSS, Supabase (PostgreSQL + Auth) e Vercel. Para um consultório pequeno, os planos gratuitos costumam bastar.

> **Antes de usar no dia a dia:** siga todos os passos abaixo e faça o teste da seção 9. Este código foi escrito, mas ainda não foi executado de ponta a ponta: se algo falhar na primeira instalação, veja a seção 11.

---

## 1. O que você vai precisar (tudo gratuito para começar)

1. Uma conta no **Supabase**: https://supabase.com
2. Uma conta no **GitHub**: https://github.com (usada para enviar o projeto à Vercel)
3. Uma conta na **Vercel**: https://vercel.com (entre com a conta do GitHub)
4. Só para testar no seu computador: **Node.js 20 ou mais novo** (https://nodejs.org, versão “LTS”)

## 2. Criar o banco de dados no Supabase

1. No Supabase, clique em **New project**. Escolha um nome (ex.: `consultorio`), crie uma **senha do banco** (guarde-a) e escolha a região **South America (São Paulo)**.
2. Aguarde alguns minutos até o projeto ficar pronto.
3. No menu da esquerda, abra **SQL Editor** → **New query**.
4. Abra o arquivo `supabase/setup_completo.sql` deste projeto, copie **todo** o conteúdo, cole no editor e clique em **Run**. Deve aparecer “Success”.
   - Rode **uma única vez**. Se precisar recomeçar do zero, crie um projeto novo.

## 3. Configurar o acesso (Authentication)

No Supabase, menu **Authentication**:

1. **Sign In / Providers** (ou *Providers* > *Email*): deixe *Email* ligado e **desligue “Allow new users to sign up”** (cadastro público). Só a administradora cria contas.
2. **URL Configuration**:
   - *Site URL*: o endereço do sistema. Por enquanto `http://localhost:3000`; depois da publicação, troque pelo endereço da Vercel.
   - *Redirect URLs*: adicione `http://localhost:3000/**` e, depois, `https://SEU-ENDERECO.vercel.app/**`.
3. **Emails**: o Supabase gratuito envia **poucos e-mails por hora**. Para uso real, configure um SMTP próprio em *Project Settings > Authentication > SMTP Settings* (serviços como Resend ou Brevo têm plano gratuito).

## 4. Pegar as chaves do projeto

Em **Project Settings > API**, anote:

- **Project URL**
- **anon public key**
- **service_role key** (SECRETA: nunca publique nem envie a ninguém)

## 5. Criar a conta da administradora

1. No Supabase, **Authentication > Users > Add user > Create new user**.
2. Informe o e-mail e uma senha, e marque **Auto Confirm User**.
3. **A primeira conta criada vira automaticamente administradora.** Por isso, crie esta antes de qualquer outra.

## 6. Rodar no seu computador (opcional, para testar)

1. Descompacte o projeto, abra um terminal na pasta e rode: `npm install`
2. Copie `.env.example` para `.env.local` e preencha com as chaves da seção 4.
3. Rode `npm run dev` e abra http://localhost:3000
4. Entre com a conta da administradora.

## 7. Publicar na Vercel

1. Crie um repositório **privado** no GitHub e envie esta pasta (no site do GitHub: *Add file > Upload files*; **não envie** `.env.local` nem `node_modules`).
2. Na Vercel: **Add New > Project**, escolha o repositório e clique em **Import**.
3. Em **Environment Variables**, cadastre as 4 variáveis do `.env.example`:
   `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` e `NEXT_PUBLIC_SITE_URL` (o endereço final, ex.: `https://consultorio.vercel.app`).
4. Clique em **Deploy**. Ao terminar, copie o endereço e volte ao Supabase (seção 3, passo 2) para atualizar *Site URL* e *Redirect URLs*.
5. Se alterar variáveis depois, use **Deployments > Redeploy**.

## 8. Primeira configuração (dentro do sistema)

Entre como administradora e vá em **Salas**:

1. Defina o **valor da hora** de cada sala. *Sem valor, o sistema recusa reservas.*
2. Confira os **horários de funcionamento** (o padrão é segunda a sexta, 8h–20h).
3. Em **Regras de reserva**, escolha horas cheias ou 30 em 30 minutos, a duração mínima/máxima e o prazo de cancelamento (padrão: 24 horas).
4. Em **Profissionais**, cadastre cada pessoa (nome, e-mail e senha provisória) e passe os dados de acesso.

## 9. Teste de aceitação (faça antes de começar a usar)

1. Reserve um horário como administradora em nome de um profissional.
2. Em outro navegador (ou janela anônima), entre como esse profissional: ele deve ver a reserva e o valor.
3. Entre como um segundo profissional e tente reservar o **mesmo horário na mesma sala**: o sistema deve impedir. Na **outra sala**, deve permitir.
4. Cancele uma reserva com mais de 24h de antecedência (deve funcionar) e tente com menos de 24h (deve oferecer “Solicitar cancelamento”).
5. Registre um pagamento em **Financeiro** e confira o status “Pago”/“Parcialmente pago”.
6. Opcional, para quem tem familiaridade: rode `supabase/tests/regras_de_reserva.sql` em um projeto Supabase **de teste**.

## 10. Como o sistema protege os dados

- Cada tabela tem **RLS** (segurança por linha): o profissional só enxerga as **próprias** reservas, valores e pagamentos. Ele vê apenas “Ocupado” nos horários dos outros.
- Reservas, pagamentos e solicitações **não aceitam escrita direta**: tudo passa por funções do banco que validam regras (expediente, bloqueios, passado, duração e prazo de cancelamento).
- **Dois cliques ao mesmo tempo** não geram conflito: o próprio PostgreSQL impede reservas sobrepostas na mesma sala.
- Pagamentos **nunca são apagados**. Cancelar uma reserva zera o valor devido, mas mantém o histórico; se já havia valor pago, aparece “A estornar”.
- Todo cadastro, reserva, cancelamento e pagamento fica no **Histórico** (quem fez, quando, o que mudou).
- A chave `service_role` é usada só no servidor (criar contas, suspender acessos).
- **LGPD:** o sistema não guarda prontuários nem dados de pacientes. O campo “Observação” da reserva é livre: oriente os profissionais a **não** colocar nomes de pacientes.
- Horários seguem o fuso de Brasília.

## 11. Problemas comuns

| Sintoma | O que fazer |
|---|---|
| Erro de “Invalid API key” ou página em branco | Confira as variáveis (seção 4) e reinicie/redeploy. |
| “O valor da hora desta sala ainda não foi definido” | Defina em **Salas > Valor da hora**. |
| Link de redefinir senha não funciona | Confira *Site URL* e *Redirect URLs* (seção 3). |
| E-mails não chegam | Limite do plano gratuito: configure SMTP próprio. |
| Erro no build da Vercel | Abra *Deployments > (último) > Build Logs*, copie a mensagem e envie para quem mantém o projeto. |

## 12. Estrutura do projeto

- `supabase/` — banco: `migrations/` (schema, funções, RLS), `seed.sql`, `setup_completo.sql` (tudo junto) e `tests/`.
- `app/` — páginas e ações do servidor (`actions/`). `(app)/admin/` é a área da administradora.
- `components/` — interface (calendário, diálogos, menu).
- `lib/` — regras de apoio (datas em Brasília, dinheiro, mensagens de erro, ocupação) e conexão com o Supabase.

## 13. Próximas versões (já previstas na arquitetura)

A tabela `notification_outbox` está pronta para enviar avisos por **e-mail e WhatsApp** no futuro, sem mudar o restante do sistema. Hoje as notificações aparecem dentro da plataforma (sino/“Notificações”).
