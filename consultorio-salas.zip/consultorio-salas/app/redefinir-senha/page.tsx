import AuthFrame from '@/components/AuthFrame';
import PasswordForm from '@/components/PasswordForm';

export default function ResetPage() {
  return (
    <AuthFrame title="Nova senha" subtitle="Escolha uma senha com pelo menos 8 caracteres.">
      <PasswordForm redirectTo="/" />
    </AuthFrame>
  );
}
