'use server';
import { revalidatePath } from 'next/cache';
import { requireCtx } from '@/lib/auth';
import { fail, failText, type Res } from '@/lib/errors';

export async function updateProfileAction(fd: FormData): Promise<Res> {
  const { supabase, user } = await requireCtx();
  const name = String(fd.get('full_name') || '').trim();
  if (!name) return failText('Informe seu nome.');
  const { error } = await supabase.from('profiles').update({
    full_name: name,
    phone: String(fd.get('phone') || '').trim() || null,
    registration_number: String(fd.get('registration_number') || '').trim() || null,
  }).eq('id', user.id);
  if (error) return fail(error.message);
  revalidatePath('/', 'layout');
  return { ok: true };
}

export async function markNotificationsReadAction(): Promise<Res> {
  const { supabase } = await requireCtx();
  const { error } = await supabase.rpc('mark_notifications_read', { p_ids: null });
  if (error) return fail(error.message);
  revalidatePath('/', 'layout');
  return { ok: true };
}
