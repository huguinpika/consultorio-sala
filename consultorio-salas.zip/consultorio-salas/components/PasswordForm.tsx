'use client';
import { useRouter } from 'next/navigation';
import { ActionForm } from '@/components/ui';
import { updatePasswordAction } from '@/app/actions/auth';

export default function PasswordForm({ redirectTo }: { redirectTo?: string }) {
  const router = useRouter();
  return (
    <ActionForm action={updatePasswordAction} submit="Salvar nova senha" success="Senha alterada." className="grid gap-4" submitClass="btn-primary w-full" reset
      onDone={() => redirectTo && router.push(redirectTo)}>
      <div><label className="label" htmlFor="pw">Nova senha</label><input id="pw" name="password" type="password" minLength={8} autoComplete="new-password" required className="input" /></div>
      <div><label className="label" htmlFor="pw2">Repita a senha</label><input id="pw2" name="confirm" type="password" minLength={8} autoComplete="new-password" required className="input" /></div>
    </ActionForm>
  );
}
