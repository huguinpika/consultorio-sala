import Link from 'next/link';
import { requireAdmin } from '@/lib/auth';
import { Badge, Empty, PayBadge } from '@/components/badges';
import { brl } from '@/lib/money';
import { occupancy, pct } from '@/lib/occupancy';
import { addDays, addMonths, fmtDate, fmtDateLong, fmtTime, monthLabel, monthStart, todayYmd, toISO, ymd } from '@/lib/time';

export default async function Dashboard() {
  const { supabase } = await requireAdmin();
  const today = todayYmd(), mStart = monthStart(today), mEnd = addMonths(mStart, 1);
  const nowISO = new Date().toISOString();
  const [{ data: rooms }, { data: hours }, { data: month }, { data: upcoming }, { data: openBal }, { count: pros }, { count: reqs }, { data: monthPays }] = await Promise.all([
    supabase.from('rooms').select('id,name,color,is_active').order('sort_order'),
    supabase.from('opening_hours').select('*'),
    supabase.from('bookings').select('id,room_id,starts_at,ends_at,status,amount_cents,cancelled_at').gte('starts_at', toISO(mStart, 0)).lt('starts_at', toISO(mEnd, 0)),
    supabase.from('bookings').select('id,room_id,starts_at,ends_at,amount_cents,room:rooms(name,color),professional:profiles!bookings_professional_id_fkey(full_name)').eq('status', 'confirmed').gte('ends_at', nowISO).order('starts_at').limit(6),
    supabase.from('booking_financials').select('balance_cents').eq('status', 'confirmed').gt('balance_cents', 0),
    supabase.from('profiles').select('id', { count: 'exact', head: true }).eq('role', 'professional').eq('is_active', true),
    supabase.from('booking_requests').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    supabase.from('payments').select('amount_cents,kind').gte('paid_at', toISO(mStart, 0)).lt('paid_at', toISO(mEnd, 0)),
  ]);
  const activeRooms = (rooms ?? []).filter((r: any) => r.is_active);
  const confirmed = (month ?? []).filter((b: any) => b.status === 'confirmed');
  const todayList = confirmed.filter((b: any) => ymd(b.starts_at) === today);
  const billed = confirmed.reduce((s: number, b: any) => s + b.amount_cents, 0);
  const received = (monthPays ?? []).reduce((s: number, p: any) => s + (p.kind === 'payment' ? p.amount_cents : -p.amount_cents), 0);
  const pending = (openBal ?? []).reduce((s: number, r: any) => s + r.balance_cents, 0);
  const cancelled = (month ?? []).filter((b: any) => b.status === 'cancelled').length;
  const occ = occupancy(hours ?? [], month ?? [], activeRooms.map((r: any) => r.id), mStart, today < mEnd ? addDays(today, 1) : mEnd);
  const nowMs = Date.now();
  const busyNow = (roomId: string) => confirmed.find((b: any) => b.room_id === roomId && new Date(b.starts_at).getTime() <= nowMs && new Date(b.ends_at).getTime() > nowMs);

  const Stat = ({ label, value, hint }: { label: string; value: string; hint?: string }) => (
    <div className="card p-4"><p className="text-sm text-mute">{label}</p><p className="mt-1 text-2xl font-semibold tracking-tight">{value}</p>{hint && <p className="mt-0.5 text-xs text-mute">{hint}</p>}</div>
  );

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div><h1 className="page-title">Painel</h1><p className="text-sm capitalize text-mute">{fmtDateLong(today)}</p></div>
        {!!reqs && <Link href="/admin/solicitacoes" className="btn-primary">{reqs} solicitação(ões) aguardando resposta</Link>}
      </div>

      <section className="grid gap-3 md:grid-cols-2">
        {activeRooms.map((r: any) => {
          const b: any = busyNow(r.id);
          return (
            <Link key={r.id} href={`/agenda?view=dia&date=${today}`} className="card flex items-center gap-4 p-4 transition hover:border-ink/20">
              <span className="h-12 w-1.5 rounded-full" style={{ background: r.color }} />
              <div className="min-w-0 flex-1"><p className="font-semibold">{r.name}</p><p className="text-sm text-mute">{b ? `Ocupada até ${fmtTime(b.ends_at)}` : 'Disponível agora'}</p></div>
              <Badge tone={b ? 'amber' : 'green'}>{b ? 'Ocupada' : 'Livre'}</Badge>
            </Link>
          );
        })}
      </section>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Reservas hoje" value={String(todayList.length)} />
        <Stat label="Profissionais ativos" value={String(pros ?? 0)} />
        <Stat label={`Faturamento de ${monthLabel(today).split(' ')[0]}`} value={brl(billed)} hint={`Recebido no mês: ${brl(received)}`} />
        <Stat label="Valores pendentes" value={brl(pending)} hint="Saldo de reservas confirmadas" />
        <Stat label="Taxa de ocupação do mês" value={pct(occ.rate)} hint="Até hoje, sobre o horário de funcionamento" />
        <Stat label="Reservas canceladas" value={String(cancelled)} hint="Neste mês" />
      </section>

      <section className="grid gap-3">
        <div className="flex items-center justify-between"><h2 className="font-semibold">Próximas reservas</h2><Link href="/admin/reservas" className="text-sm text-brand-700 hover:underline">Ver todas</Link></div>
        <div className="card divide-y divide-line">
          {!upcoming?.length ? <Empty title="Nenhuma reserva futura." hint="Use a agenda para reservar em nome de um profissional." /> : upcoming.map((b: any) => (
            <div key={b.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-4 py-3 text-sm">
              <span className="h-8 w-1 rounded-full" style={{ background: b.room?.color }} />
              <span className="min-w-40 font-medium">{fmtDate(ymd(b.starts_at))} · {fmtTime(b.starts_at)}–{fmtTime(b.ends_at)}</span>
              <span className="text-mute">{b.room?.name}</span>
              <span className="mr-auto">{b.professional?.full_name}</span>
              <span className="font-medium">{brl(b.amount_cents)}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
void PayBadge;
