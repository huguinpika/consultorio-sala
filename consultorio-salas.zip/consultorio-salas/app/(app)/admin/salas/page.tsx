import { requireAdmin } from '@/lib/auth';
import { Empty } from '@/components/badges';
import { ActionButton, ActionForm } from '@/components/ui';
import { addBlockAction, addHoursAction, addRoomRateAction, deleteBlockAction, deleteHoursAction, updateRoomAction, updateSettingsAction } from '@/app/actions/admin';
import { brl } from '@/lib/money';
import { occupancy, pct } from '@/lib/occupancy';
import { addDays, fmtDateTime, hhmm, todayYmd, toISO, WEEKDAYS_SHORT } from '@/lib/time';

const ORDER = [1, 2, 3, 4, 5, 6, 0];
const tm = (t: string) => { const [h, m] = t.split(':').map(Number); return hhmm(h * 60 + m).replace('24:00', '24:00'); };

export default async function Rooms() {
  const { supabase } = await requireAdmin();
  const today = todayYmd(), from = addDays(today, -30);
  const [{ data: rooms }, { data: hours }, { data: rates }, { data: blocks }, { data: settings }, { data: bk }] = await Promise.all([
    supabase.from('rooms').select('*').order('sort_order'),
    supabase.from('opening_hours').select('*').order('opens_at'),
    supabase.from('room_rates').select('*').order('valid_from', { ascending: false }),
    supabase.from('blocks').select('*, room:rooms(name)').gte('ends_at', new Date().toISOString()).order('starts_at'),
    supabase.from('settings').select('*').single(),
    supabase.from('bookings').select('room_id,starts_at,ends_at,status').gte('starts_at', toISO(from, 0)).lt('starts_at', toISO(today, 1440)),
  ]);

  return (
    <div className="grid gap-8">
      <h1 className="page-title">Salas e configurações</h1>

      {(rooms ?? []).map((r: any) => {
        const rh = (hours ?? []).filter((h: any) => h.room_id === r.id);
        const rr = (rates ?? []).filter((x: any) => x.room_id === r.id);
        const current = rr.find((x: any) => new Date(x.valid_from) <= new Date());
        const occ = occupancy(hours ?? [], bk ?? [], [r.id], from, addDays(today, 1));
        return (
          <section key={r.id} className="card grid gap-6 p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="flex items-center gap-2 text-lg font-semibold"><span className="h-3 w-3 rounded-sm" style={{ background: r.color }} />{r.name}</h2>
              <p className="text-sm text-mute">Ocupação nos últimos 30 dias: <span className="font-semibold text-ink">{pct(occ.rate)}</span></p>
            </div>

            <ActionForm action={updateRoomAction.bind(null, r.id)} success="Sala atualizada." className="grid items-end gap-3 sm:grid-cols-[1fr_1fr_auto_auto_auto]">
              <div><label className="label" htmlFor={`n-${r.id}`}>Nome</label><input id={`n-${r.id}`} name="name" required defaultValue={r.name} className="input" /></div>
              <div><label className="label" htmlFor={`d-${r.id}`}>Descrição</label><input id={`d-${r.id}`} name="description" defaultValue={r.description ?? ''} className="input" /></div>
              <div><label className="label" htmlFor={`c-${r.id}`}>Cor</label><input id={`c-${r.id}`} name="color" type="color" defaultValue={r.color} className="h-[38px] w-14 rounded-lg border border-line bg-white p-1" /></div>
              <label className="flex items-center gap-2 pb-2 text-sm"><input type="checkbox" name="is_active" defaultChecked={r.is_active} /> Ativa</label>
            </ActionForm>

            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="mb-1 font-medium">Valor da hora</h3>
                <p className="mb-3 text-sm text-mute">{current ? <>Atual: <span className="font-semibold text-ink">{brl(current.hourly_rate_cents)}</span></> : 'Ainda não definido: sem valor, ninguém consegue reservar.'}</p>
                <ActionForm action={addRoomRateAction.bind(null, r.id)} success="Novo valor salvo." reset submit="Definir valor" className="mb-3 flex items-end gap-2">
                  <div className="flex-1"><label className="label" htmlFor={`p-${r.id}`}>Novo valor (R$)</label><input id={`p-${r.id}`} name="price" inputMode="decimal" required placeholder="50,00" className="input" /></div>
                </ActionForm>
                {!!rr.length && <ul className="divide-y divide-line text-sm">{rr.slice(0, 5).map((x: any) => <li key={x.id} className="flex justify-between py-1.5"><span className="text-mute">desde {fmtDateTime(x.valid_from).slice(0, 10)}</span><span>{brl(x.hourly_rate_cents)}/h</span></li>)}</ul>}
              </div>

              <div>
                <h3 className="mb-3 font-medium">Horário de funcionamento</h3>
                {!rh.length ? <p className="mb-3 text-sm text-amber-800">Nenhum horário cadastrado: a sala não aceita reservas.</p> : (
                  <ul className="mb-3 divide-y divide-line text-sm">{ORDER.flatMap((d) => rh.filter((h: any) => h.weekday === d).map((h: any) => (
                    <li key={h.id} className="flex items-center justify-between py-1.5"><span><span className="inline-block w-10 font-medium">{WEEKDAYS_SHORT[d]}</span>{tm(h.opens_at)} às {tm(h.closes_at)}</span>
                      <ActionButton action={deleteHoursAction.bind(null, h.id)} success="Horário removido." confirm="Remover este horário?" className="btn-ghost btn-sm">Remover</ActionButton></li>)))}</ul>
                )}
                <ActionForm action={addHoursAction.bind(null, r.id)} success="Horário adicionado." reset submit="Adicionar" className="grid gap-3">
                  <fieldset className="flex flex-wrap gap-x-3 gap-y-1 text-sm"><legend className="label">Dias</legend>
                    {ORDER.map((d) => <label key={d} className="flex items-center gap-1"><input type="checkbox" name="weekday" value={d} /> {WEEKDAYS_SHORT[d]}</label>)}</fieldset>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="label" htmlFor={`o-${r.id}`}>Abre</label><input id={`o-${r.id}`} type="time" name="opens" required defaultValue="08:00" className="input" /></div>
                    <div><label className="label" htmlFor={`f-${r.id}`}>Fecha</label><input id={`f-${r.id}`} type="time" name="closes" required defaultValue="20:00" className="input" /></div>
                  </div>
                </ActionForm>
                <p className="mt-2 text-xs text-mute">Para pausa de almoço, cadastre dois intervalos (ex.: 08:00–12:00 e 13:00–20:00).</p>
              </div>
            </div>
          </section>
        );
      })}

      <section className="card p-5">
        <h2 className="mb-1 text-lg font-semibold">Bloqueios de agenda</h2>
        <p className="mb-4 text-sm text-mute">Feriados, manutenção ou ausências. Só é possível bloquear períodos sem reservas confirmadas.</p>
        <ActionForm action={addBlockAction} success="Período bloqueado." reset submit="Bloquear" className="mb-4 grid items-end gap-3 md:grid-cols-[1fr_1fr_1fr_1.2fr_auto]">
          <div><label className="label" htmlFor="b-room">Sala</label><select id="b-room" name="room" className="input"><option value="">Todas as salas</option>{(rooms ?? []).map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
          <div><label className="label" htmlFor="b-start">Início</label><input id="b-start" name="start" type="datetime-local" required className="input" /></div>
          <div><label className="label" htmlFor="b-end">Fim</label><input id="b-end" name="end" type="datetime-local" required className="input" /></div>
          <div><label className="label" htmlFor="b-reason">Motivo</label><input id="b-reason" name="reason" className="input" placeholder="Ex.: feriado" /></div>
        </ActionForm>
        {!blocks?.length ? <Empty title="Nenhum bloqueio futuro." /> : (
          <ul className="divide-y divide-line text-sm">{blocks.map((b: any) => (
            <li key={b.id} className="flex flex-wrap items-center justify-between gap-2 py-2"><span>{b.room?.name ?? 'Todas as salas'} · {fmtDateTime(b.starts_at)} até {fmtDateTime(b.ends_at)}{b.reason ? ` · ${b.reason}` : ''}</span>
              <ActionButton action={deleteBlockAction.bind(null, b.id)} success="Bloqueio removido." confirm="Remover este bloqueio?">Remover</ActionButton></li>))}</ul>
        )}
      </section>

      {settings && (
        <section className="card p-5">
          <h2 className="mb-4 text-lg font-semibold">Regras de reserva</h2>
          <ActionForm action={updateSettingsAction} success="Regras atualizadas." className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="s-slot">Intervalo das reservas</label><select id="s-slot" name="slot_minutes" defaultValue={settings.slot_minutes} className="input"><option value="60">Horas cheias (1 em 1 hora)</option><option value="30">A cada 30 minutos</option></select></div>
            <div><label className="label" htmlFor="s-notice">Cancelamento direto até (horas antes)</label><input id="s-notice" name="cancellation_notice_hours" type="number" min={0} defaultValue={settings.cancellation_notice_hours} className="input" /></div>
            <div><label className="label" htmlFor="s-min">Duração mínima (minutos)</label><input id="s-min" name="min_duration_minutes" type="number" min={30} step={30} defaultValue={settings.min_duration_minutes} className="input" /></div>
            <div><label className="label" htmlFor="s-max">Duração máxima (minutos)</label><input id="s-max" name="max_duration_minutes" type="number" min={30} step={30} defaultValue={settings.max_duration_minutes} className="input" /></div>
          </ActionForm>
        </section>
      )}
    </div>
  );
}
