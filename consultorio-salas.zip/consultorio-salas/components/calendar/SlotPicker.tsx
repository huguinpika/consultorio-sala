'use client';
import { useEffect, useMemo, useState } from 'react';
import { busyAction } from '@/app/actions/booking';
import { endOptions, freeStarts, openIntervals, type Interval } from '@/lib/slots';
import { fmtDuration, hhmm, minutesOfDay, todayYmd } from '@/lib/time';

export type SlotValue = { roomId: string; date: string; start: number | null; end: number | null };
export type RoomLite = { id: string; name: string; color: string };

/** Sala + data + início + término, mostrando só horários realmente livres. */
export default function SlotPicker({ rooms, hours, settings, value, onChange, excludeStartISO }: {
  rooms: RoomLite[]; hours: any[]; settings: any; value: SlotValue; onChange: (v: SlotValue) => void; excludeStartISO?: string;
}) {
  const [busy, setBusy] = useState<Interval[]>([]);
  const [loading, setLoading] = useState(false);
  const { roomId, date, start, end } = value;
  const slot = settings.slot_minutes, min = settings.min_duration_minutes, max = settings.max_duration_minutes;

  useEffect(() => {
    if (!roomId || !date) return;
    let live = true;
    setLoading(true);
    busyAction(roomId, date, excludeStartISO).then((r) => { if (live) { setBusy(r.ok ? r.busy : []); setLoading(false); } });
    return () => { live = false; };
  }, [roomId, date, excludeStartISO]);

  const today = todayYmd();
  const nowMin = date === today ? minutesOfDay(new Date()) : null;
  const iv = useMemo(() => openIntervals(hours, roomId, date), [hours, roomId, date]);
  const starts = date < today ? [] : freeStarts(iv, busy, slot, min, nowMin);
  const ends = start !== null && starts.includes(start) ? endOptions(iv, busy, slot, min, max, start) : [];

  useEffect(() => {
    let s = start, e = end;
    if (s !== null && !starts.includes(s)) s = null;
    if (s === null) e = null; else if (e === null || !ends.includes(e)) e = ends[0] ?? null;
    if (s !== start || e !== end) onChange({ ...value, start: s, end: e });
  });

  return (
    <div className="grid gap-3">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="label" htmlFor="sp-room">Sala</label>
          <select id="sp-room" className="input" value={roomId} onChange={(e) => onChange({ ...value, roomId: e.target.value, start: null, end: null })}>
            {rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        </div>
        <div>
          <label className="label" htmlFor="sp-date">Data</label>
          <input id="sp-date" type="date" className="input" min={today} value={date} onChange={(e) => e.target.value && onChange({ ...value, date: e.target.value, start: null, end: null })} />
        </div>
      </div>
      {!iv.length ? (
        <p className="rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">Essa sala não funciona nesse dia. Escolha outra data ou outra sala.</p>
      ) : !loading && !starts.length ? (
        <p className="rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">Não há horários livres nessa data. Tente outra sala ou outro dia.</p>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="sp-start">Início</label>
            <select id="sp-start" className="input" value={start ?? ''} onChange={(e) => onChange({ ...value, start: e.target.value === '' ? null : Number(e.target.value), end: null })}>
              <option value="">Escolha</option>
              {starts.map((m) => <option key={m} value={m}>{hhmm(m)}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="sp-end">Término</label>
            <select id="sp-end" className="input" value={end ?? ''} disabled={start === null} onChange={(e) => onChange({ ...value, end: e.target.value === '' ? null : Number(e.target.value) })}>
              <option value="">Escolha</option>
              {ends.map((m) => <option key={m} value={m}>{hhmm(m)} ({fmtDuration(m - (start ?? 0))})</option>)}
            </select>
          </div>
        </div>
      )}
    </div>
  );
}
