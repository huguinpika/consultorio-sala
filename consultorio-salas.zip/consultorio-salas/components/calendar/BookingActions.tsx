'use client';
import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { Modal, useToast } from '@/components/ui';
import SlotPicker, { type RoomLite, type SlotValue } from './SlotPicker';
import { cancelBookingAction, requestCancelAction, requestChangeAction, rescheduleAction } from '@/app/actions/booking';
import { ymd } from '@/lib/time';
import type { Res } from '@/lib/errors';

export type BookingLite = { id: string; roomId: string; start: string; end: string; status: string };
type Mode = null | 'cancel' | 'request-cancel' | 'change' | 'reschedule';

/** Botões de cancelar / solicitar cancelamento / alterar, respeitando a regra do prazo. */
export default function BookingActions({ booking, rooms, hours, settings, isAdmin }: {
  booking: BookingLite; rooms: RoomLite[]; hours: any[]; settings: any; isAdmin: boolean;
}) {
  const [mode, setMode] = useState<Mode>(null);
  const [reason, setReason] = useState('');
  const [slot, setSlot] = useState<SlotValue>({ roomId: booking.roomId, date: ymd(booking.start), start: null, end: null });
  const [pending, run] = useTransition();
  const { toast } = useToast();
  const router = useRouter();

  if (booking.status !== 'confirmed') return null;
  const startMs = new Date(booking.start).getTime();
  if (!isAdmin && startMs <= Date.now()) return null;
  const direct = isAdmin || startMs - settings.cancellation_notice_hours * 3600_000 > Date.now();
  const close = () => { setMode(null); setReason(''); };
  const go = (fn: () => Promise<Res>, ok: string) => run(async () => {
    const r = await fn();
    if (r.ok) { toast(ok); close(); router.refresh(); } else toast(r.error, 'err');
  });
  const slotOk = slot.start !== null && slot.end !== null;
  const s = { room: slot.roomId, date: slot.date, startMin: slot.start ?? 0, endMin: slot.end ?? 0 };

  return (
    <>
      <div className="flex flex-wrap gap-2">
        {direct
          ? <button className="btn-danger btn-sm" onClick={() => setMode('cancel')}>Cancelar reserva</button>
          : <button className="btn-danger btn-sm" onClick={() => setMode('request-cancel')}>Solicitar cancelamento</button>}
        <button className="btn-ghost btn-sm" onClick={() => setMode(isAdmin ? 'reschedule' : 'change')}>{isAdmin ? 'Remanejar' : 'Solicitar alteração'}</button>
      </div>

      <Modal open={mode === 'cancel' || mode === 'request-cancel'} onClose={close} title={mode === 'cancel' ? 'Cancelar reserva' : 'Solicitar cancelamento'}>
        <p className="mb-3 text-sm text-mute">
          {mode === 'cancel' ? 'O horário volta a ficar livre na hora. O cancelamento fica registrado no histórico.'
            : `Faltam menos de ${settings.cancellation_notice_hours}h para o início, então a administração precisa aprovar o cancelamento.`}
        </p>
        <label className="label" htmlFor="ba-reason">Motivo (opcional)</label>
        <input id="ba-reason" className="input mb-4" value={reason} onChange={(e) => setReason(e.target.value)} />
        <div className="flex justify-end gap-2">
          <button className="btn-ghost" onClick={close}>Voltar</button>
          <button className="btn-primary" disabled={pending}
            onClick={() => mode === 'cancel' ? go(() => cancelBookingAction(booking.id, reason), 'Reserva cancelada.') : go(() => requestCancelAction(booking.id, reason), 'Solicitação enviada.')}>
            {mode === 'cancel' ? 'Confirmar cancelamento' : 'Enviar solicitação'}
          </button>
        </div>
      </Modal>

      <Modal open={mode === 'change' || mode === 'reschedule'} onClose={close} title={mode === 'reschedule' ? 'Remanejar reserva' : 'Solicitar alteração'} wide>
        <div className="grid gap-4">
          <SlotPicker rooms={rooms} hours={hours} settings={settings} value={slot} onChange={setSlot} excludeStartISO={booking.start} />
          {mode === 'change' && (
            <div>
              <label className="label" htmlFor="ba-reason2">Motivo (opcional)</label>
              <input id="ba-reason2" className="input" value={reason} onChange={(e) => setReason(e.target.value)} />
            </div>
          )}
          <div className="flex justify-end gap-2">
            <button className="btn-ghost" onClick={close}>Voltar</button>
            <button className="btn-primary" disabled={!slotOk || pending}
              onClick={() => mode === 'reschedule' ? go(() => rescheduleAction(booking.id, s), 'Reserva remanejada.') : go(() => requestChangeAction(booking.id, s, reason), 'Solicitação enviada.')}>
              {mode === 'reschedule' ? 'Salvar novo horário' : 'Enviar solicitação'}
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}
