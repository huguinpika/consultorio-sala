import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        canvas: '#f6f7f6',
        ink: '#18231f',
        mute: '#66756f',
        line: '#e3e8e5',
        brand: { 50: '#eef6f3', 100: '#d6eae3', 500: '#2a8068', 600: '#1f6b57', 700: '#185544' },
      },
      fontFamily: { sans: ['var(--font-sans)', 'system-ui', 'sans-serif'] },
      keyframes: {
        pop: { '0%': { opacity: '0', transform: 'translateY(6px) scale(.98)' }, '100%': { opacity: '1', transform: 'none' } },
      },
      animation: { pop: 'pop .16s ease-out' },
    },
  },
  plugins: [],
};
export default config;
