-- TESTES DAS REGRAS DE RESERVA
-- Rode no SQL Editor de um projeto Supabase de TESTE (não use em produção).
-- Tudo roda dentro de uma transação e termina com ROLLBACK: nada fica salvo.
-- Cada bloco imprime NOTICE "OK ..." ou falha com erro.
begin;

do $$
declare
  v_admin uuid := gen_random_uuid(); v_pro uuid := gen_random_uuid(); v_pro2 uuid := gen_random_uuid();
  v_room uuid; v_room2 uuid; v_start timestamptz; v_b public.bookings; v_msg text;
begin
  -- usuários (o primeiro vira admin pelo trigger)
  insert into auth.users (id, email) values (v_admin, 'admin@teste.local'), (v_pro, 'pro@teste.local'), (v_pro2, 'pro2@teste.local');
  select id into v_room  from public.rooms where name = 'Sala 1';
  select id into v_room2 from public.rooms where name = 'Sala 2';
  insert into public.room_rates (room_id, hourly_rate_cents) values (v_room, 5000), (v_room2, 6000);
  insert into public.professional_rates (professional_id, room_id, hourly_rate_cents) values (v_pro2, null, 4000);

  -- próxima segunda-feira às 10:00 (horário de Brasília), pelo menos 3 dias à frente
  v_start := (((current_date + 3 + ((8 - extract(dow from current_date + 3)::int) % 7))::timestamp + time '10:00')
              at time zone 'America/Sao_Paulo');

  -- agir como profissional
  perform set_config('request.jwt.claims', json_build_object('sub', v_pro, 'role', 'authenticated')::text, true);
  v_b := public.create_booking(v_room, v_start, v_start + interval '2 hours');
  assert v_b.amount_cents = 10000, 'valor = 2h x R$50';
  raise notice 'OK criar reserva e calcular valor';

  begin  -- conflito na mesma sala
    perform public.create_booking(v_room, v_start + interval '1 hour', v_start + interval '3 hours');
    raise exception 'deveria falhar';
  exception when others then
    get stacked diagnostics v_msg = message_text; assert v_msg = 'horario_indisponivel', v_msg;
  end;
  raise notice 'OK bloqueia conflito na mesma sala';

  perform public.create_booking(v_room2, v_start, v_start + interval '1 hour');
  raise notice 'OK permite horário igual em sala diferente';

  begin  -- fora do expediente (07:00)
    perform public.create_booking(v_room, v_start - interval '3 hours', v_start - interval '2 hours');
    raise exception 'deveria falhar';
  exception when others then
    get stacked diagnostics v_msg = message_text; assert v_msg = 'fora_do_expediente', v_msg;
  end;
  raise notice 'OK bloqueia fora do expediente';

  begin  -- passado
    perform public.create_booking(v_room, now() - interval '2 days', now() - interval '2 days' + interval '1 hour');
    raise exception 'deveria falhar';
  exception when others then
    get stacked diagnostics v_msg = message_text; assert v_msg = 'horario_no_passado', v_msg;
  end;
  raise notice 'OK bloqueia reserva no passado';

  -- outro profissional não enxerga a reserva
  perform set_config('request.jwt.claims', json_build_object('sub', v_pro2, 'role', 'authenticated')::text, true);
  set local role authenticated;
  assert (select count(*) from public.bookings) = 0, 'RLS: pro2 não pode ver reservas do pro';
  reset role;
  raise notice 'OK RLS isola profissionais';

  -- preço especial do profissional 2
  v_b := public.create_booking(v_room, v_start + interval '3 hours', v_start + interval '4 hours');
  assert v_b.amount_cents = 4000, 'preço especial';
  raise notice 'OK preço especial por profissional';

  -- cancelamento dentro do prazo (>24h) permitido
  perform public.cancel_booking(v_b.id, 'teste');
  raise notice 'OK cancelamento dentro do prazo';

  -- admin registra pagamento; cancelamento posterior não apaga pagamento
  perform set_config('request.jwt.claims', json_build_object('sub', v_admin, 'role', 'authenticated')::text, true);
  select * into v_b from public.bookings where professional_id = v_pro and room_id = v_room;
  perform public.record_payment(v_b.id, 3000);
  perform public.cancel_booking(v_b.id, 'admin');
  assert (select payment_status from public.booking_financials where booking_id = v_b.id) = 'a_estornar';
  assert (select count(*) from public.payments where booking_id = v_b.id) = 1, 'pagamento preservado';
  raise notice 'OK financeiro reflete cancelamento sem apagar pagamentos';

  assert (select count(*) from public.audit_log where table_name = 'bookings') > 0, 'auditoria';
  raise notice 'OK histórico de alterações registrado';
end $$;

rollback;
