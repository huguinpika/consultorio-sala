import type { ReactNode } from 'react';

export default function AuthFrame({ title, subtitle, children }: { title: string; subtitle?: string; children: ReactNode }) {
  return (
    <div className="grid min-h-screen md:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden overflow-hidden bg-brand-700 p-12 text-white md:flex md:flex-col md:justify-between">
        <div className="flex items-center gap-2.5">
          <svg width="30" height="30" viewBox="0 0 28 28" aria-hidden><rect x="2" y="3" width="14" height="22" rx="3" fill="#fff" fillOpacity=".95" /><rect x="12" y="3" width="14" height="22" rx="3" fill="#8fb4ff" fillOpacity=".9" /></svg>
          <span className="font-semibold tracking-tight">Agenda de Salas</span>
        </div>
        <div>
          <p className="max-w-sm text-3xl font-semibold leading-tight tracking-tight">Duas salas, um calendário, nenhum conflito de horário.</p>
          <p className="mt-4 max-w-sm text-sm text-white/70">Reserve, acompanhe valores por hora e mantenha tudo organizado em um só lugar.</p>
        </div>
        <div aria-hidden className="pointer-events-none absolute -right-16 top-1/3 grid grid-cols-2 gap-3 opacity-20">
          {Array.from({ length: 8 }, (_, i) => <div key={i} className="h-24 w-20 rounded-xl bg-white" style={{ marginTop: i % 2 ? 28 : 0 }} />)}
        </div>
      </div>
      <div className="flex items-center justify-center px-5 py-10">
        <div className="w-full max-w-sm">
          <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
          {subtitle && <p className="mb-6 mt-1 text-sm text-mute">{subtitle}</p>}
          {children}
        </div>
      </div>
    </div>
  );
}
