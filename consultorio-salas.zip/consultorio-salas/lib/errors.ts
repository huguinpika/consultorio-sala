const MSG: Record<string, string> = {
  horario_indisponivel: 'Esse horário acabou de ser ocupado. Escolha outro horário ou outra sala.',
  horario_bloqueado: 'Esse horário está bloqueado pela administração.',
  fora_do_expediente: 'Esse horário está fora do funcionamento da sala.',
  horario_no_passado: 'Não é possível reservar horários que já passaram.',
  horario_invalido: 'O horário de início precisa seguir os intervalos permitidos (ex.: horas cheias).',
  duracao_invalida: 'A duração não é permitida. Confira a duração mínima, a máxima e os intervalos.',
  sala_indisponivel: 'Essa sala não está disponível para reservas.',
  tarifa_nao_configurada: 'O valor da hora desta sala ainda não foi definido. Fale com a administração.',
  profissional_inativo: 'Esse profissional está suspenso e não pode receber reservas.',
  usuario_inativo: 'Sua conta está suspensa. Fale com a administração.',
  nao_autenticado: 'Sua sessão expirou. Entre novamente.',
  sem_permissao: 'Você não tem permissão para essa ação.',
  reserva_nao_encontrada: 'Reserva não encontrada.',
  reserva_ja_cancelada: 'Essa reserva já foi cancelada.',
  cancelamento_fora_do_prazo: 'O prazo para cancelar sozinho passou. Envie uma solicitação de cancelamento à administração.',
  solicitacao_pendente: 'Já existe uma solicitação em análise para essa reserva.',
  solicitacao_nao_encontrada: 'Solicitação não encontrada.',
  solicitacao_ja_resolvida: 'Essa solicitação já foi respondida.',
  valor_invalido: 'Informe um valor maior que zero.',
  reserva_cancelada_sem_pagamento: 'Reserva cancelada não recebe novos pagamentos. Registre um estorno, se necessário.',
  pagamento_excede_valor: 'O pagamento ultrapassa o valor da reserva.',
  estorno_excede_pago: 'O estorno é maior que o valor já pago.',
  existem_reservas_no_periodo: 'Há reservas confirmadas nesse período. Cancele ou remaneje antes de bloquear.',
  ultimo_administrador: 'Precisa existir ao menos um administrador ativo.',
};

export function friendly(message?: string | null): string {
  if (!message) return 'Algo deu errado. Tente novamente.';
  for (const k of Object.keys(MSG)) if (message.includes(k)) return MSG[k];
  if (message.includes('bookings_no_overlap')) return MSG.horario_indisponivel;
  if (message.includes('duplicate key')) return 'Já existe um registro com esses dados.';
  if (message.includes('violates foreign key')) return 'Este item possui histórico vinculado e não pode ser removido.';
  return 'Não foi possível concluir a ação. Tente novamente.';
}

export type Res = { ok: true; [k: string]: any } | { ok: false; error: string };
export const fail = (message?: string | null): Res => ({ ok: false, error: friendly(message) });
export const failText = (error: string): Res => ({ ok: false, error });
