'use client';
import { useState } from 'react';
import { ActionForm, Modal } from '@/components/ui';
import { recordPaymentAction } from '@/app/actions/booking';
import { todayYmd } from '@/lib/time';

export default function PaymentDialog({ bookingId, balanceCents, paidCents, label, status }: { bookingId: string; balanceCents: number; paidCents: number; label: string; status: string }) {
  const [open, setOpen] = useState(false);
  const refundDue = status === 'a_estornar';
  const def = ((refundDue ? paidCents : Math.max(balanceCents, 0)) / 100).toFixed(2).replace('.', ',');
  const canPay = status !== 'cancelada' && status !== 'a_estornar' && status !== 'pago';
  return (
    <>
      <button className="btn-ghost btn-sm" onClick={() => setOpen(true)}>{refundDue ? 'Registrar estorno' : canPay ? 'Registrar pagamento' : 'Pagamentos'}</button>
      <Modal open={open} onClose={() => setOpen(false)} title={refundDue ? 'Registrar estorno' : 'Registrar pagamento'}>
        <p className="mb-4 text-sm text-mute">{label}</p>
        <ActionForm action={recordPaymentAction.bind(null, bookingId)} success="Registrado." submit="Salvar" className="grid gap-4" onDone={() => setOpen(false)}>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label" htmlFor="p-kind">Tipo</label>
              <select id="p-kind" name="kind" className="input" defaultValue={refundDue ? 'refund' : 'payment'}>
                <option value="payment" disabled={status === 'cancelada' || refundDue}>Pagamento</option><option value="refund" disabled={paidCents <= 0}>Estorno</option></select></div>
            <div><label className="label" htmlFor="p-amount">Valor (R$)</label><input id="p-amount" name="amount" inputMode="decimal" required defaultValue={def} className="input" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="label" htmlFor="p-method">Forma</label>
              <select id="p-method" name="method" className="input"><option value="pix">Pix</option><option value="dinheiro">Dinheiro</option><option value="cartao">Cartão</option><option value="transferencia">Transferência</option><option value="outro">Outro</option></select></div>
            <div><label className="label" htmlFor="p-date">Data</label><input id="p-date" type="date" name="date" defaultValue={todayYmd()} className="input" /></div>
          </div>
          <div><label className="label" htmlFor="p-notes">Observação (opcional)</label><input id="p-notes" name="notes" className="input" /></div>
        </ActionForm>
      </Modal>
    </>
  );
}
