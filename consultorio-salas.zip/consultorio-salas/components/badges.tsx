import type { ReactNode } from 'react';

const TONES = {
  gray: 'bg-stone-100 text-stone-700',
  green: 'bg-emerald-50 text-emerald-800',
  amber: 'bg-amber-50 text-amber-800',
  red: 'bg-red-50 text-red-700',
  blue: 'bg-sky-50 text-sky-800',
};
export type Tone = keyof typeof TONES;

export function Badge({ tone = 'gray', children }: { tone?: Tone; children: ReactNode }) {
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${TONES[tone]}`}>{children}</span>;
}

export const PAY: Record<string, { label: string; tone: Tone; dot: string }> = {
  pendente: { label: 'Pendente', tone: 'amber', dot: '#d97706' },
  parcial: { label: 'Parcialmente pago', tone: 'blue', dot: '#0284c7' },
  pago: { label: 'Pago', tone: 'green', dot: '#059669' },
  cancelada: { label: 'Cancelada', tone: 'gray', dot: '#a8a29e' },
  a_estornar: { label: 'A estornar', tone: 'red', dot: '#dc2626' },
};

export function PayBadge({ status }: { status?: string | null }) {
  const p = PAY[status ?? 'pendente'] ?? PAY.pendente;
  return <Badge tone={p.tone}>{p.label}</Badge>;
}

export function Empty({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="px-4 py-10 text-center">
      <p className="text-sm font-medium">{title}</p>
      {hint && <p className="mt-1 text-sm text-mute">{hint}</p>}
    </div>
  );
}

export function RoomDot({ color, name }: { color: string; name: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />
      {name}
    </span>
  );
}
