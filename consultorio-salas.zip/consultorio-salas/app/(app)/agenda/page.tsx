import Calendar from '@/components/calendar/Calendar';
import type { Ev } from '@/components/calendar/TimeGrid';
import { Empty } from '@/components/badges';
import { requireCtx } from '@/lib/auth';
import { addDays, monthStart, startOfWeek, toISO, todayYmd } from '@/lib/time';

export default async function AgendaPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { supabase, profile } = await requireCtx();
  const isAdmin = profile.role === 'admin';
  const view = (['dia', 'semana', 'mes'].includes(sp.view ?? '') ? sp.view : 'dia') as 'dia' | 'semana' | 'mes';
  const date = /^\d{4}-\d{2}-\d{2}$/.test(sp.date ?? '') ? sp.date! : todayYmd();

  const [{ data: rooms }, { data: hours }, { data: settings }] = await Promise.all([
    supabase.from('rooms').select('id,name,color').eq('is_active', true).order('sort_order'),
    supabase.from('opening_hours').select('*'),
    supabase.from('settings').select('*').single(),
  ]);
  if (!rooms?.length || !settings) return <Empty title="Nenhuma sala ativa" hint="A administração precisa cadastrar ou ativar as salas." />;
  const roomId = rooms.find((r: any) => r.id === sp.sala)?.id ?? rooms[0].id;

  const from = view === 'dia' ? date : view === 'semana' ? startOfWeek(date) : startOfWeek(monthStart(date));
  const to = view === 'dia' ? addDays(date, 1) : view === 'semana' ? addDays(from, 7) : addDays(startOfWeek(monthStart(date)), 42);
  const fromI = toISO(from, 0), toI = toISO(to, 0);

  const { data: bk } = await supabase
    .from('bookings')
    .select('id,room_id,professional_id,starts_at,ends_at,status,amount_cents,notes,professional:profiles!bookings_professional_id_fkey(full_name)')
    .eq('status', 'confirmed').lt('starts_at', toI).gt('ends_at', fromI);
  const ids = (bk ?? []).map((b: any) => b.id);
  const { data: fin } = ids.length ? await supabase.from('booking_financials').select('booking_id,payment_status').in('booking_id', ids) : { data: [] as any[] };
  const payOf = new Map((fin ?? []).map((f: any) => [f.booking_id, f.payment_status]));

  const events: Ev[] = (bk ?? []).map((b: any) => ({
    key: b.id, id: b.id, kind: 'booking', roomId: b.room_id, start: b.starts_at, end: b.ends_at, mine: b.professional_id === profile.id,
    title: isAdmin ? b.professional?.full_name ?? 'Profissional' : 'Sua reserva',
    pay: payOf.get(b.id), amount: b.amount_cents, professionalId: b.professional_id, professionalName: b.professional?.full_name, status: b.status, notes: b.notes ?? undefined,
  }));

  if (isAdmin) {
    const { data: blocks } = await supabase.from('blocks').select('*').lt('starts_at', toI).gt('ends_at', fromI);
    for (const k of blocks ?? []) events.push({ key: 'k' + k.id, kind: 'block', roomId: k.room_id ?? '*', start: k.starts_at, end: k.ends_at, mine: false, title: k.reason || 'Bloqueado' });
  } else {
    const res = await Promise.all(rooms.map((r: any) => supabase.rpc('get_room_busy', { p_room: r.id, p_from: fromI, p_to: toI })));
    res.forEach((r, i) => (r.data ?? []).forEach((x: any, j: number) => {
      if (x.kind === 'booking' && x.is_mine) return; // as suas já aparecem com detalhes
      events.push({ key: `o${i}-${j}`, kind: x.kind === 'block' ? 'block' : 'busy', roomId: rooms[i].id, start: x.starts_at, end: x.ends_at, mine: false, title: x.kind === 'block' ? 'Indisponível' : 'Ocupado' });
    }));
  }

  let professionals: { id: string; name: string }[] = [];
  if (isAdmin) {
    const { data } = await supabase.from('profiles').select('id,full_name').eq('is_active', true).order('full_name');
    professionals = (data ?? []).map((p: any) => ({ id: p.id, name: p.full_name }));
  }

  return (
    <div>
      <h1 className="page-title mb-5">Agenda</h1>
      <Calendar view={view} date={date} roomId={roomId} rooms={rooms as any} hours={hours ?? []} settings={settings} events={events} professionals={professionals} isAdmin={isAdmin} />
    </div>
  );
}
