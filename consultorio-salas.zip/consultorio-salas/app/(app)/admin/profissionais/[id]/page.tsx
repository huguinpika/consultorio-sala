import Link from 'next/link';
import { notFound } from 'next/navigation';
import { requireAdmin } from '@/lib/auth';
import { Badge, Empty } from '@/components/badges';
import { ActionButton, ActionForm } from '@/components/ui';
import { addProfessionalRateAction, deleteProfessionalAction, sendResetAction, setActiveAction, updateProfessionalAction } from '@/app/actions/admin';
import { brl } from '@/lib/money';
import { fmtDateTime } from '@/lib/time';

export default async function ProfessionalDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase } = await requireAdmin();
  const { data: p } = await supabase.from('profiles').select('*').eq('id', id).single();
  if (!p) notFound();
  const [{ data: rooms }, { data: rates }, { data: fin }] = await Promise.all([
    supabase.from('rooms').select('id,name').order('sort_order'),
    supabase.from('professional_rates').select('*').eq('professional_id', id).order('valid_from', { ascending: false }).limit(20),
    supabase.from('booking_financials').select('status,amount_cents,paid_cents,balance_cents').eq('professional_id', id),
  ]);
  const roomName = new Map((rooms ?? []).map((r: any) => [r.id, r.name]));
  const rows = fin ?? [];
  const confirmed = rows.filter((r: any) => r.status === 'confirmed');
  const billed = confirmed.reduce((s: number, r: any) => s + r.amount_cents, 0);
  const open = confirmed.reduce((s: number, r: any) => s + Math.max(r.balance_cents, 0), 0);

  return (
    <div className="grid max-w-3xl gap-6">
      <div>
        <Link href="/admin/profissionais" className="text-sm text-brand-700 hover:underline">← Profissionais</Link>
        <div className="mt-1 flex flex-wrap items-center gap-3"><h1 className="page-title">{p.full_name}</h1>{p.is_active ? <Badge tone="green">Ativo</Badge> : <Badge tone="red">Suspenso</Badge>}</div>
        <p className="text-sm text-mute">{p.email}</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="card p-3"><p className="text-xs text-mute">Reservas</p><p className="text-lg font-semibold">{confirmed.length}</p></div>
        <div className="card p-3"><p className="text-xs text-mute">Faturado</p><p className="text-lg font-semibold">{brl(billed)}</p></div>
        <div className="card p-3"><p className="text-xs text-mute">Em aberto</p><p className="text-lg font-semibold text-amber-700">{brl(open)}</p></div>
      </div>

      <section className="card p-5">
        <h2 className="mb-4 font-semibold">Dados cadastrais</h2>
        <ActionForm action={updateProfessionalAction.bind(null, id)} success="Dados atualizados." className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2"><label className="label" htmlFor="d-name">Nome completo</label><input id="d-name" name="full_name" required defaultValue={p.full_name} className="input" /></div>
          <div><label className="label" htmlFor="d-phone">Telefone</label><input id="d-phone" name="phone" defaultValue={p.phone ?? ''} className="input" /></div>
          <div><label className="label" htmlFor="d-reg">Registro profissional (CRP)</label><input id="d-reg" name="registration_number" defaultValue={p.registration_number ?? ''} className="input" /></div>
        </ActionForm>
      </section>

      <section className="card p-5">
        <h2 className="mb-1 font-semibold">Preço especial por hora</h2>
        <p className="mb-4 text-sm text-mute">Vale para novas reservas. Reservas já feitas mantêm o valor da época. Sem preço especial, vale o preço da sala.</p>
        <ActionForm action={addProfessionalRateAction.bind(null, id)} success="Preço especial salvo." reset submit="Salvar preço" className="mb-4 grid items-end gap-3 sm:grid-cols-[1fr_1fr_auto]">
          <div><label className="label" htmlFor="r-room">Sala</label><select id="r-room" name="room" className="input"><option value="">Todas as salas</option>{(rooms ?? []).map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
          <div><label className="label" htmlFor="r-price">Valor da hora (R$)</label><input id="r-price" name="price" inputMode="decimal" required placeholder="50,00" className="input" /></div>
        </ActionForm>
        {!rates?.length ? <Empty title="Nenhum preço especial." /> : (
          <ul className="divide-y divide-line text-sm">{rates.map((r: any, i: number) => (
            <li key={r.id} className="flex justify-between py-2"><span>{r.room_id ? roomName.get(r.room_id) : 'Todas as salas'} · desde {fmtDateTime(r.valid_from).slice(0, 10)}</span><span className="font-medium">{brl(r.hourly_rate_cents)}/h{i === 0 ? '' : ''}</span></li>))}</ul>
        )}
      </section>

      <section className="card p-5">
        <h2 className="mb-4 font-semibold">Acesso à conta</h2>
        <div className="flex flex-wrap gap-2">
          <ActionButton action={sendResetAction.bind(null, id)} success="E-mail de redefinição enviado.">Enviar link para redefinir senha</ActionButton>
          {p.is_active
            ? <ActionButton action={setActiveAction.bind(null, id, false)} success="Conta suspensa." confirm="Suspender esta conta? A pessoa não conseguirá mais entrar, mas o histórico é mantido." className="btn-danger btn-sm">Suspender conta</ActionButton>
            : <ActionButton action={setActiveAction.bind(null, id, true)} success="Conta reativada.">Reativar conta</ActionButton>}
          <ActionButton action={deleteProfessionalAction.bind(null, id)} success="Conta excluída." confirm="Excluir definitivamente? Só é possível se não houver reservas." className="btn-danger btn-sm">Excluir conta</ActionButton>
        </div>
        <p className="mt-3 text-xs text-mute">Quem tem reservas no histórico não pode ser excluído: suspenda a conta.</p>
      </section>
    </div>
  );
}
