import Link from 'next/link';
import AuthFrame from '@/components/AuthFrame';
import { ActionForm } from '@/components/ui';
import { requestResetAction } from '@/app/actions/auth';

export default function ForgotPage() {
  return (
    <AuthFrame title="Redefinir senha" subtitle="Enviaremos um link para o seu e-mail. Se a conta existir, a mensagem chega em instantes.">
      <ActionForm action={requestResetAction} submit="Enviar link" success="Se o e-mail estiver cadastrado, o link foi enviado." className="grid gap-4" submitClass="btn-primary w-full" reset>
        <div><label className="label" htmlFor="email">E-mail</label><input id="email" name="email" type="email" required className="input" /></div>
      </ActionForm>
      <p className="mt-5 text-center text-sm"><Link href="/login" className="text-brand-700 hover:underline">Voltar ao login</Link></p>
    </AuthFrame>
  );
}
