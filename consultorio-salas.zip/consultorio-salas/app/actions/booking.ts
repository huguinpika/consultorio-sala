'use server';
import { revalidatePath } from 'next/cache';
import { requireAdmin, requireCtx } from '@/lib/auth';
import { fail, failText, type Res } from '@/lib/errors';
import { toISO } from '@/lib/time';

const refresh = () => revalidatePath('/', 'layout');
type Slot = { room: string; date: string; startMin: number; endMin: number };

export async function estimateAction(s: Slot, professional?: string): Promise<Res> {
  const { supabase } = await requireCtx();
  const { data, error } = await supabase.rpc('estimate_booking', {
    p_room: s.room, p_starts: toISO(s.date, s.startMin), p_ends: toISO(s.date, s.endMin), p_professional: professional || null,
  });
  if (error) return fail(error.message);
  const r: any = Array.isArray(data) ? data[0] : data;
  return { ok: true, rate: r.hourly_rate_cents, minutes: r.duration_minutes, amount: r.amount_cents };
}

/** Intervalos ocupados (em minutos do dia) de uma sala, sem identificar quem reservou. */
export async function busyAction(room: string, date: string, excludeStartISO?: string): Promise<Res> {
  const { supabase } = await requireCtx();
  const from = toISO(date, 0);
  const { data, error } = await supabase.rpc('get_room_busy', { p_room: room, p_from: from, p_to: toISO(date, 1440) });
  if (error) return fail(error.message);
  const base = new Date(from).getTime();
  const busy = (data as any[])
    .filter((r) => !(excludeStartISO && r.kind === 'booking' && new Date(r.starts_at).getTime() === new Date(excludeStartISO).getTime()))
    .map((r) => ({
      start: Math.max(0, (new Date(r.starts_at).getTime() - base) / 60000),
      end: Math.min(1440, (new Date(r.ends_at).getTime() - base) / 60000),
    }));
  return { ok: true, busy };
}

export async function createBookingAction(s: Slot, professional?: string, notes?: string): Promise<Res> {
  const { supabase } = await requireCtx();
  const { error } = await supabase.rpc('create_booking', {
    p_room: s.room, p_starts: toISO(s.date, s.startMin), p_ends: toISO(s.date, s.endMin),
    p_professional: professional || null, p_notes: notes || null,
  });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function cancelBookingAction(id: string, reason: string): Promise<Res> {
  const { supabase } = await requireCtx();
  const { error } = await supabase.rpc('cancel_booking', { p_booking: id, p_reason: reason || null });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function rescheduleAction(id: string, s: Slot): Promise<Res> {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.rpc('reschedule_booking', {
    p_booking: id, p_room: s.room, p_starts: toISO(s.date, s.startMin), p_ends: toISO(s.date, s.endMin),
  });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function requestCancelAction(id: string, reason: string): Promise<Res> {
  const { supabase } = await requireCtx();
  const { error } = await supabase.rpc('request_booking_change', { p_booking: id, p_type: 'cancel', p_reason: reason || null });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function requestChangeAction(id: string, s: Slot, reason: string): Promise<Res> {
  const { supabase } = await requireCtx();
  const { error } = await supabase.rpc('request_booking_change', {
    p_booking: id, p_type: 'change', p_reason: reason || null,
    p_room: s.room, p_starts: toISO(s.date, s.startMin), p_ends: toISO(s.date, s.endMin),
  });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function resolveRequestAction(id: string, approve: boolean, fd: FormData): Promise<Res> {
  const { supabase } = await requireAdmin();
  const note = String(fd.get('note') || '').trim();
  const { error } = await supabase.rpc('resolve_booking_request', { p_request: id, p_approve: approve, p_note: note || null });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function recordPaymentAction(bookingId: string, fd: FormData): Promise<Res> {
  const { supabase } = await requireAdmin();
  const { parseMoney } = await import('@/lib/money');
  const cents = parseMoney(String(fd.get('amount') || ''));
  if (!cents) return failText('Informe um valor válido.');
  const date = String(fd.get('date') || '');
  const { error } = await supabase.rpc('record_payment', {
    p_booking: bookingId, p_amount_cents: cents, p_kind: String(fd.get('kind') || 'payment'),
    p_method: String(fd.get('method') || 'pix'), p_paid_at: date ? toISO(date, 12 * 60) : null,
    p_notes: String(fd.get('notes') || '').trim() || null,
  });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}
