import AppShell from '@/components/AppShell';
import { requireCtx } from '@/lib/auth';

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const { supabase, profile } = await requireCtx();
  const { count: unread } = await supabase.from('notifications').select('id', { count: 'exact', head: true }).is('read_at', null);
  let pending = 0;
  if (profile.role === 'admin') {
    const { count } = await supabase.from('booking_requests').select('id', { count: 'exact', head: true }).eq('status', 'pending');
    pending = count ?? 0;
  }
  return <AppShell role={profile.role} name={profile.full_name} unread={unread ?? 0} pending={pending}>{children}</AppShell>;
}
