'use client';
import { createContext, useCallback, useContext, useEffect, useState, useTransition, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { AlertCircle, CheckCircle2, X } from 'lucide-react';
import type { Res } from '@/lib/errors';

type T = { id: number; msg: string; kind: 'ok' | 'err' };
const Ctx = createContext<{ toast: (m: string, k?: 'ok' | 'err') => void }>({ toast: () => {} });
export const useToast = () => useContext(Ctx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<T[]>([]);
  const toast = useCallback((msg: string, kind: 'ok' | 'err' = 'ok') => {
    const id = Date.now() + Math.random();
    setItems((s) => [...s, { id, msg, kind }]);
    setTimeout(() => setItems((s) => s.filter((i) => i.id !== id)), kind === 'err' ? 7000 : 3500);
  }, []);
  return (
    <Ctx.Provider value={{ toast }}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-20 z-[70] flex flex-col items-center gap-2 px-4 md:bottom-6" aria-live="polite">
        {items.map((i) => (
          <div key={i.id} role="status" className={`animate-pop pointer-events-auto flex max-w-md items-start gap-2 rounded-lg border px-3.5 py-2.5 text-sm shadow-lg ${i.kind === 'ok' ? 'border-brand-100 bg-white' : 'border-red-200 bg-red-50 text-red-800'}`}>
            {i.kind === 'ok' ? <CheckCircle2 size={18} className="mt-0.5 shrink-0 text-brand-600" /> : <AlertCircle size={18} className="mt-0.5 shrink-0" />}
            <span>{i.msg}</span>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={title}
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`animate-pop max-h-[92vh] w-full overflow-y-auto rounded-t-2xl bg-white p-5 shadow-xl sm:rounded-2xl ${wide ? 'sm:max-w-xl' : 'sm:max-w-md'}`}>
        <div className="mb-4 flex items-center justify-between gap-4">
          <h2 className="text-base font-semibold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Fechar" className="rounded-md p-1 text-mute hover:bg-canvas"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

type Action = (fd: FormData) => Promise<Res>;

/** Formulário ligado a uma Server Action: mostra aviso de sucesso/erro e atualiza a tela. */
export function ActionForm({ action, children, submit = 'Salvar', success = 'Salvo', className = '', reset = false, onDone, submitClass = 'btn-primary' }: {
  action: Action; children: ReactNode; submit?: string | null; success?: string; className?: string; reset?: boolean; onDone?: (r: Res) => void; submitClass?: string;
}) {
  const [pending, start] = useTransition();
  const { toast } = useToast();
  const router = useRouter();
  return (
    <form className={className} onSubmit={(e) => {
      e.preventDefault();
      const form = e.currentTarget;
      const fd = new FormData(form);
      start(async () => {
        const r = await action(fd);
        if (r && r.ok) { toast(success); if (reset) form.reset(); onDone?.(r); router.refresh(); }
        else if (r) toast(r.error, 'err');
      });
    }}>
      {children}
      {submit && <button className={submitClass} disabled={pending}>{pending ? 'Aguarde…' : submit}</button>}
    </form>
  );
}

export function ActionButton({ action, children, success = 'Feito', confirm, className = 'btn-ghost btn-sm', onDone }: {
  action: () => Promise<Res>; children: ReactNode; success?: string; confirm?: string; className?: string; onDone?: () => void;
}) {
  const [pending, start] = useTransition();
  const { toast } = useToast();
  const router = useRouter();
  return (
    <button type="button" className={className} disabled={pending} onClick={() => {
      if (confirm && !window.confirm(confirm)) return;
      start(async () => {
        const r = await action();
        if (r.ok) { toast(success); onDone?.(); router.refresh(); } else toast(r.error, 'err');
      });
    }}>
      {pending ? 'Aguarde…' : children}
    </button>
  );
}
