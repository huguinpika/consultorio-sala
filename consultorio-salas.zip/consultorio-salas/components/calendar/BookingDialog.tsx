'use client';
import { useEffect, useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { Modal, useToast } from '@/components/ui';
import SlotPicker, { type RoomLite, type SlotValue } from './SlotPicker';
import { createBookingAction, estimateAction } from '@/app/actions/booking';
import { brl } from '@/lib/money';
import { fmtDuration } from '@/lib/time';

export default function BookingDialog({ open, onClose, rooms, hours, settings, professionals, isAdmin, initial }: {
  open: boolean; onClose: () => void; rooms: RoomLite[]; hours: any[]; settings: any;
  professionals: { id: string; name: string }[]; isAdmin: boolean;
  initial: { roomId: string; date: string; start?: number | null };
}) {
  const [slot, setSlot] = useState<SlotValue>({ roomId: initial.roomId, date: initial.date, start: initial.start ?? null, end: null });
  const [prof, setProf] = useState('');
  const [notes, setNotes] = useState('');
  const [est, setEst] = useState<{ rate: number; minutes: number; amount: number } | null>(null);
  const [estError, setEstError] = useState('');
  const [pending, run] = useTransition();
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    if (open) { setSlot({ roomId: initial.roomId, date: initial.date, start: initial.start ?? null, end: null }); setNotes(''); setEst(null); setEstError(''); }
  }, [open, initial.roomId, initial.date, initial.start]);

  const ready = slot.start !== null && slot.end !== null && (!isAdmin || prof);
  useEffect(() => {
    setEst(null); setEstError('');
    if (!open || !ready) return;
    let live = true;
    estimateAction({ room: slot.roomId, date: slot.date, startMin: slot.start!, endMin: slot.end! }, prof || undefined).then((r) => {
      if (!live) return;
      if (r.ok) setEst({ rate: r.rate, minutes: r.minutes, amount: r.amount }); else setEstError(r.error);
    });
    return () => { live = false; };
  }, [open, ready, slot.roomId, slot.date, slot.start, slot.end, prof]);

  const submit = () => run(async () => {
    const r = await createBookingAction({ room: slot.roomId, date: slot.date, startMin: slot.start!, endMin: slot.end! }, prof || undefined, notes);
    if (r.ok) { toast('Reserva confirmada.'); onClose(); router.refresh(); } else toast(r.error, 'err');
  });

  return (
    <Modal open={open} onClose={onClose} title="Reservar horário" wide>
      <div className="grid gap-4">
        {isAdmin && (
          <div>
            <label className="label" htmlFor="bd-prof">Reservar em nome de</label>
            <select id="bd-prof" className="input" value={prof} onChange={(e) => setProf(e.target.value)}>
              <option value="">Escolha o profissional</option>
              {professionals.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
        )}
        <SlotPicker rooms={rooms} hours={hours} settings={settings} value={slot} onChange={setSlot} />
        <div>
          <label className="label" htmlFor="bd-notes">Observação (opcional)</label>
          <input id="bd-notes" className="input" maxLength={200} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Não inclua dados de pacientes" />
        </div>
        <div className="rounded-lg bg-brand-50 px-3.5 py-3 text-sm" aria-live="polite">
          {est ? (
            <p><span className="font-semibold">{brl(est.amount)}</span> <span className="text-mute">· {fmtDuration(est.minutes)} × {brl(est.rate)} por hora</span></p>
          ) : estError ? <p className="text-red-700">{estError}</p>
            : <p className="text-mute">Escolha o horário para ver o valor estimado.</p>}
        </div>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-ghost" onClick={onClose}>Voltar</button>
          <button type="button" className="btn-primary" disabled={!est || pending} onClick={submit}>{pending ? 'Confirmando…' : 'Confirmar reserva'}</button>
        </div>
      </div>
    </Modal>
  );
}
