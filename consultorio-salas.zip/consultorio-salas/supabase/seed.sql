-- SEED: dados mínimos de configuração (não são dados fictícios de uso).
-- Seguro para rodar uma vez após as migrations. Ajuste horários e preços depois, no painel.
insert into public.settings (id) values (true) on conflict (id) do nothing;

insert into public.rooms (name, description, color, sort_order) values
  ('Sala 1', 'Sala 1', '#0f766e', 1),
  ('Sala 2', 'Sala 2', '#2563eb', 2)
on conflict (name) do nothing;

-- Horário inicial sugerido: segunda a sexta, 08:00–20:00 (edite no painel).
insert into public.opening_hours (room_id, weekday, opens_at, closes_at)
select r.id, d, time '08:00', time '20:00'
from public.rooms r, generate_series(1, 5) d
where not exists (select 1 from public.opening_hours oh where oh.room_id = r.id);

-- ATENÇÃO: nenhuma tarifa é criada. Defina o valor da hora de cada sala no painel
-- (Salas > Tarifas) antes de aceitar reservas; sem tarifa o sistema recusa a reserva.
