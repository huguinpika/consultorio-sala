import BookingActions from '@/components/calendar/BookingActions';
import { Badge, Empty, PayBadge } from '@/components/badges';
import { brl } from '@/lib/money';
import { fmtDateLong, fmtDuration, fmtTime, ymd } from '@/lib/time';

export type BookingItem = {
  id: string; room_id: string; starts_at: string; ends_at: string; status: string; amount_cents: number; notes?: string | null; cancel_reason?: string | null;
  room?: { name: string; color: string } | null; professional?: { full_name: string } | null; fin?: { payment_status: string; paid_cents: number; balance_cents: number } | null;
};

export default function BookingList({ items, rooms, hours, settings, isAdmin, empty }: {
  items: BookingItem[]; rooms: any[]; hours: any[]; settings: any; isAdmin: boolean; empty: string;
}) {
  if (!items.length) return <div className="card"><Empty title={empty} /></div>;
  return (
    <ul className="grid gap-2.5">
      {items.map((b) => {
        const mins = (new Date(b.ends_at).getTime() - new Date(b.starts_at).getTime()) / 60000;
        return (
          <li key={b.id} className="card flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
            <span className="hidden h-12 w-1 shrink-0 rounded-full sm:block" style={{ background: b.room?.color ?? '#999' }} />
            <div className="min-w-0 flex-1">
              <p className="font-medium capitalize">{fmtDateLong(ymd(b.starts_at))}</p>
              <p className="text-sm text-mute">
                {fmtTime(b.starts_at)} às {fmtTime(b.ends_at)} ({fmtDuration(mins)}) · <span style={{ color: b.room?.color }}>{b.room?.name}</span>
                {isAdmin && b.professional ? ` · ${b.professional.full_name}` : ''}
              </p>
              {b.status === 'cancelled' && b.cancel_reason && <p className="mt-0.5 text-xs text-mute">Motivo: {b.cancel_reason}</p>}
              {b.notes && <p className="mt-0.5 text-xs text-mute">Obs.: {b.notes}</p>}
            </div>
            <div className="flex items-center gap-3 sm:flex-col sm:items-end sm:gap-1">
              <p className={`font-semibold ${b.status === 'cancelled' ? 'text-mute line-through' : ''}`}>{brl(b.amount_cents)}</p>
              {b.status === 'cancelled' && !(b.fin && b.fin.paid_cents > 0) ? <Badge tone="gray">Cancelada</Badge>
                : <div className="flex gap-1.5">{b.status === 'cancelled' && <Badge tone="gray">Cancelada</Badge>}<PayBadge status={b.fin?.payment_status} /></div>}
            </div>
            <BookingActions booking={{ id: b.id, roomId: b.room_id, start: b.starts_at, end: b.ends_at, status: b.status }} rooms={rooms} hours={hours} settings={settings} isAdmin={isAdmin} />
          </li>
        );
      })}
    </ul>
  );
}

export async function loadBookingContext(supabase: any) {
  const [{ data: rooms }, { data: hours }, { data: settings }] = await Promise.all([
    supabase.from('rooms').select('id,name,color').eq('is_active', true).order('sort_order'),
    supabase.from('opening_hours').select('*'),
    supabase.from('settings').select('*').single(),
  ]);
  return { rooms: rooms ?? [], hours: hours ?? [], settings: settings ?? { slot_minutes: 60, min_duration_minutes: 60, max_duration_minutes: 480, cancellation_notice_hours: 24 } };
}

export async function attachFinancials(supabase: any, rows: any[]): Promise<BookingItem[]> {
  const ids = rows.map((r) => r.id);
  const { data } = ids.length ? await supabase.from('booking_financials').select('booking_id,payment_status,paid_cents,balance_cents').in('booking_id', ids) : { data: [] };
  const m = new Map((data ?? []).map((f: any) => [f.booking_id, f]));
  return rows.map((r) => ({ ...r, fin: m.get(r.id) ?? null }));
}
