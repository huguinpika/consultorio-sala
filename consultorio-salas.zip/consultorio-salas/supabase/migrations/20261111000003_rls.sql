-- =====================================================================
-- 0003 · PERMISSÕES (GRANTs) E POLÍTICAS RLS
-- Princípios:
--  * Nada é acessível por padrão (anon não acessa nada).
--  * Administradora: acesso total; profissional: apenas os próprios dados.
--  * Reservas, pagamentos e solicitações NÃO têm escrita direta: só via RPC.
--  * Histórico (audit_log) é somente leitura e só para a administradora.
-- =====================================================================

-- 1) Fecha tudo e reabre só o necessário
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke execute on functions from public;

-- 2) Funções que o app pode chamar (todas validam auth.uid() internamente)
grant execute on function
  public.is_admin(), public.current_user_active(),
  public.estimate_booking(uuid, timestamptz, timestamptz, uuid),
  public.get_room_busy(uuid, timestamptz, timestamptz),
  public.create_booking(uuid, timestamptz, timestamptz, uuid, text),
  public.cancel_booking(uuid, text),
  public.reschedule_booking(uuid, uuid, timestamptz, timestamptz),
  public.request_booking_change(uuid, public.request_type, text, uuid, timestamptz, timestamptz),
  public.resolve_booking_request(uuid, boolean, text),
  public.record_payment(uuid, int, public.payment_kind, public.payment_method, timestamptz, text),
  public.mark_notifications_read(uuid[])
to authenticated;

-- 3) Privilégios de tabela (o RLS abaixo restringe as linhas)
grant select on public.settings, public.profiles, public.rooms, public.opening_hours, public.room_rates,
                public.professional_rates, public.bookings, public.payments, public.booking_requests,
                public.notifications, public.blocks, public.audit_log, public.notification_outbox,
                public.booking_financials
  to authenticated;
grant update on public.settings                to authenticated;
grant update (full_name, phone, registration_number, role, is_active) on public.profiles to authenticated;
grant insert, update, delete on public.rooms, public.opening_hours, public.blocks,
                                public.room_rates, public.professional_rates to authenticated;

-- 4) RLS
alter table public.settings            enable row level security;
alter table public.profiles            enable row level security;
alter table public.rooms               enable row level security;
alter table public.opening_hours       enable row level security;
alter table public.blocks              enable row level security;
alter table public.room_rates          enable row level security;
alter table public.professional_rates  enable row level security;
alter table public.bookings            enable row level security;
alter table public.payments            enable row level security;
alter table public.booking_requests    enable row level security;
alter table public.audit_log           enable row level security;
alter table public.notifications       enable row level security;
alter table public.notification_outbox enable row level security;

-- settings / rooms / opening_hours / room_rates: leitura para usuários ativos, escrita só admin
create policy settings_read  on public.settings for select to authenticated using (public.current_user_active());
create policy settings_admin on public.settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy rooms_read  on public.rooms for select to authenticated using (public.current_user_active());
create policy rooms_admin on public.rooms for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy hours_read  on public.opening_hours for select to authenticated using (public.current_user_active());
create policy hours_admin on public.opening_hours for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy room_rates_read  on public.room_rates for select to authenticated using (public.current_user_active());
create policy room_rates_admin on public.room_rates for all    to authenticated using (public.is_admin()) with check (public.is_admin());

-- blocks: só admin (motivo é interno; profissionais veem apenas "indisponível" via get_room_busy)
create policy blocks_admin on public.blocks for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- professional_rates: o profissional vê somente o próprio preço especial
create policy prof_rates_read  on public.professional_rates for select to authenticated
  using (public.is_admin() or (professional_id = auth.uid() and public.current_user_active()));
create policy prof_rates_admin on public.professional_rates for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- profiles: cada um vê/edita o próprio (o trigger bloqueia role/is_active/e-mail); admin vê/edita todos
create policy profiles_read   on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

-- bookings / payments / booking_requests: somente leitura direta
create policy bookings_read on public.bookings for select to authenticated
  using (public.is_admin() or (professional_id = auth.uid() and public.current_user_active()));

create policy payments_read on public.payments for select to authenticated
  using (public.is_admin() or (public.current_user_active()
         and exists (select 1 from public.bookings b where b.id = booking_id and b.professional_id = auth.uid())));

create policy requests_read on public.booking_requests for select to authenticated
  using (public.is_admin() or (requested_by = auth.uid() and public.current_user_active()));

-- audit_log e outbox: só admin lê; ninguém escreve diretamente (triggers/RPCs são security definer)
create policy audit_read  on public.audit_log           for select to authenticated using (public.is_admin());
create policy outbox_read on public.notification_outbox for select to authenticated using (public.is_admin());

-- notifications: cada um lê as próprias (marcar como lida via RPC)
create policy notifications_read on public.notifications for select to authenticated using (user_id = auth.uid());
