import { redirect } from 'next/navigation';
import { requireCtx } from '@/lib/auth';

export default async function Home() {
  const { profile } = await requireCtx();
  redirect(profile.role === 'admin' ? '/admin' : '/agenda');
}
