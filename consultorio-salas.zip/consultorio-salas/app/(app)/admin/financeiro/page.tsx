import Link from 'next/link';
import { requireAdmin } from '@/lib/auth';
import { Empty, PayBadge } from '@/components/badges';
import PaymentDialog from '@/components/PaymentDialog';
import { brl } from '@/lib/money';
import { addMonths, clampMonth, fmtDate, fmtDuration, fmtTime, monthLabel, toISO, ymd } from '@/lib/time';

type Row = any;
export default async function Finance({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { supabase } = await requireAdmin();
  const mes = clampMonth(sp.mes), from = `${mes}-01`, to = addMonths(from, 1);
  const fromI = toISO(from, 0), toI = toISO(to, 0);

  const [{ data: rooms }, { data: pros }, { data: bk }, { data: pays }, { data: hist }] = await Promise.all([
    supabase.from('rooms').select('id,name,color').order('sort_order'),
    supabase.from('profiles').select('id,full_name').order('full_name'),
    supabase.from('bookings').select('id,room_id,professional_id,starts_at,ends_at,status,amount_cents,hourly_rate_cents').gte('starts_at', fromI).lt('starts_at', toI).order('starts_at'),
    supabase.from('payments').select('amount_cents,kind').gte('paid_at', fromI).lt('paid_at', toI),
    supabase.from('bookings').select('starts_at,amount_cents').eq('status', 'confirmed').gte('starts_at', toISO(addMonths(from, -5), 0)).lt('starts_at', toI),
  ]);
  const ids = (bk ?? []).map((b: Row) => b.id);
  const { data: fin } = ids.length ? await supabase.from('booking_financials').select('booking_id,paid_cents,balance_cents,payment_status').in('booking_id', ids) : { data: [] as Row[] };
  const finMap = new Map((fin ?? []).map((f: Row) => [f.booking_id, f]));
  const proName = new Map((pros ?? []).map((p: Row) => [p.id, p.full_name]));
  const room = new Map((rooms ?? []).map((r: Row) => [r.id, r]));

  let rows: Row[] = (bk ?? []).map((b: Row) => ({ ...b, ...(finMap.get(b.id) ?? { paid_cents: 0, balance_cents: b.amount_cents, payment_status: 'pendente' }) }));
  if (sp.pro) rows = rows.filter((r) => r.professional_id === sp.pro);
  if (sp.sala) rows = rows.filter((r) => r.room_id === sp.sala);
  if (sp.situacao) rows = rows.filter((r) => r.payment_status === sp.situacao);

  const conf = rows.filter((r) => r.status === 'confirmed');
  const billed = conf.reduce((s, r) => s + r.amount_cents, 0);
  const paid = conf.reduce((s, r) => s + r.paid_cents, 0);
  const pending = conf.reduce((s, r) => s + Math.max(r.balance_cents, 0), 0);
  const received = (pays ?? []).reduce((s: number, p: Row) => s + (p.kind === 'payment' ? p.amount_cents : -p.amount_cents), 0);
  const toRefund = rows.filter((r) => r.payment_status === 'a_estornar').reduce((s, r) => s + r.paid_cents, 0);

  const group = (key: (r: Row) => string) => {
    const m = new Map<string, { n: number; min: number; billed: number; paid: number; open: number }>();
    for (const r of conf) {
      const k = key(r), g = m.get(k) ?? { n: 0, min: 0, billed: 0, paid: 0, open: 0 };
      g.n++; g.min += (new Date(r.ends_at).getTime() - new Date(r.starts_at).getTime()) / 60000;
      g.billed += r.amount_cents; g.paid += r.paid_cents; g.open += Math.max(r.balance_cents, 0); m.set(k, g);
    }
    return [...m.entries()];
  };
  const byPro = group((r) => proName.get(r.professional_id) ?? '—').sort((a, b) => b[1].billed - a[1].billed);
  const byRoom = group((r) => (room.get(r.room_id) as Row)?.name ?? '—');
  const byDay = group((r) => ymd(r.starts_at)).sort((a, b) => a[0].localeCompare(b[0]));
  const byMonth = new Map<string, number>();
  for (const b of hist ?? []) { const k = ymd(b.starts_at).slice(0, 7); byMonth.set(k, (byMonth.get(k) ?? 0) + b.amount_cents); }

  const link = (m: string) => `/admin/financeiro?mes=${m}${sp.pro ? `&pro=${sp.pro}` : ''}${sp.sala ? `&sala=${sp.sala}` : ''}${sp.situacao ? `&situacao=${sp.situacao}` : ''}`;
  const Stat = ({ l, v, h }: { l: string; v: string; h?: string }) => <div className="card p-4"><p className="text-sm text-mute">{l}</p><p className="mt-1 text-xl font-semibold">{v}</p>{h && <p className="text-xs text-mute">{h}</p>}</div>;
  const Group = ({ title, data }: { title: string; data: [string, { n: number; min: number; billed: number; paid: number; open: number }][] }) => (
    <section className="grid gap-2"><h2 className="font-semibold">{title}</h2>
      <div className="card overflow-x-auto">{!data.length ? <Empty title="Sem reservas no período." /> : (
        <table className="w-full min-w-[480px]"><thead><tr className="border-b border-line"><th className="th" /><th className="th">Reservas</th><th className="th">Horas</th><th className="th">Faturado</th><th className="th">Pago</th><th className="th">Em aberto</th></tr></thead>
          <tbody className="divide-y divide-line">{data.map(([k, g]) => <tr key={k}><td className="td font-medium">{/^\d{4}-/.test(k) ? fmtDate(k) : k}</td><td className="td">{g.n}</td><td className="td">{fmtDuration(g.min)}</td><td className="td">{brl(g.billed)}</td><td className="td">{brl(g.paid)}</td><td className="td">{brl(g.open)}</td></tr>)}</tbody></table>)}</div></section>
  );

  return (
    <div className="grid gap-6">
      <div className="flex flex-wrap items-center gap-2">
        <h1 className="page-title mr-auto">Financeiro</h1>
        <Link href={link(addMonths(from, -1).slice(0, 7))} className="btn-ghost" aria-label="Mês anterior">‹</Link>
        <span className="min-w-36 text-center text-sm font-medium capitalize">{monthLabel(from)}</span>
        <Link href={link(addMonths(from, 1).slice(0, 7))} className="btn-ghost" aria-label="Próximo mês">›</Link>
        <a href={`/admin/financeiro/export?mes=${mes}${sp.pro ? `&pro=${sp.pro}` : ''}${sp.sala ? `&sala=${sp.sala}` : ''}${sp.situacao ? `&situacao=${sp.situacao}` : ''}`} className="btn-primary">Exportar CSV</a>
      </div>

      <form method="get" className="card grid grid-cols-2 gap-3 p-4 md:grid-cols-4">
        <input type="hidden" name="mes" value={mes} />
        <div><label className="label" htmlFor="x-pro">Profissional</label><select id="x-pro" name="pro" defaultValue={sp.pro ?? ''} className="input"><option value="">Todos</option>{(pros ?? []).map((p: Row) => <option key={p.id} value={p.id}>{p.full_name}</option>)}</select></div>
        <div><label className="label" htmlFor="x-sala">Sala</label><select id="x-sala" name="sala" defaultValue={sp.sala ?? ''} className="input"><option value="">Todas</option>{(rooms ?? []).map((r: Row) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
        <div><label className="label" htmlFor="x-sit">Situação</label><select id="x-sit" name="situacao" defaultValue={sp.situacao ?? ''} className="input"><option value="">Todas</option><option value="pendente">Pendente</option><option value="parcial">Parcialmente pago</option><option value="pago">Pago</option><option value="a_estornar">A estornar</option><option value="cancelada">Cancelada</option></select></div>
        <div className="flex items-end"><button className="btn-primary w-full">Filtrar</button></div>
      </form>

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat l="Faturado no mês" v={brl(billed)} h={`${conf.length} reserva(s) confirmadas`} />
        <Stat l="Pago (dessas reservas)" v={brl(paid)} />
        <Stat l="Em aberto" v={brl(pending)} />
        <Stat l="Recebido no mês" v={brl(received)} h={toRefund ? `${brl(toRefund)} a estornar` : 'Pelo dia do pagamento'} />
      </section>

      <Group title="Por profissional" data={byPro} />
      <Group title="Por sala" data={byRoom} />
      <Group title="Faturamento diário" data={byDay} />

      <section className="grid gap-2"><h2 className="font-semibold">Faturamento mensal (últimos 6 meses)</h2>
        <div className="card overflow-x-auto"><table className="w-full"><tbody className="divide-y divide-line">{[...byMonth.entries()].sort((a, b) => b[0].localeCompare(a[0])).map(([k, v]) => <tr key={k}><td className="td capitalize">{monthLabel(`${k}-01`)}</td><td className="td text-right font-medium">{brl(v)}</td></tr>)}</tbody></table></div></section>

      <section className="grid gap-2"><h2 className="font-semibold">Reservas e pagamentos</h2>
        <div className="card overflow-x-auto">{!rows.length ? <Empty title="Nenhuma reserva neste período." /> : (
          <table className="w-full min-w-[760px]"><thead><tr className="border-b border-line"><th className="th">Data</th><th className="th">Profissional</th><th className="th">Sala</th><th className="th">Valor</th><th className="th">Pago</th><th className="th">Situação</th><th /></tr></thead>
            <tbody className="divide-y divide-line">{rows.map((r) => {
              const label = `${fmtDate(ymd(r.starts_at))} · ${fmtTime(r.starts_at)}–${fmtTime(r.ends_at)} · ${proName.get(r.professional_id)} · ${(room.get(r.room_id) as Row)?.name} · ${brl(r.amount_cents)}`;
              return <tr key={r.id}><td className="td">{fmtDate(ymd(r.starts_at))}<br /><span className="text-xs text-mute">{fmtTime(r.starts_at)}–{fmtTime(r.ends_at)}</span></td>
                <td className="td">{proName.get(r.professional_id)}</td><td className="td">{(room.get(r.room_id) as Row)?.name}</td>
                <td className={`td ${r.status === 'cancelled' ? 'text-mute line-through' : ''}`}>{brl(r.amount_cents)}</td><td className="td">{brl(r.paid_cents)}</td>
                <td className="td"><PayBadge status={r.payment_status} /></td>
                <td className="td text-right"><PaymentDialog bookingId={r.id} balanceCents={r.balance_cents} paidCents={r.paid_cents} status={r.payment_status} label={label} /></td></tr>;
            })}</tbody></table>)}</div></section>
    </div>
  );
}
