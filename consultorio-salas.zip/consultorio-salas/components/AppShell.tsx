'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, type ReactNode } from 'react';
import { Bell, CalendarDays, DoorOpen, History, Inbox, LayoutDashboard, ListChecks, LogOut, Menu, UserRound, Users, Wallet, CreditCard, X } from 'lucide-react';
import { logoutAction } from '@/app/actions/auth';

type Item = { href: string; label: string; icon: any; exact?: boolean; primary?: boolean; badge?: 'unread' | 'pending' };
const ADMIN: Item[] = [
  { href: '/admin', label: 'Painel', icon: LayoutDashboard, exact: true, primary: true },
  { href: '/agenda', label: 'Agenda', icon: CalendarDays, primary: true },
  { href: '/admin/reservas', label: 'Reservas', icon: ListChecks, primary: true },
  { href: '/admin/solicitacoes', label: 'Solicitações', icon: Inbox, badge: 'pending', primary: true },
  { href: '/admin/profissionais', label: 'Profissionais', icon: Users },
  { href: '/admin/financeiro', label: 'Financeiro', icon: Wallet },
  { href: '/admin/salas', label: 'Salas', icon: DoorOpen },
  { href: '/admin/historico', label: 'Histórico', icon: History },
  { href: '/notificacoes', label: 'Notificações', icon: Bell, badge: 'unread' },
  { href: '/perfil', label: 'Meu perfil', icon: UserRound },
];
const PRO: Item[] = [
  { href: '/agenda', label: 'Agenda', icon: CalendarDays, primary: true },
  { href: '/reservas', label: 'Minhas reservas', icon: ListChecks, primary: true },
  { href: '/pagamentos', label: 'Pagamentos', icon: CreditCard, primary: true },
  { href: '/notificacoes', label: 'Notificações', icon: Bell, badge: 'unread', primary: true },
  { href: '/perfil', label: 'Meu perfil', icon: UserRound },
];

function Logo() {
  return (
    <span className="flex items-center gap-2.5">
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden>
        <rect x="2" y="3" width="14" height="22" rx="3" fill="#1f6b57" />
        <rect x="12" y="3" width="14" height="22" rx="3" fill="#3b6fd4" fillOpacity=".85" />
      </svg>
      <span className="text-[15px] font-semibold tracking-tight">Agenda de Salas</span>
    </span>
  );
}

export default function AppShell({ role, name, unread, pending, children }: { role: 'admin' | 'professional'; name: string; unread: number; pending: number; children: ReactNode }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const items = role === 'admin' ? ADMIN : PRO;
  const active = (i: Item) => (i.exact ? path === i.href : path === i.href || path.startsWith(i.href + '/'));
  const count = (i: Item) => (i.badge === 'unread' ? unread : i.badge === 'pending' ? pending : 0);

  const link = (i: Item, mobile = false) => {
    const Icon = i.icon, n = count(i), on = active(i);
    return (
      <Link key={i.href} href={i.href} onClick={() => setOpen(false)} aria-current={on ? 'page' : undefined}
        className={mobile
          ? `relative flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] ${on ? 'font-semibold text-brand-700' : 'text-mute'}`
          : `flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${on ? 'bg-brand-50 font-medium text-brand-700' : 'text-ink/80 hover:bg-canvas'}`}>
        <Icon size={mobile ? 20 : 18} />
        <span>{mobile ? i.label.replace('Minhas ', '') : i.label}</span>
        {n > 0 && <span className={`rounded-full bg-brand-600 px-1.5 text-[11px] font-semibold leading-5 text-white ${mobile ? 'absolute right-[22%] top-1' : 'ml-auto'}`}>{n}</span>}
      </Link>
    );
  };

  return (
    <div className="min-h-screen md:pl-60">
      <aside className="fixed inset-y-0 left-0 hidden w-60 flex-col border-r border-line bg-white p-3 md:flex">
        <div className="px-2 pb-5 pt-3"><Logo /></div>
        <nav className="flex flex-1 flex-col gap-0.5 overflow-y-auto">{items.map((i) => link(i))}</nav>
        <div className="mt-2 border-t border-line px-2 pt-3">
          <p className="truncate text-sm font-medium">{name}</p>
          <p className="mb-2 text-xs text-mute">{role === 'admin' ? 'Administração' : 'Profissional'}</p>
          <form action={logoutAction}><button className="btn-ghost btn-sm w-full"><LogOut size={14} /> Sair</button></form>
        </div>
      </aside>

      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-line bg-white/95 px-4 py-3 backdrop-blur md:hidden">
        <Logo />
        <button onClick={() => setOpen(true)} aria-label="Abrir menu" className="rounded-md p-1.5 hover:bg-canvas"><Menu size={20} /></button>
      </header>

      {open && (
        <div className="fixed inset-0 z-50 bg-ink/40 md:hidden" onClick={() => setOpen(false)}>
          <div className="animate-pop absolute inset-x-0 bottom-0 rounded-t-2xl bg-white p-4" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2 flex items-center justify-between"><p className="text-sm font-medium">{name}</p><button onClick={() => setOpen(false)} aria-label="Fechar"><X size={18} /></button></div>
            <nav className="grid gap-0.5">{items.map((i) => link(i))}</nav>
            <form action={logoutAction} className="mt-3"><button className="btn-ghost w-full"><LogOut size={16} /> Sair</button></form>
          </div>
        </div>
      )}

      <main className="mx-auto max-w-6xl px-4 pb-28 pt-5 md:px-8 md:pb-10 md:pt-8">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-30 flex border-t border-line bg-white md:hidden" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {items.filter((i) => i.primary).slice(0, 4).map((i) => link(i, true))}
        <button onClick={() => setOpen(true)} className="flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] text-mute"><Menu size={20} />Mais</button>
      </nav>
    </div>
  );
}
