'use server';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { failText, type Res } from '@/lib/errors';

const site = () => (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/$/, '');

export async function loginAction(fd: FormData): Promise<Res> {
  const email = String(fd.get('email') || '').trim().toLowerCase();
  const password = String(fd.get('password') || '');
  if (!email || !password) return failText('Informe e-mail e senha.');
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return failText('E-mail ou senha incorretos.');
  const { data: { user } } = await supabase.auth.getUser();
  const { data: p } = await supabase.from('profiles').select('is_active').eq('id', user!.id).single();
  if (!p?.is_active) {
    await supabase.auth.signOut();
    return failText('Sua conta está suspensa. Fale com a administração.');
  }
  redirect('/');
}

export async function logoutAction() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect('/login');
}

export async function requestResetAction(fd: FormData): Promise<Res> {
  const email = String(fd.get('email') || '').trim().toLowerCase();
  if (!email) return failText('Informe seu e-mail.');
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${site()}/auth/callback?next=/redefinir-senha` });
  return { ok: true }; // resposta igual exista ou não a conta (não revela quem tem cadastro)
}

export async function updatePasswordAction(fd: FormData): Promise<Res> {
  const password = String(fd.get('password') || '');
  const confirm = String(fd.get('confirm') || '');
  if (password.length < 8) return failText('A senha precisa ter ao menos 8 caracteres.');
  if (password !== confirm) return failText('As senhas não conferem.');
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password });
  if (error) return failText('Não foi possível alterar a senha. Abra o link do e-mail novamente.');
  return { ok: true };
}
