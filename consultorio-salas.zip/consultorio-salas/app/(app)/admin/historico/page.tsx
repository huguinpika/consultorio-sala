import { requireAdmin } from '@/lib/auth';
import { Badge, Empty } from '@/components/badges';
import { ACTION_LABEL, METHOD, TABLE_LABEL } from '@/lib/labels';
import { brl } from '@/lib/money';
import { fmtDateTime } from '@/lib/time';

const FIELD: Record<string, string> = {
  status: 'situação', starts_at: 'início', ends_at: 'fim', room_id: 'sala', amount_cents: 'valor', hourly_rate_cents: 'valor da hora', notes: 'observação',
  cancel_reason: 'motivo', full_name: 'nome', phone: 'telefone', is_active: 'ativo', role: 'perfil', name: 'nome', color: 'cor', reason: 'motivo',
  slot_minutes: 'intervalo (min)', min_duration_minutes: 'duração mínima', max_duration_minutes: 'duração máxima', cancellation_notice_hours: 'prazo de cancelamento (h)', registration_number: 'registro',
};
const IGNORE = new Set(['updated_at', 'updated_by', 'created_at']);

function show(k: string, v: any): string {
  if (v === null || v === undefined || v === '') return '—';
  if (k.endsWith('_cents')) return brl(v);
  if (k.endsWith('_at') && typeof v === 'string' && v.includes('T')) return fmtDateTime(v);
  if (typeof v === 'boolean') return v ? 'sim' : 'não';
  return String(v).length > 40 ? String(v).slice(0, 40) + '…' : String(v);
}
function summarize(r: any): string {
  const n = r.new_data ?? {}, o = r.old_data ?? {};
  if (r.action === 'UPDATE') {
    const ch = Object.keys(n).filter((k) => !IGNORE.has(k) && JSON.stringify(n[k]) !== JSON.stringify(o[k])).slice(0, 5);
    return ch.map((k) => `${FIELD[k] ?? k}: ${show(k, o[k])} → ${show(k, n[k])}`).join(' · ') || 'Sem mudanças relevantes';
  }
  const d = r.action === 'INSERT' ? n : o;
  if (r.table_name === 'bookings') return `${fmtDateTime(d.starts_at)}–${fmtDateTime(d.ends_at).slice(11)} · ${brl(d.amount_cents)}`;
  if (r.table_name === 'payments') return `${d.kind === 'refund' ? 'Estorno' : 'Pagamento'} ${brl(d.amount_cents)} · ${METHOD[d.method] ?? d.method}`;
  if (r.table_name.endsWith('_rates')) return `${brl(d.hourly_rate_cents)}/h`;
  return d.full_name ?? d.name ?? d.reason ?? d.type ?? '';
}

export default async function History({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { supabase } = await requireAdmin();
  let q = supabase.from('audit_log').select('*').order('created_at', { ascending: false }).limit(200);
  if (sp.tabela) q = q.eq('table_name', sp.tabela);
  const [{ data }, { data: pros }] = await Promise.all([q, supabase.from('profiles').select('id,full_name')]);
  const who = new Map((pros ?? []).map((p: any) => [p.id, p.full_name]));
  return (
    <div className="grid gap-5">
      <h1 className="page-title">Histórico de alterações</h1>
      <form method="get" className="flex flex-wrap items-end gap-3">
        <div><label className="label" htmlFor="h-t">Tipo de registro</label>
          <select id="h-t" name="tabela" defaultValue={sp.tabela ?? ''} className="input"><option value="">Todos</option>{Object.entries(TABLE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
        <button className="btn-primary">Filtrar</button>
      </form>
      <div className="card overflow-x-auto">
        {!data?.length ? <Empty title="Nada registrado ainda." /> : (
          <table className="w-full min-w-[680px]"><thead><tr className="border-b border-line"><th className="th">Quando</th><th className="th">Quem</th><th className="th">O quê</th><th className="th">Detalhes</th></tr></thead>
            <tbody className="divide-y divide-line">{data.map((r: any) => (
              <tr key={r.id}><td className="td whitespace-nowrap">{fmtDateTime(r.created_at)}</td><td className="td">{r.actor_id ? who.get(r.actor_id) ?? '—' : 'Sistema'}</td>
                <td className="td"><Badge tone={r.action === 'DELETE' ? 'red' : r.action === 'INSERT' ? 'green' : 'blue'}>{ACTION_LABEL[r.action]}</Badge> {TABLE_LABEL[r.table_name] ?? r.table_name}</td>
                <td className="td text-mute">{summarize(r)}</td></tr>))}</tbody></table>
        )}
      </div>
    </div>
  );
}
