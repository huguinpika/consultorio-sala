import BookingList, { attachFinancials, loadBookingContext } from '@/components/BookingList';
import { requireAdmin } from '@/lib/auth';
import { toISO } from '@/lib/time';

export default async function AllBookings({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { supabase } = await requireAdmin();
  const ctx = await loadBookingContext(supabase);
  const { data: pros } = await supabase.from('profiles').select('id,full_name').order('full_name');

  let q = supabase.from('bookings')
    .select('*, room:rooms(name,color), professional:profiles!bookings_professional_id_fkey(full_name)')
    .order('starts_at', { ascending: false }).limit(200);
  const status = sp.status ?? 'confirmed';
  if (status !== 'all') q = q.eq('status', status);
  if (sp.pro) q = q.eq('professional_id', sp.pro);
  if (sp.sala) q = q.eq('room_id', sp.sala);
  if (sp.de) q = q.gte('starts_at', toISO(sp.de, 0));
  if (sp.ate) q = q.lt('starts_at', toISO(sp.ate, 1440));
  const { data } = await q;
  const items = await attachFinancials(supabase, data ?? []);

  return (
    <div className="grid gap-5">
      <h1 className="page-title">Reservas</h1>
      <form className="card grid grid-cols-2 gap-3 p-4 md:grid-cols-6" method="get">
        <div><label className="label" htmlFor="f-status">Situação</label>
          <select id="f-status" name="status" defaultValue={status} className="input"><option value="confirmed">Confirmadas</option><option value="cancelled">Canceladas</option><option value="all">Todas</option></select></div>
        <div><label className="label" htmlFor="f-pro">Profissional</label>
          <select id="f-pro" name="pro" defaultValue={sp.pro ?? ''} className="input"><option value="">Todos</option>{(pros ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.full_name}</option>)}</select></div>
        <div><label className="label" htmlFor="f-sala">Sala</label>
          <select id="f-sala" name="sala" defaultValue={sp.sala ?? ''} className="input"><option value="">Todas</option>{ctx.rooms.map((r: any) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
        <div><label className="label" htmlFor="f-de">De</label><input id="f-de" type="date" name="de" defaultValue={sp.de ?? ''} className="input" /></div>
        <div><label className="label" htmlFor="f-ate">Até</label><input id="f-ate" type="date" name="ate" defaultValue={sp.ate ?? ''} className="input" /></div>
        <div className="flex items-end"><button className="btn-primary w-full">Filtrar</button></div>
      </form>
      <BookingList items={items} rooms={ctx.rooms} hours={ctx.hours} settings={ctx.settings} isAdmin empty="Nenhuma reserva encontrada com esses filtros." />
    </div>
  );
}
