import './globals.css';
import type { Metadata, Viewport } from 'next';
import { Figtree } from 'next/font/google';
import { ToastProvider } from '@/components/ui';

const font = Figtree({ subsets: ['latin'], variable: '--font-sans', display: 'swap' });

export const metadata: Metadata = { title: 'Agenda de Salas', description: 'Agendamento e locação de salas do consultório.' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#1f6b57' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={font.variable}>
      <body className="font-sans"><ToastProvider>{children}</ToastProvider></body>
    </html>
  );
}
