'use client';
import Link from 'next/link';
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import TimeGrid, { type Col, type Ev } from './TimeGrid';
import BookingDialog from './BookingDialog';
import BookingActions from './BookingActions';
import { Modal } from '@/components/ui';
import { PayBadge, RoomDot } from '@/components/badges';
import { brl } from '@/lib/money';
import {
  addDays, addMonths, daysInMonth, fmtDate, fmtDateLong, fmtTime, monthLabel, monthStart, startOfWeek, todayYmd, weekday, WEEKDAYS_SHORT, ymd, MONTHS,
} from '@/lib/time';

type Room = { id: string; name: string; color: string };
type View = 'dia' | 'semana' | 'mes';

export default function Calendar({ view, date, roomId, rooms, hours, settings, events, professionals, isAdmin }: {
  view: View; date: string; roomId: string; rooms: Room[]; hours: any[]; settings: any; events: Ev[];
  professionals: { id: string; name: string }[]; isAdmin: boolean;
}) {
  const [dlg, setDlg] = useState<{ roomId: string; date: string; start?: number | null } | null>(null);
  const [ev, setEv] = useState<Ev | null>(null);
  const href = (p: { view?: View; date?: string; sala?: string }) => `/agenda?view=${p.view ?? view}&date=${p.date ?? date}&sala=${p.sala ?? roomId}`;
  const step = view === 'dia' ? 1 : 7;
  const prev = view === 'mes' ? addMonths(date, -1) : addDays(date, -step);
  const next = view === 'mes' ? addMonths(date, 1) : addDays(date, step);
  const room = (id: string) => rooms.find((r) => r.id === id);

  const wk = startOfWeek(date);
  const title = view === 'dia' ? fmtDateLong(date) : view === 'semana' ? `${fmtDate(wk).slice(0, 5)} a ${fmtDate(addDays(wk, 6)).slice(0, 5)}` : monthLabel(date);

  const columns: Col[] = view === 'dia'
    ? rooms.map((r) => ({ key: r.id, label: r.name, date, roomId: r.id, color: r.color }))
    : Array.from({ length: 7 }, (_, i) => {
        const d = addDays(wk, i);
        return { key: d, label: WEEKDAYS_SHORT[weekday(d)], sub: d.slice(8) + '/' + d.slice(5, 7), date: d, roomId, color: room(roomId)?.color ?? '#1f6b57' };
      });

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1">
          <Link href={href({ date: prev })} className="btn-ghost px-2" aria-label="Anterior"><ChevronLeft size={16} /></Link>
          <Link href={href({ date: todayYmd() })} className="btn-ghost">Hoje</Link>
          <Link href={href({ date: next })} className="btn-ghost px-2" aria-label="Próximo"><ChevronRight size={16} /></Link>
        </div>
        <h2 className="mr-auto text-base font-semibold capitalize sm:text-lg">{title}</h2>
        <div className="flex rounded-lg border border-line bg-white p-0.5 text-sm">
          {(['dia', 'semana', 'mes'] as View[]).map((v) => (
            <Link key={v} href={href({ view: v })} aria-current={v === view ? 'page' : undefined}
              className={`rounded-md px-3 py-1.5 ${v === view ? 'bg-brand-600 text-white' : 'text-ink/80 hover:bg-canvas'}`}>{v === 'mes' ? 'Mês' : v === 'dia' ? 'Dia' : 'Semana'}</Link>
          ))}
        </div>
        <button className="btn-primary" onClick={() => setDlg({ roomId: view === 'dia' ? rooms[0]?.id ?? '' : roomId, date: date < todayYmd() ? todayYmd() : date })}>
          <Plus size={16} /> Reservar horário
        </button>
      </div>

      {view !== 'dia' && (
        <div className="mb-3 flex gap-2">
          {rooms.map((r) => (
            <Link key={r.id} href={href({ sala: r.id })} aria-current={r.id === roomId ? 'page' : undefined}
              className={`flex items-center gap-2 rounded-full border px-3 py-1 text-sm ${r.id === roomId ? 'border-ink/30 bg-white font-medium' : 'border-line text-mute hover:bg-white'}`}>
              <span className="h-2.5 w-2.5 rounded-sm" style={{ background: r.color }} />{r.name}
            </Link>
          ))}
        </div>
      )}

      <div className="card overflow-hidden">
        {view === 'mes' ? (
          <MonthGrid date={date} rooms={rooms} events={events} href={href} />
        ) : (
          <TimeGrid columns={columns} hours={hours} events={events} slot={settings.slot_minutes} minWidth={view === 'semana' ? 680 : 0}
            onSlot={(c, s) => setDlg({ roomId: c.roomId, date: c.date, start: s })} onEvent={setEv} />
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-mute">
        {rooms.map((r) => <RoomDot key={r.id} color={r.color} name={r.name} />)}
        <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-600" /> pendente</span>
        <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-sky-600" /> parcial</span>
        <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-600" /> pago</span>
      </div>

      {dlg && (
        <BookingDialog open onClose={() => setDlg(null)} rooms={rooms} hours={hours} settings={settings} professionals={professionals} isAdmin={isAdmin} initial={dlg} />
      )}

      <Modal open={!!ev} onClose={() => setEv(null)} title="Reserva">
        {ev && (
          <div className="grid gap-3 text-sm">
            <p className="flex items-center justify-between gap-2">
              <RoomDot color={room(ev.roomId)?.color ?? '#999'} name={room(ev.roomId)?.name ?? ''} />
              {ev.pay && <PayBadge status={ev.pay} />}
            </p>
            <p className="text-base font-semibold">{fmtDate(ymd(ev.start))} · {fmtTime(ev.start)} às {fmtTime(ev.end)}</p>
            {isAdmin && ev.professionalName && <p><span className="text-mute">Profissional: </span>{ev.professionalName}</p>}
            {ev.amount !== undefined && <p><span className="text-mute">Valor: </span>{brl(ev.amount)}</p>}
            {ev.notes && <p><span className="text-mute">Observação: </span>{ev.notes}</p>}
            {ev.id && (
              <BookingActions booking={{ id: ev.id, roomId: ev.roomId, start: ev.start, end: ev.end, status: ev.status ?? 'confirmed' }}
                rooms={rooms} hours={hours} settings={settings} isAdmin={isAdmin} />
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

function MonthGrid({ date, rooms, events, href }: { date: string; rooms: Room[]; events: Ev[]; href: (p: { view?: View; date?: string }) => string }) {
  const first = monthStart(date), gridStart = startOfWeek(first);
  const lead = (weekday(first) + 6) % 7, weeks = Math.ceil((lead + daysInMonth(first)) / 7);
  const today = todayYmd();
  const counts: Record<string, Record<string, number>> = {};
  for (const e of events) {
    if (e.kind === 'block') continue;
    const d = ymd(e.start);
    ((counts[d] ??= {})[e.roomId] ??= 0);
    counts[d][e.roomId]++;
  }
  return (
    <div>
      <div className="grid grid-cols-7 border-b border-line text-center text-xs text-mute">
        {[1, 2, 3, 4, 5, 6, 0].map((w) => <div key={w} className="py-2">{WEEKDAYS_SHORT[w]}</div>)}
      </div>
      <div className="grid grid-cols-7">
        {Array.from({ length: weeks * 7 }, (_, i) => {
          const d = addDays(gridStart, i), inMonth = d.slice(0, 7) === first.slice(0, 7), c = counts[d] ?? {};
          return (
            <Link key={d} href={href({ view: 'dia', date: d })} aria-label={fmtDateLong(d)}
              className={`min-h-[72px] border-b border-l border-line p-1.5 transition hover:bg-brand-50 sm:min-h-[92px] ${inMonth ? '' : 'bg-canvas/70 text-mute/60'}`}>
              <span className={`inline-flex h-6 min-w-6 items-center justify-center rounded-full px-1 text-xs ${d === today ? 'bg-brand-600 font-semibold text-white' : ''}`}>{Number(d.slice(8))}</span>
              <div className="mt-1 flex flex-wrap gap-1">
                {rooms.map((r) => c[r.id] ? (
                  <span key={r.id} className="rounded px-1.5 text-[11px] font-medium" style={{ background: `${r.color}26`, color: r.color }}>{c[r.id]}</span>
                ) : null)}
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
export { MONTHS };
