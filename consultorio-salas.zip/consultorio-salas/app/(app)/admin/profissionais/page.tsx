import Link from 'next/link';
import { requireAdmin } from '@/lib/auth';
import { Badge, Empty } from '@/components/badges';
import { ActionForm } from '@/components/ui';
import { createProfessionalAction } from '@/app/actions/admin';

export default async function Professionals() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from('profiles').select('*').order('full_name');
  return (
    <div className="grid gap-6">
      <h1 className="page-title">Profissionais</h1>
      <details className="card group p-4">
        <summary className="cursor-pointer text-sm font-medium">Cadastrar novo profissional</summary>
        <ActionForm action={createProfessionalAction} success="Conta criada. Passe o e-mail e a senha provisória ao profissional." reset submit="Criar conta" className="mt-4 grid gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="n-name">Nome completo</label><input id="n-name" name="full_name" required className="input" /></div>
          <div><label className="label" htmlFor="n-email">E-mail (será o login)</label><input id="n-email" name="email" type="email" required className="input" /></div>
          <div><label className="label" htmlFor="n-phone">Telefone</label><input id="n-phone" name="phone" inputMode="tel" className="input" /></div>
          <div><label className="label" htmlFor="n-reg">Registro profissional (CRP)</label><input id="n-reg" name="registration_number" className="input" /></div>
          <div className="sm:col-span-2"><label className="label" htmlFor="n-pw">Senha provisória (mín. 8 caracteres)</label><input id="n-pw" name="password" type="text" minLength={8} required autoComplete="off" className="input" />
            <p className="mt-1 text-xs text-mute">O profissional pode trocá-la em “Meu perfil” ou usar “Esqueci minha senha”.</p></div>
        </ActionForm>
      </details>
      <div className="card overflow-x-auto">
        {!data?.length ? <Empty title="Nenhum profissional cadastrado." /> : (
          <table className="w-full min-w-[560px]"><thead><tr className="border-b border-line"><th className="th">Nome</th><th className="th">E-mail</th><th className="th">Telefone</th><th className="th">Situação</th><th /></tr></thead>
            <tbody className="divide-y divide-line">{data.map((p: any) => (
              <tr key={p.id}><td className="td font-medium">{p.full_name}{p.role === 'admin' && <span className="ml-2"><Badge tone="blue">Administração</Badge></span>}</td>
                <td className="td">{p.email}</td><td className="td">{p.phone ?? '—'}</td>
                <td className="td">{p.is_active ? <Badge tone="green">Ativo</Badge> : <Badge tone="red">Suspenso</Badge>}</td>
                <td className="td text-right"><Link href={`/admin/profissionais/${p.id}`} className="btn-ghost btn-sm">Gerenciar</Link></td></tr>))}</tbody></table>
        )}
      </div>
    </div>
  );
}
