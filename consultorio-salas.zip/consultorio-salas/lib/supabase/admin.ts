import 'server-only';
import { createClient } from '@supabase/supabase-js';

// Cliente com poderes totais (chave service_role). Use SOMENTE em Server Actions já protegidas por requireAdmin().
export function createAdminClient() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
