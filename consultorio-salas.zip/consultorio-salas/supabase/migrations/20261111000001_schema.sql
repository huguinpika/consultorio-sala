-- =====================================================================
-- 0001 · ESQUEMA: extensões, tipos, tabelas, constraints e índices
-- Valores monetários sempre em CENTAVOS (inteiro). Datas em UTC (timestamptz);
-- a exibição em horário de Brasília é feita pelo app e pelas funções.
-- =====================================================================

create extension if not exists btree_gist;

create type public.user_role      as enum ('admin', 'professional');
create type public.booking_status as enum ('confirmed', 'cancelled');
create type public.request_type   as enum ('cancel', 'change');
create type public.request_status as enum ('pending', 'approved', 'rejected');
create type public.payment_kind   as enum ('payment', 'refund');
create type public.payment_method as enum ('pix', 'dinheiro', 'cartao', 'transferencia', 'outro');

-- Configurações globais (linha única) ---------------------------------
create table public.settings (
  id                        boolean primary key default true check (id),
  timezone                  text    not null default 'America/Sao_Paulo',
  slot_minutes              int     not null default 60 check (slot_minutes in (30, 60)), -- 30 = meia hora habilitada
  min_duration_minutes      int     not null default 60 check (min_duration_minutes > 0),
  max_duration_minutes      int     not null default 480,
  cancellation_notice_hours int     not null default 24 check (cancellation_notice_hours >= 0),
  updated_at                timestamptz not null default now(),
  check (max_duration_minutes >= min_duration_minutes)
);

-- Perfis (1 para 1 com auth.users) ------------------------------------
create table public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,
  role                public.user_role not null default 'professional',
  full_name           text not null check (length(trim(full_name)) > 0),
  email               text not null,
  phone               text,
  registration_number text,                       -- ex.: CRP (opcional)
  is_active           boolean not null default true,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create unique index profiles_email_key on public.profiles (lower(email));

-- Salas ---------------------------------------------------------------
create table public.rooms (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  description text,
  color       text not null default '#2563eb' check (color ~ '^#[0-9a-fA-F]{6}$'),
  is_active   boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Horários de funcionamento (vários intervalos por dia; 0 = domingo) ---
create table public.opening_hours (
  id        uuid primary key default gen_random_uuid(),
  room_id   uuid not null references public.rooms (id) on delete cascade,
  weekday   smallint not null check (weekday between 0 and 6),
  opens_at  time not null,
  closes_at time not null,
  check (opens_at < closes_at and closes_at <= time '24:00')
);
create index opening_hours_room_day_idx on public.opening_hours (room_id, weekday);

-- Bloqueios (room_id nulo = vale para todas as salas) -----------------
create table public.blocks (
  id         uuid primary key default gen_random_uuid(),
  room_id    uuid references public.rooms (id) on delete cascade,
  starts_at  timestamptz not null,
  ends_at    timestamptz not null,
  reason     text,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);
create index blocks_range_idx on public.blocks using gist (tstzrange(starts_at, ends_at));

-- Tarifas por hora, com vigência (preserva o histórico de valores) -----
create table public.room_rates (
  id                uuid primary key default gen_random_uuid(),
  room_id           uuid not null references public.rooms (id) on delete cascade,
  hourly_rate_cents int not null check (hourly_rate_cents >= 0),
  valid_from        timestamptz not null default now(),
  created_by        uuid references public.profiles (id) on delete set null,
  created_at        timestamptz not null default now()
);
create index room_rates_lookup_idx on public.room_rates (room_id, valid_from desc);

-- Preço especial por profissional (room_id nulo = todas as salas) ------
create table public.professional_rates (
  id                uuid primary key default gen_random_uuid(),
  professional_id   uuid not null references public.profiles (id) on delete cascade,
  room_id           uuid references public.rooms (id) on delete cascade,
  hourly_rate_cents int not null check (hourly_rate_cents >= 0),
  valid_from        timestamptz not null default now(),
  created_by        uuid references public.profiles (id) on delete set null,
  created_at        timestamptz not null default now()
);
create index professional_rates_lookup_idx on public.professional_rates (professional_id, room_id, valid_from desc);

-- Reservas ------------------------------------------------------------
create table public.bookings (
  id                uuid primary key default gen_random_uuid(),
  room_id           uuid not null references public.rooms (id) on delete restrict,
  professional_id   uuid not null references public.profiles (id) on delete restrict,
  starts_at         timestamptz not null,
  ends_at           timestamptz not null,
  status            public.booking_status not null default 'confirmed',
  hourly_rate_cents int not null check (hourly_rate_cents >= 0),  -- valor/hora "congelado" na reserva
  amount_cents      int not null check (amount_cents >= 0),       -- duração (h) × valor/hora
  notes             text,
  created_by        uuid references public.profiles (id) on delete set null,
  updated_by        uuid references public.profiles (id) on delete set null,
  cancelled_at      timestamptz,
  cancelled_by      uuid references public.profiles (id) on delete set null,
  cancel_reason     text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  check (ends_at > starts_at),
  check ((status = 'cancelled') = (cancelled_at is not null)),
  -- GARANTIA DE INTEGRIDADE: o próprio PostgreSQL impede sobreposição na mesma sala,
  -- mesmo com duas pessoas reservando ao mesmo tempo. Reservas canceladas não contam.
  constraint bookings_no_overlap exclude using gist (
    room_id with =,
    tstzrange(starts_at, ends_at) with &&
  ) where (status = 'confirmed')
);
create index bookings_professional_idx on public.bookings (professional_id, starts_at desc);
create index bookings_room_time_idx    on public.bookings (room_id, starts_at);
create index bookings_status_idx       on public.bookings (status, starts_at);

-- Pagamentos (registrados manualmente; nunca são apagados) -------------
create table public.payments (
  id           uuid primary key default gen_random_uuid(),
  booking_id   uuid not null references public.bookings (id) on delete restrict,
  kind         public.payment_kind not null default 'payment',  -- 'refund' = estorno
  amount_cents int not null check (amount_cents > 0),
  method       public.payment_method not null default 'pix',
  paid_at      timestamptz not null default now(),
  notes        text,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now()
);
create index payments_booking_idx on public.payments (booking_id);
create index payments_paid_at_idx on public.payments (paid_at);

-- Solicitações do profissional (cancelar / alterar) --------------------
create table public.booking_requests (
  id                uuid primary key default gen_random_uuid(),
  booking_id        uuid not null references public.bookings (id) on delete cascade,
  requested_by      uuid not null references public.profiles (id) on delete cascade,
  type              public.request_type not null,
  reason            text,
  desired_room_id   uuid references public.rooms (id),
  desired_starts_at timestamptz,
  desired_ends_at   timestamptz,
  status            public.request_status not null default 'pending',
  resolved_by       uuid references public.profiles (id) on delete set null,
  resolved_at       timestamptz,
  resolution_note   text,
  created_at        timestamptz not null default now(),
  check (type <> 'change' or (desired_starts_at is not null and desired_ends_at is not null and desired_ends_at > desired_starts_at))
);
create unique index booking_requests_one_pending_idx on public.booking_requests (booking_id) where status = 'pending';
create index booking_requests_status_idx on public.booking_requests (status, created_at desc);

-- Histórico de alterações (somente inserção) ---------------------------
create table public.audit_log (
  id         bigint generated always as identity primary key,
  table_name text not null,
  record_id  text,
  action     text not null,             -- INSERT | UPDATE | DELETE
  actor_id   uuid,                      -- null = operação do sistema
  old_data   jsonb,
  new_data   jsonb,
  created_at timestamptz not null default now()
);
create index audit_log_record_idx  on public.audit_log (table_name, record_id);
create index audit_log_created_idx on public.audit_log (created_at desc);

-- Notificações internas + fila para canais futuros ----------------------
create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  title      text not null,
  body       text,
  link       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);

-- Reservada para WhatsApp/e-mail no futuro. Nada depende dela na versão 1.
create table public.notification_outbox (
  id              uuid primary key default gen_random_uuid(),
  notification_id uuid not null references public.notifications (id) on delete cascade,
  channel         text not null check (channel in ('email', 'whatsapp')),
  status          text not null default 'pending' check (status in ('pending', 'sent', 'failed')),
  attempts        int not null default 0,
  last_error      text,
  created_at      timestamptz not null default now(),
  sent_at         timestamptz
);

-- Visão financeira por reserva (respeita RLS de quem consulta) ---------
-- Reserva cancelada: valor devido = 0; pagamentos já feitos continuam visíveis
-- e aparecem como 'a_estornar' até a administradora registrar o estorno.
create view public.booking_financials with (security_invoker = true) as
select
  b.id as booking_id, b.professional_id, b.room_id, b.starts_at, b.ends_at, b.status,
  b.amount_cents,
  case when b.status = 'cancelled' then 0 else b.amount_cents end                    as due_cents,
  coalesce(p.net_paid, 0)::int                                                          as paid_cents,
  (case when b.status = 'cancelled' then 0 else b.amount_cents end - coalesce(p.net_paid, 0))::int as balance_cents,
  case
    when b.status = 'cancelled' and coalesce(p.net_paid, 0) > 0 then 'a_estornar'
    when b.status = 'cancelled'                                  then 'cancelada'
    when coalesce(p.net_paid, 0) <= 0                            then 'pendente'
    when coalesce(p.net_paid, 0) < b.amount_cents                then 'parcial'
    else 'pago'
  end as payment_status
from public.bookings b
left join lateral (
  select sum(case pay.kind when 'payment' then pay.amount_cents else -pay.amount_cents end) as net_paid
  from public.payments pay where pay.booking_id = b.id
) p on true;
