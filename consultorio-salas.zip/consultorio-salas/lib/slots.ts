import { weekday } from '@/lib/time';

export type Interval = { start: number; end: number };

const toMin = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + (m || 0); };

export function openIntervals(hours: any[], roomId: string, date: string): Interval[] {
  const wd = weekday(date);
  return hours
    .filter((h) => h.room_id === roomId && h.weekday === wd)
    .map((h) => ({ start: toMin(h.opens_at), end: toMin(h.closes_at) }))
    .sort((a, b) => a.start - b.start);
}

const overlaps = (busy: Interval[], s: number, e: number) => busy.some((b) => b.start < e && b.end > s);

/** horários de início livres (a partir da duração mínima) */
export function freeStarts(iv: Interval[], busy: Interval[], slot: number, minDur: number, nowMin: number | null): number[] {
  const out: number[] = [];
  for (const i of iv) for (let s = i.start; s + minDur <= i.end; s += slot) {
    if (nowMin !== null && s <= nowMin) continue;
    if (!overlaps(busy, s, s + minDur)) out.push(s);
  }
  return out;
}

/** horários de término possíveis para um início */
export function endOptions(iv: Interval[], busy: Interval[], slot: number, minDur: number, maxDur: number, start: number): number[] {
  const i = iv.find((x) => start >= x.start && start < x.end);
  if (!i) return [];
  const out: number[] = [];
  for (let e = start + minDur; e <= Math.min(i.end, start + maxDur); e += slot) {
    if (overlaps(busy, start, e)) break;
    out.push(e);
  }
  return out;
}
