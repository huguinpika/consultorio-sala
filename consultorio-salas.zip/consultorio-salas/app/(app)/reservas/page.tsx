import BookingList, { attachFinancials, loadBookingContext } from '@/components/BookingList';
import { requireCtx } from '@/lib/auth';
import { fmtDateTime } from '@/lib/time';
import { Badge } from '@/components/badges';

export default async function MyBookings() {
  const { supabase } = await requireCtx();
  const ctx = await loadBookingContext(supabase);
  const { data } = await supabase.from('bookings').select('*, room:rooms(name,color)').order('starts_at', { ascending: false }).limit(300);
  const all = await attachFinancials(supabase, data ?? []);
  const now = Date.now();
  const upcoming = all.filter((b) => b.status === 'confirmed' && new Date(b.ends_at).getTime() > now).reverse();
  const history = all.filter((b) => !upcoming.includes(b));
  const { data: reqs } = await supabase.from('booking_requests').select('id,type,status,created_at,resolution_note').order('created_at', { ascending: false }).limit(10);
  const common = { rooms: ctx.rooms, hours: ctx.hours, settings: ctx.settings, isAdmin: false };

  return (
    <div className="grid gap-8">
      <div>
        <h1 className="page-title">Minhas reservas</h1>
        <p className="mt-1 text-sm text-mute">Você cancela sozinho até {ctx.settings.cancellation_notice_hours}h antes do início. Depois disso, envie uma solicitação.</p>
      </div>
      <section className="grid gap-3"><h2 className="font-semibold">Próximas</h2><BookingList items={upcoming} empty="Você não tem reservas futuras." {...common} /></section>
      {!!reqs?.length && (
        <section className="grid gap-3">
          <h2 className="font-semibold">Solicitações</h2>
          <ul className="card divide-y divide-line">
            {reqs.map((r: any) => (
              <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm">
                <span>{r.type === 'cancel' ? 'Cancelamento' : 'Alteração'} · {fmtDateTime(r.created_at)}{r.resolution_note ? ` · ${r.resolution_note}` : ''}</span>
                <Badge tone={r.status === 'approved' ? 'green' : r.status === 'rejected' ? 'red' : 'amber'}>{r.status === 'approved' ? 'Aprovada' : r.status === 'rejected' ? 'Recusada' : 'Em análise'}</Badge>
              </li>
            ))}
          </ul>
        </section>
      )}
      <section className="grid gap-3"><h2 className="font-semibold">Histórico</h2><BookingList items={history} empty="Seu histórico aparecerá aqui." {...common} /></section>
    </div>
  );
}
