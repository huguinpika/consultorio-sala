export const METHOD: Record<string, string> = { pix: 'Pix', dinheiro: 'Dinheiro', cartao: 'Cartão', transferencia: 'Transferência', outro: 'Outro' };
export const TABLE_LABEL: Record<string, string> = {
  bookings: 'Reserva', payments: 'Pagamento', profiles: 'Profissional', rooms: 'Sala', opening_hours: 'Horário de funcionamento',
  blocks: 'Bloqueio', room_rates: 'Tarifa da sala', professional_rates: 'Tarifa do profissional', booking_requests: 'Solicitação', settings: 'Configurações',
};
export const ACTION_LABEL: Record<string, string> = { INSERT: 'Criado', UPDATE: 'Alterado', DELETE: 'Removido' };
