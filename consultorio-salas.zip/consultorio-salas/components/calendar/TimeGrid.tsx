'use client';
import { useEffect, useState, type CSSProperties } from 'react';
import { PAY } from '@/components/badges';
import { openIntervals } from '@/lib/slots';
import { fmtTime, hhmm, minutesOfDay, toISO, ymd } from '@/lib/time';

export type Col = { key: string; label: string; sub?: string; date: string; roomId: string; color: string };
export type Ev = {
  key: string; kind: 'booking' | 'busy' | 'block'; roomId: string; start: string; end: string; mine: boolean;
  title: string; id?: string; pay?: string; amount?: number; professionalId?: string; professionalName?: string; status?: string; notes?: string;
};

const H = 56; // px por hora

export default function TimeGrid({ columns, hours, events, slot, onSlot, onEvent, minWidth = 0 }: {
  columns: Col[]; hours: any[]; events: Ev[]; slot: number; minWidth?: number;
  onSlot: (c: Col, startMin: number) => void; onEvent: (e: Ev) => void;
}) {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => { setNow(new Date()); const t = setInterval(() => setNow(new Date()), 60000); return () => clearInterval(t); }, []);

  let lo = 1440, hi = 0;
  for (const c of columns) for (const iv of openIntervals(hours, c.roomId, c.date)) { lo = Math.min(lo, iv.start); hi = Math.max(hi, iv.end); }
  if (lo >= hi) { lo = 8 * 60; hi = 18 * 60; }
  lo = Math.floor(lo / 60) * 60; hi = Math.ceil(hi / 60) * 60;
  const total = ((hi - lo) / 60) * H;
  const marks: number[] = [];
  for (let m = lo; m < hi; m += 60) marks.push(m);
  const today = now ? ymd(now) : null, nowMin = now ? minutesOfDay(now) : null;

  return (
    <div className="overflow-x-auto">
      <div style={{ minWidth }}>
        <div className="flex border-b border-line bg-white">
          <div className="w-12 shrink-0" />
          {columns.map((c) => (
            <div key={c.key} className="flex-1 border-l border-line px-2 py-2 text-center">
              <p className="flex items-center justify-center gap-1.5 text-sm font-medium"><span className="h-2 w-2 rounded-sm" style={{ background: c.color }} />{c.label}</p>
              {c.sub && <p className={`text-xs ${c.date === today ? 'font-semibold text-brand-700' : 'text-mute'}`}>{c.sub}</p>}
            </div>
          ))}
        </div>
        <div className="flex">
          <div className="relative w-12 shrink-0" style={{ height: total }}>
            {marks.map((m) => <span key={m} className="absolute right-2 text-[11px] text-mute" style={{ top: ((m - lo) / 60) * H + 2 }}>{hhmm(m)}</span>)}
          </div>
          {columns.map((c) => {
            const iv = openIntervals(hours, c.roomId, c.date);
            const dayStart = new Date(toISO(c.date, 0)).getTime();
            const rel = (iso: string) => (new Date(iso).getTime() - dayStart) / 60000;
            const evs = events.filter((e) => (e.roomId === c.roomId || e.roomId === '*') && rel(e.end) > lo && rel(e.start) < hi);
            const slots: number[] = [];
            for (const i of iv) for (let s = i.start; s + slot <= i.end; s += slot) slots.push(s);
            return (
              <div key={c.key} className="relative flex-1 border-l border-line" style={{ height: total }}>
                <div className="absolute inset-0 bg-[repeating-linear-gradient(135deg,#eef0ef_0,#eef0ef_6px,#f6f7f6_6px,#f6f7f6_12px)]" />
                {iv.map((i, k) => <div key={k} className="absolute inset-x-0 bg-white" style={{ top: ((i.start - lo) / 60) * H, height: ((i.end - i.start) / 60) * H }} />)}
                {marks.map((m) => <div key={m} className="absolute inset-x-0 border-t border-line/80" style={{ top: ((m - lo) / 60) * H }} />)}
                {slots.map((s) => {
                  const past = today !== null && (c.date < today || (c.date === today && s <= (nowMin ?? 0)));
                  return (
                    <button key={s} type="button" disabled={past} onClick={() => onSlot(c, s)} aria-label={`Reservar ${c.label} às ${hhmm(s)}`}
                      className="absolute inset-x-0 transition hover:bg-brand-50 disabled:cursor-default disabled:hover:bg-transparent"
                      style={{ top: ((s - lo) / 60) * H, height: (slot / 60) * H }} />
                  );
                })}
                {evs.map((e) => {
                  const s = Math.max(rel(e.start), lo), en = Math.min(rel(e.end), hi);
                  if (en <= s) return null;
                  const top = ((s - lo) / 60) * H, h = ((en - s) / 60) * H - 2, tall = h >= 44;
                  const color = e.roomId === '*' ? '#9ca3af' : c.color;
                  const style: CSSProperties = { top, height: h, borderLeft: `3px solid ${color}`, ...(e.kind === 'booking' ? { background: `${color}26` } : {}) };
                  const cls = e.kind === 'block'
                    ? 'bg-[repeating-linear-gradient(135deg,#e2e5e4_0,#e2e5e4_5px,#eef0ef_5px,#eef0ef_10px)] text-mute'
                    : e.kind === 'busy' ? 'bg-stone-100 text-mute' : 'text-ink';
                  return (
                    <button key={e.key} type="button" disabled={e.kind !== 'booking'} onClick={() => onEvent(e)} style={style}
                      className={`absolute inset-x-1 overflow-hidden rounded-md px-2 py-0.5 text-left text-xs leading-tight ${cls} ${e.kind === 'booking' ? 'cursor-pointer hover:brightness-95' : 'cursor-default'}`}>
                      {e.pay && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full" style={{ background: PAY[e.pay]?.dot }} title={PAY[e.pay]?.label} />}
                      <span className="block truncate font-medium">{e.title}</span>
                      {tall && <span className="block truncate text-[11px] opacity-75">{fmtTime(e.start)}–{fmtTime(e.end)}</span>}
                    </button>
                  );
                })}
                {c.date === today && nowMin !== null && nowMin >= lo && nowMin < hi && (
                  <div className="pointer-events-none absolute inset-x-0 z-10 border-t-2 border-red-500" style={{ top: ((nowMin - lo) / 60) * H }}>
                    <span className="absolute -left-1 -top-[5px] h-2 w-2 rounded-full bg-red-500" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
