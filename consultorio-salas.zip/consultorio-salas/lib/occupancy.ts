import { addDays, toISO, weekday } from '@/lib/time';
import { openIntervals } from '@/lib/slots';

/** Taxa de ocupação = minutos reservados ÷ minutos de funcionamento no período [from, toExclusive) */
export function occupancy(hours: any[], bookings: any[], roomIds: string[], from: string, toExclusive: string) {
  let available = 0;
  for (let d = from; d < toExclusive; d = addDays(d, 1))
    for (const r of roomIds) for (const iv of openIntervals(hours, r, d)) available += iv.end - iv.start;
  const f = new Date(toISO(from, 0)).getTime(), t = new Date(toISO(toExclusive, 0)).getTime();
  let booked = 0;
  for (const b of bookings) {
    if (b.status !== 'confirmed' || !roomIds.includes(b.room_id)) continue;
    const s = Math.max(new Date(b.starts_at).getTime(), f), e = Math.min(new Date(b.ends_at).getTime(), t);
    if (e > s) booked += (e - s) / 60000;
  }
  return { available, booked, rate: available ? booked / available : 0 };
}
export const pct = (r: number) => `${Math.round(r * 100)}%`;
export { weekday };
