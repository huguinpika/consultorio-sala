'use server';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { createClient } from '@/lib/supabase/server';
import { fail, failText, type Res } from '@/lib/errors';
import { parseMoney } from '@/lib/money';
import { localInputToISO } from '@/lib/time';

const refresh = () => revalidatePath('/', 'layout');
const s = (fd: FormData, k: string) => String(fd.get(k) ?? '').trim();
const site = () => (process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000').replace(/\/$/, '');

// ---------------- profissionais ----------------
export async function createProfessionalAction(fd: FormData): Promise<Res> {
  await requireAdmin();
  const email = s(fd, 'email').toLowerCase(), password = s(fd, 'password'), name = s(fd, 'full_name');
  if (!name || !email) return failText('Informe nome e e-mail.');
  if (password.length < 8) return failText('A senha provisória precisa ter ao menos 8 caracteres.');
  const admin = createAdminClient();
  const { data, error } = await admin.auth.admin.createUser({
    email, password, email_confirm: true, user_metadata: { full_name: name, phone: s(fd, 'phone') },
  });
  if (error || !data.user) {
    return failText(/already|registered|exists/i.test(error?.message ?? '') ? 'Já existe uma conta com esse e-mail.' : 'Não foi possível criar a conta. Confira os dados.');
  }
  const reg = s(fd, 'registration_number');
  if (reg) await admin.from('profiles').update({ registration_number: reg }).eq('id', data.user.id);
  refresh();
  return { ok: true, id: data.user.id };
}

export async function updateProfessionalAction(id: string, fd: FormData): Promise<Res> {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from('profiles').update({
    full_name: s(fd, 'full_name'), phone: s(fd, 'phone') || null, registration_number: s(fd, 'registration_number') || null,
  }).eq('id', id);
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function setActiveAction(id: string, active: boolean): Promise<Res> {
  const { supabase, user } = await requireAdmin();
  if (id === user.id && !active) return failText('Você não pode suspender a própria conta.');
  const { error } = await supabase.from('profiles').update({ is_active: active }).eq('id', id);
  if (error) return fail(error.message);
  // Suspensão também bloqueia novos logins e a renovação de sessões já abertas.
  await createAdminClient().auth.admin.updateUserById(id, { ban_duration: active ? 'none' : '876000h' });
  refresh();
  return { ok: true };
}

export async function sendResetAction(id: string): Promise<Res> {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from('profiles').select('email').eq('id', id).single();
  if (!data) return failText('Profissional não encontrado.');
  const anon = await createClient();
  const { error } = await anon.auth.resetPasswordForEmail(data.email, { redirectTo: `${site()}/auth/callback?next=/redefinir-senha` });
  if (error) return failText('Não foi possível enviar o e-mail agora. Tente novamente em alguns minutos.');
  return { ok: true };
}

export async function deleteProfessionalAction(id: string): Promise<Res> {
  const { supabase, user } = await requireAdmin();
  if (id === user.id) return failText('Você não pode excluir a própria conta.');
  const { count } = await supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('professional_id', id);
  if (count && count > 0) return failText('Este profissional tem histórico de reservas. Suspenda a conta em vez de excluir.');
  const { error } = await createAdminClient().auth.admin.deleteUser(id);
  if (error) return failText('Não foi possível excluir. Suspenda a conta em vez de excluir.');
  refresh();
  return { ok: true };
}

export async function addProfessionalRateAction(id: string, fd: FormData): Promise<Res> {
  const { supabase, user } = await requireAdmin();
  const cents = parseMoney(s(fd, 'price'));
  if (cents === null) return failText('Informe um valor válido.');
  const room = s(fd, 'room');
  const { error } = await supabase.from('professional_rates').insert({
    professional_id: id, room_id: room || null, hourly_rate_cents: cents, created_by: user.id,
  });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

// ---------------- salas ----------------
export async function updateRoomAction(id: string, fd: FormData): Promise<Res> {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from('rooms').update({
    name: s(fd, 'name'), description: s(fd, 'description') || null, color: s(fd, 'color') || '#2563eb', is_active: fd.get('is_active') === 'on',
  }).eq('id', id);
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function addRoomRateAction(roomId: string, fd: FormData): Promise<Res> {
  const { supabase, user } = await requireAdmin();
  const cents = parseMoney(s(fd, 'price'));
  if (cents === null) return failText('Informe um valor válido.');
  const { error } = await supabase.from('room_rates').insert({ room_id: roomId, hourly_rate_cents: cents, created_by: user.id });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function addHoursAction(roomId: string, fd: FormData): Promise<Res> {
  const { supabase } = await requireAdmin();
  const days = fd.getAll('weekday').map(Number);
  const opens = s(fd, 'opens'), closes = s(fd, 'closes');
  if (!days.length) return failText('Marque ao menos um dia da semana.');
  if (!opens || !closes || opens >= closes) return failText('O horário de abertura precisa ser antes do fechamento.');
  const { error } = await supabase.from('opening_hours').insert(days.map((d) => ({ room_id: roomId, weekday: d, opens_at: opens, closes_at: closes })));
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function deleteHoursAction(id: string): Promise<Res> {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from('opening_hours').delete().eq('id', id);
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function addBlockAction(fd: FormData): Promise<Res> {
  const { supabase, user } = await requireAdmin();
  const start = s(fd, 'start'), end = s(fd, 'end'), room = s(fd, 'room');
  if (!start || !end) return failText('Informe início e fim do bloqueio.');
  if (start >= end) return failText('O fim precisa ser depois do início.');
  const { error } = await supabase.from('blocks').insert({
    room_id: room || null, starts_at: localInputToISO(start), ends_at: localInputToISO(end), reason: s(fd, 'reason') || null, created_by: user.id,
  });
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function deleteBlockAction(id: string): Promise<Res> {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from('blocks').delete().eq('id', id);
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}

export async function updateSettingsAction(fd: FormData): Promise<Res> {
  const { supabase } = await requireAdmin();
  const slot = Number(s(fd, 'slot_minutes')), min = Number(s(fd, 'min_duration_minutes')), max = Number(s(fd, 'max_duration_minutes')), notice = Number(s(fd, 'cancellation_notice_hours'));
  if (![30, 60].includes(slot)) return failText('Escolha reservas de 30 minutos ou de 1 hora.');
  if (!(min > 0) || min % slot !== 0) return failText('A duração mínima precisa ser múltipla do intervalo.');
  if (max < min || max % slot !== 0) return failText('A duração máxima precisa ser maior que a mínima e múltipla do intervalo.');
  if (!(notice >= 0)) return failText('Informe o prazo de cancelamento em horas.');
  const { error } = await supabase.from('settings').update({
    slot_minutes: slot, min_duration_minutes: min, max_duration_minutes: max, cancellation_notice_hours: notice,
  }).eq('id', true);
  if (error) return fail(error.message);
  refresh();
  return { ok: true };
}
