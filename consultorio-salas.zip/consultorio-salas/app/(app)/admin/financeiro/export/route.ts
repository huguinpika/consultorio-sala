import { NextResponse, type NextRequest } from 'next/server';
import { requireAdmin } from '@/lib/auth';
import { addMonths, clampMonth, fmtDate, fmtDuration, fmtTime, toISO, ymd } from '@/lib/time';

const csv = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
const num = (cents: number) => (cents / 100).toFixed(2).replace('.', ',');

export async function GET(req: NextRequest) {
  const { supabase } = await requireAdmin();
  const sp = req.nextUrl.searchParams;
  const mes = clampMonth(sp.get('mes') ?? undefined), from = `${mes}-01`;
  const [{ data: rooms }, { data: pros }, { data: bk }] = await Promise.all([
    supabase.from('rooms').select('id,name'), supabase.from('profiles').select('id,full_name'),
    supabase.from('bookings').select('id,room_id,professional_id,starts_at,ends_at,status,amount_cents,hourly_rate_cents').gte('starts_at', toISO(from, 0)).lt('starts_at', toISO(addMonths(from, 1), 0)).order('starts_at'),
  ]);
  const ids = (bk ?? []).map((b: any) => b.id);
  const { data: fin } = ids.length ? await supabase.from('booking_financials').select('booking_id,paid_cents,balance_cents,payment_status').in('booking_id', ids) : { data: [] as any[] };
  const f = new Map((fin ?? []).map((x: any) => [x.booking_id, x]));
  const rn = new Map((rooms ?? []).map((r: any) => [r.id, r.name])), pn = new Map((pros ?? []).map((p: any) => [p.id, p.full_name]));

  let rows = bk ?? [];
  if (sp.get('pro')) rows = rows.filter((r: any) => r.professional_id === sp.get('pro'));
  if (sp.get('sala')) rows = rows.filter((r: any) => r.room_id === sp.get('sala'));
  if (sp.get('situacao')) rows = rows.filter((r: any) => (f.get(r.id) as any)?.payment_status === sp.get('situacao'));

  const head = ['Data', 'Início', 'Fim', 'Duração', 'Sala', 'Profissional', 'Valor da hora', 'Valor', 'Pago', 'Saldo', 'Situação do pagamento', 'Situação da reserva'];
  const lines = rows.map((r: any) => {
    const x: any = f.get(r.id) ?? { paid_cents: 0, balance_cents: r.amount_cents, payment_status: 'pendente' };
    const min = (new Date(r.ends_at).getTime() - new Date(r.starts_at).getTime()) / 60000;
    return [fmtDate(ymd(r.starts_at)), fmtTime(r.starts_at), fmtTime(r.ends_at), fmtDuration(min), rn.get(r.room_id), pn.get(r.professional_id),
      num(r.hourly_rate_cents), num(r.amount_cents), num(x.paid_cents), num(x.balance_cents), x.payment_status, r.status === 'confirmed' ? 'Confirmada' : 'Cancelada'].map(csv).join(';');
  });
  const body = '\uFEFF' + [head.map(csv).join(';'), ...lines].join('\r\n');
  return new NextResponse(body, { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="financeiro-${mes}.csv"` } });
}
