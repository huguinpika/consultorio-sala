-- CONSULTÓRIO: instalação completa do banco (cole tudo no SQL Editor do Supabase e clique em Run)
-- =====================================================================
-- 0001 · ESQUEMA: extensões, tipos, tabelas, constraints e índices
-- Valores monetários sempre em CENTAVOS (inteiro). Datas em UTC (timestamptz);
-- a exibição em horário de Brasília é feita pelo app e pelas funções.
-- =====================================================================

create extension if not exists btree_gist;

create type public.user_role      as enum ('admin', 'professional');
create type public.booking_status as enum ('confirmed', 'cancelled');
create type public.request_type   as enum ('cancel', 'change');
create type public.request_status as enum ('pending', 'approved', 'rejected');
create type public.payment_kind   as enum ('payment', 'refund');
create type public.payment_method as enum ('pix', 'dinheiro', 'cartao', 'transferencia', 'outro');

-- Configurações globais (linha única) ---------------------------------
create table public.settings (
  id                        boolean primary key default true check (id),
  timezone                  text    not null default 'America/Sao_Paulo',
  slot_minutes              int     not null default 60 check (slot_minutes in (30, 60)), -- 30 = meia hora habilitada
  min_duration_minutes      int     not null default 60 check (min_duration_minutes > 0),
  max_duration_minutes      int     not null default 480,
  cancellation_notice_hours int     not null default 24 check (cancellation_notice_hours >= 0),
  updated_at                timestamptz not null default now(),
  check (max_duration_minutes >= min_duration_minutes)
);

-- Perfis (1 para 1 com auth.users) ------------------------------------
create table public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,
  role                public.user_role not null default 'professional',
  full_name           text not null check (length(trim(full_name)) > 0),
  email               text not null,
  phone               text,
  registration_number text,                       -- ex.: CRP (opcional)
  is_active           boolean not null default true,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
create unique index profiles_email_key on public.profiles (lower(email));

-- Salas ---------------------------------------------------------------
create table public.rooms (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  description text,
  color       text not null default '#2563eb' check (color ~ '^#[0-9a-fA-F]{6}$'),
  is_active   boolean not null default true,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- Horários de funcionamento (vários intervalos por dia; 0 = domingo) ---
create table public.opening_hours (
  id        uuid primary key default gen_random_uuid(),
  room_id   uuid not null references public.rooms (id) on delete cascade,
  weekday   smallint not null check (weekday between 0 and 6),
  opens_at  time not null,
  closes_at time not null,
  check (opens_at < closes_at and closes_at <= time '24:00')
);
create index opening_hours_room_day_idx on public.opening_hours (room_id, weekday);

-- Bloqueios (room_id nulo = vale para todas as salas) -----------------
create table public.blocks (
  id         uuid primary key default gen_random_uuid(),
  room_id    uuid references public.rooms (id) on delete cascade,
  starts_at  timestamptz not null,
  ends_at    timestamptz not null,
  reason     text,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);
create index blocks_range_idx on public.blocks using gist (tstzrange(starts_at, ends_at));

-- Tarifas por hora, com vigência (preserva o histórico de valores) -----
create table public.room_rates (
  id                uuid primary key default gen_random_uuid(),
  room_id           uuid not null references public.rooms (id) on delete cascade,
  hourly_rate_cents int not null check (hourly_rate_cents >= 0),
  valid_from        timestamptz not null default now(),
  created_by        uuid references public.profiles (id) on delete set null,
  created_at        timestamptz not null default now()
);
create index room_rates_lookup_idx on public.room_rates (room_id, valid_from desc);

-- Preço especial por profissional (room_id nulo = todas as salas) ------
create table public.professional_rates (
  id                uuid primary key default gen_random_uuid(),
  professional_id   uuid not null references public.profiles (id) on delete cascade,
  room_id           uuid references public.rooms (id) on delete cascade,
  hourly_rate_cents int not null check (hourly_rate_cents >= 0),
  valid_from        timestamptz not null default now(),
  created_by        uuid references public.profiles (id) on delete set null,
  created_at        timestamptz not null default now()
);
create index professional_rates_lookup_idx on public.professional_rates (professional_id, room_id, valid_from desc);

-- Reservas ------------------------------------------------------------
create table public.bookings (
  id                uuid primary key default gen_random_uuid(),
  room_id           uuid not null references public.rooms (id) on delete restrict,
  professional_id   uuid not null references public.profiles (id) on delete restrict,
  starts_at         timestamptz not null,
  ends_at           timestamptz not null,
  status            public.booking_status not null default 'confirmed',
  hourly_rate_cents int not null check (hourly_rate_cents >= 0),  -- valor/hora "congelado" na reserva
  amount_cents      int not null check (amount_cents >= 0),       -- duração (h) × valor/hora
  notes             text,
  created_by        uuid references public.profiles (id) on delete set null,
  updated_by        uuid references public.profiles (id) on delete set null,
  cancelled_at      timestamptz,
  cancelled_by      uuid references public.profiles (id) on delete set null,
  cancel_reason     text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  check (ends_at > starts_at),
  check ((status = 'cancelled') = (cancelled_at is not null)),
  -- GARANTIA DE INTEGRIDADE: o próprio PostgreSQL impede sobreposição na mesma sala,
  -- mesmo com duas pessoas reservando ao mesmo tempo. Reservas canceladas não contam.
  constraint bookings_no_overlap exclude using gist (
    room_id with =,
    tstzrange(starts_at, ends_at) with &&
  ) where (status = 'confirmed')
);
create index bookings_professional_idx on public.bookings (professional_id, starts_at desc);
create index bookings_room_time_idx    on public.bookings (room_id, starts_at);
create index bookings_status_idx       on public.bookings (status, starts_at);

-- Pagamentos (registrados manualmente; nunca são apagados) -------------
create table public.payments (
  id           uuid primary key default gen_random_uuid(),
  booking_id   uuid not null references public.bookings (id) on delete restrict,
  kind         public.payment_kind not null default 'payment',  -- 'refund' = estorno
  amount_cents int not null check (amount_cents > 0),
  method       public.payment_method not null default 'pix',
  paid_at      timestamptz not null default now(),
  notes        text,
  created_by   uuid references public.profiles (id) on delete set null,
  created_at   timestamptz not null default now()
);
create index payments_booking_idx on public.payments (booking_id);
create index payments_paid_at_idx on public.payments (paid_at);

-- Solicitações do profissional (cancelar / alterar) --------------------
create table public.booking_requests (
  id                uuid primary key default gen_random_uuid(),
  booking_id        uuid not null references public.bookings (id) on delete cascade,
  requested_by      uuid not null references public.profiles (id) on delete cascade,
  type              public.request_type not null,
  reason            text,
  desired_room_id   uuid references public.rooms (id),
  desired_starts_at timestamptz,
  desired_ends_at   timestamptz,
  status            public.request_status not null default 'pending',
  resolved_by       uuid references public.profiles (id) on delete set null,
  resolved_at       timestamptz,
  resolution_note   text,
  created_at        timestamptz not null default now(),
  check (type <> 'change' or (desired_starts_at is not null and desired_ends_at is not null and desired_ends_at > desired_starts_at))
);
create unique index booking_requests_one_pending_idx on public.booking_requests (booking_id) where status = 'pending';
create index booking_requests_status_idx on public.booking_requests (status, created_at desc);

-- Histórico de alterações (somente inserção) ---------------------------
create table public.audit_log (
  id         bigint generated always as identity primary key,
  table_name text not null,
  record_id  text,
  action     text not null,             -- INSERT | UPDATE | DELETE
  actor_id   uuid,                      -- null = operação do sistema
  old_data   jsonb,
  new_data   jsonb,
  created_at timestamptz not null default now()
);
create index audit_log_record_idx  on public.audit_log (table_name, record_id);
create index audit_log_created_idx on public.audit_log (created_at desc);

-- Notificações internas + fila para canais futuros ----------------------
create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  title      text not null,
  body       text,
  link       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications (user_id, created_at desc);

-- Reservada para WhatsApp/e-mail no futuro. Nada depende dela na versão 1.
create table public.notification_outbox (
  id              uuid primary key default gen_random_uuid(),
  notification_id uuid not null references public.notifications (id) on delete cascade,
  channel         text not null check (channel in ('email', 'whatsapp')),
  status          text not null default 'pending' check (status in ('pending', 'sent', 'failed')),
  attempts        int not null default 0,
  last_error      text,
  created_at      timestamptz not null default now(),
  sent_at         timestamptz
);

-- Visão financeira por reserva (respeita RLS de quem consulta) ---------
-- Reserva cancelada: valor devido = 0; pagamentos já feitos continuam visíveis
-- e aparecem como 'a_estornar' até a administradora registrar o estorno.
create view public.booking_financials with (security_invoker = true) as
select
  b.id as booking_id, b.professional_id, b.room_id, b.starts_at, b.ends_at, b.status,
  b.amount_cents,
  case when b.status = 'cancelled' then 0 else b.amount_cents end                    as due_cents,
  coalesce(p.net_paid, 0)::int                                                          as paid_cents,
  (case when b.status = 'cancelled' then 0 else b.amount_cents end - coalesce(p.net_paid, 0))::int as balance_cents,
  case
    when b.status = 'cancelled' and coalesce(p.net_paid, 0) > 0 then 'a_estornar'
    when b.status = 'cancelled'                                  then 'cancelada'
    when coalesce(p.net_paid, 0) <= 0                            then 'pendente'
    when coalesce(p.net_paid, 0) < b.amount_cents                then 'parcial'
    else 'pago'
  end as payment_status
from public.bookings b
left join lateral (
  select sum(case pay.kind when 'payment' then pay.amount_cents else -pay.amount_cents end) as net_paid
  from public.payments pay where pay.booking_id = b.id
) p on true;
-- =====================================================================
-- 0002 · FUNÇÕES, TRIGGERS E RPCs
-- Toda escrita em reservas/pagamentos/solicitações passa por RPCs
-- (security definer). Erros são códigos curtos (ex.: horario_indisponivel)
-- que o app traduz para mensagens em português.
-- =====================================================================

-- ---------- utilitários ------------------------------------------------
create function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin' and is_active);
$$;

create function public.current_user_active() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and is_active);
$$;

create function public.touch_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

create function public.fmt_local(p_ts timestamptz) returns text
language sql stable security definer set search_path = public as $$
  select to_char(p_ts at time zone (select timezone from public.settings), 'DD/MM/YYYY "às" HH24:MI');
$$;

create function public.notify(p_user uuid, p_title text, p_body text, p_link text default null) returns void
language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body, link) values (p_user, p_title, p_body, p_link);
$$;

create function public.notify_admins(p_title text, p_body text, p_link text default null) returns void
language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, title, body, link)
  select id, p_title, p_body, p_link from public.profiles where role = 'admin' and is_active;
$$;

-- ---------- histórico de alterações (auditoria) ------------------------
create function public.audit_row() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_log (table_name, record_id, action, actor_id, old_data, new_data)
  values (
    tg_table_name,
    case when tg_op = 'DELETE' then to_jsonb(old) ->> 'id' else to_jsonb(new) ->> 'id' end,
    tg_op, auth.uid(),
    case when tg_op <> 'INSERT' then to_jsonb(old) end,
    case when tg_op <> 'DELETE' then to_jsonb(new) end
  );
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['settings','profiles','rooms','opening_hours','blocks','room_rates',
                           'professional_rates','bookings','payments','booking_requests']
  loop
    execute format('create trigger %I after insert or update or delete on public.%I
                    for each row execute function public.audit_row()', 'audit_' || t, t);
  end loop;
  foreach t in array array['settings','profiles','rooms','bookings']
  loop
    execute format('create trigger %I before update on public.%I
                    for each row execute function public.touch_updated_at()', 'touch_' || t, t);
  end loop;
end $$;

-- ---------- novo usuário no Supabase Auth → cria perfil ----------------
-- O PRIMEIRO usuário criado vira administrador; os demais, profissionais.
-- (Desative o cadastro público no Supabase: Authentication > Sign In / Providers.)
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, role, full_name, email, phone)
  values (
    new.id,
    case when exists (select 1 from public.profiles where role = 'admin') then 'professional'::public.user_role else 'admin'::public.user_role end,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), split_part(new.email, '@', 1)),
    new.email,
    nullif(trim(new.raw_user_meta_data ->> 'phone'), '')
  );
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Profissional não pode promover a si mesmo nem se reativar; sempre deve existir 1 admin ativo.
create function public.profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.role <> old.role or new.is_active <> old.is_active or lower(new.email) <> lower(old.email) then
      raise exception 'sem_permissao';
    end if;
  end if;
  if old.role = 'admin' and old.is_active and (new.role <> 'admin' or not new.is_active)
     and not exists (select 1 from public.profiles where role = 'admin' and is_active and id <> old.id) then
    raise exception 'ultimo_administrador';
  end if;
  return new;
end $$;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.profiles_guard();

-- ---------- tarifas ----------------------------------------------------
-- Prioridade: preço do profissional para a sala > preço do profissional (todas) > preço da sala.
create function public.current_rate_cents(p_room uuid, p_prof uuid, p_at timestamptz default now()) returns int
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select hourly_rate_cents from public.professional_rates
      where professional_id = p_prof and room_id = p_room and valid_from <= p_at order by valid_from desc limit 1),
    (select hourly_rate_cents from public.professional_rates
      where professional_id = p_prof and room_id is null and valid_from <= p_at order by valid_from desc limit 1),
    (select hourly_rate_cents from public.room_rates
      where room_id = p_room and valid_from <= p_at order by valid_from desc limit 1)
  );
$$;

-- ---------- validação central de janela de reserva ---------------------
create function public.validate_booking_window(p_room uuid, p_starts timestamptz, p_ends timestamptz) returns void
language plpgsql stable security definer set search_path = public as $$
declare
  s public.settings; v_ls timestamp; v_le timestamp; v_min int; v_start_min int; v_end_time time;
begin
  select * into s from public.settings;
  if not exists (select 1 from public.rooms where id = p_room and is_active) then raise exception 'sala_indisponivel'; end if;
  if p_ends <= p_starts then raise exception 'duracao_invalida'; end if;

  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;
  if v_min < s.min_duration_minutes or v_min > s.max_duration_minutes or v_min % s.slot_minutes <> 0 then
    raise exception 'duracao_invalida';
  end if;

  v_ls := p_starts at time zone s.timezone;
  v_le := p_ends   at time zone s.timezone;
  v_start_min := extract(hour from v_ls)::int * 60 + extract(minute from v_ls)::int;
  if v_start_min % s.slot_minutes <> 0 or extract(second from v_ls) <> 0 then raise exception 'horario_invalido'; end if;

  if v_le::date <> v_ls::date and not (v_le::date = v_ls::date + 1 and v_le::time = time '00:00') then
    raise exception 'fora_do_expediente';
  end if;
  v_end_time := case when v_le::date > v_ls::date then time '24:00' else v_le::time end;

  if not exists (
    select 1 from public.opening_hours oh
    where oh.room_id = p_room and oh.weekday = extract(dow from v_ls)::int
      and oh.opens_at <= v_ls::time and oh.closes_at >= v_end_time
  ) then raise exception 'fora_do_expediente'; end if;

  if exists (
    select 1 from public.blocks b
    where (b.room_id is null or b.room_id = p_room)
      and tstzrange(b.starts_at, b.ends_at) && tstzrange(p_starts, p_ends)
  ) then raise exception 'horario_bloqueado'; end if;
end $$;

-- Rede de segurança: mesmo escrita direta é validada (conflito = constraint de exclusão).
create function public.bookings_validate() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'confirmed' then
    perform public.validate_booking_window(new.room_id, new.starts_at, new.ends_at);
  end if;
  return new;
end $$;
create trigger bookings_validate_ins before insert on public.bookings
  for each row execute function public.bookings_validate();
create trigger bookings_validate_upd before update of room_id, starts_at, ends_at, status on public.bookings
  for each row when (new.status = 'confirmed' and (
    new.room_id is distinct from old.room_id or new.starts_at is distinct from old.starts_at
    or new.ends_at is distinct from old.ends_at or old.status is distinct from new.status))
  execute function public.bookings_validate();

-- Não permite criar bloqueio sobre reservas confirmadas (cancele/remaneje antes).
create function public.blocks_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from public.bookings b
             where b.status = 'confirmed' and (new.room_id is null or b.room_id = new.room_id)
               and tstzrange(b.starts_at, b.ends_at) && tstzrange(new.starts_at, new.ends_at)) then
    raise exception 'existem_reservas_no_periodo';
  end if;
  return new;
end $$;
create trigger blocks_guard before insert or update of room_id, starts_at, ends_at on public.blocks
  for each row execute function public.blocks_guard();

-- ---------- RPC: estimar valor ----------------------------------------
create function public.estimate_booking(p_room uuid, p_starts timestamptz, p_ends timestamptz, p_professional uuid default null)
returns table (hourly_rate_cents int, duration_minutes int, amount_cents int)
language plpgsql stable security definer set search_path = public as $$
declare v_prof uuid; v_rate int; v_min int;
begin
  if auth.uid() is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  v_prof := case when public.is_admin() then coalesce(p_professional, auth.uid()) else auth.uid() end;
  v_rate := public.current_rate_cents(p_room, v_prof);
  if v_rate is null then raise exception 'tarifa_nao_configurada'; end if;
  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;
  return query select v_rate, v_min, round(v_rate::numeric * v_min / 60)::int;
end $$;

-- ---------- RPC: disponibilidade (sem expor quem reservou) -------------
create function public.get_room_busy(p_room uuid, p_from timestamptz, p_to timestamptz)
returns table (kind text, starts_at timestamptz, ends_at timestamptz, is_mine boolean)
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  return query
    select 'booking'::text, b.starts_at, b.ends_at, (b.professional_id = auth.uid())
    from public.bookings b
    where b.room_id = p_room and b.status = 'confirmed' and tstzrange(b.starts_at, b.ends_at) && tstzrange(p_from, p_to)
    union all
    select 'block'::text, k.starts_at, k.ends_at, false
    from public.blocks k
    where (k.room_id is null or k.room_id = p_room) and tstzrange(k.starts_at, k.ends_at) && tstzrange(p_from, p_to)
    order by 2;
end $$;

-- ---------- RPC: criar reserva -----------------------------------------
create function public.create_booking(
  p_room uuid, p_starts timestamptz, p_ends timestamptz, p_professional uuid default null, p_notes text default null
) returns public.bookings
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid(); v_admin boolean; v_prof uuid; v_rate int; v_min int; v_row public.bookings; v_room text;
begin
  if v_uid is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  v_admin := public.is_admin();
  if not v_admin and p_professional is not null and p_professional <> v_uid then raise exception 'sem_permissao'; end if;
  v_prof := case when v_admin then coalesce(p_professional, v_uid) else v_uid end;
  if not exists (select 1 from public.profiles where id = v_prof and is_active) then raise exception 'profissional_inativo'; end if;
  if p_starts <= now() then raise exception 'horario_no_passado'; end if;

  perform public.validate_booking_window(p_room, p_starts, p_ends);
  v_rate := public.current_rate_cents(p_room, v_prof);
  if v_rate is null then raise exception 'tarifa_nao_configurada'; end if;
  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;

  insert into public.bookings (room_id, professional_id, starts_at, ends_at, hourly_rate_cents, amount_cents, notes, created_by, updated_by)
  values (p_room, v_prof, p_starts, p_ends, v_rate, round(v_rate::numeric * v_min / 60)::int, nullif(trim(p_notes), ''), v_uid, v_uid)
  returning * into v_row;

  select name into v_room from public.rooms where id = p_room;
  if v_prof <> v_uid then
    perform public.notify(v_prof, 'Nova reserva em seu nome', v_room || ' · ' || public.fmt_local(p_starts), '/reservas');
  end if;
  if not v_admin then
    perform public.notify_admins('Nova reserva', (select full_name from public.profiles where id = v_prof) || ' · ' || v_room || ' · ' || public.fmt_local(p_starts), '/admin/reservas');
  end if;
  return v_row;
exception when exclusion_violation then
  raise exception 'horario_indisponivel';
end $$;

-- ---------- internas: cancelar e remanejar -----------------------------
create function public._cancel_booking(p_booking uuid, p_reason text, p_actor uuid) returns public.bookings
language plpgsql security definer set search_path = public as $$
declare v_b public.bookings; v_room text;
begin
  update public.bookings set status = 'cancelled', cancelled_at = now(), cancelled_by = p_actor,
         cancel_reason = nullif(trim(p_reason), ''), updated_by = p_actor
   where id = p_booking returning * into v_b;
  -- Pagamentos existentes NÃO são alterados; o financeiro passa a mostrar 'a_estornar' se houver valor pago.
  update public.booking_requests set status = 'approved', resolved_by = p_actor, resolved_at = now(),
         resolution_note = 'Reserva cancelada'
   where booking_id = p_booking and status = 'pending';
  select name into v_room from public.rooms where id = v_b.room_id;
  if p_actor <> v_b.professional_id then
    perform public.notify(v_b.professional_id, 'Reserva cancelada', v_room || ' · ' || public.fmt_local(v_b.starts_at), '/reservas');
  else
    perform public.notify_admins('Reserva cancelada pelo profissional', v_room || ' · ' || public.fmt_local(v_b.starts_at), '/admin/reservas');
  end if;
  return v_b;
end $$;

create function public._reschedule_booking(p_booking uuid, p_room uuid, p_starts timestamptz, p_ends timestamptz, p_actor uuid)
returns public.bookings
language plpgsql security definer set search_path = public as $$
declare v_b public.bookings; v_rate int; v_min int; v_room text;
begin
  select * into v_b from public.bookings where id = p_booking for update;
  if not found then raise exception 'reserva_nao_encontrada'; end if;
  if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
  if p_starts <= now() then raise exception 'horario_no_passado'; end if;
  perform public.validate_booking_window(p_room, p_starts, p_ends);

  v_rate := case when p_room = v_b.room_id then v_b.hourly_rate_cents else public.current_rate_cents(p_room, v_b.professional_id) end;
  if v_rate is null then raise exception 'tarifa_nao_configurada'; end if;
  v_min := (extract(epoch from (p_ends - p_starts)) / 60)::int;

  update public.bookings set room_id = p_room, starts_at = p_starts, ends_at = p_ends,
         hourly_rate_cents = v_rate, amount_cents = round(v_rate::numeric * v_min / 60)::int, updated_by = p_actor
   where id = p_booking returning * into v_b;

  select name into v_room from public.rooms where id = p_room;
  if p_actor <> v_b.professional_id then
    perform public.notify(v_b.professional_id, 'Reserva alterada', v_room || ' · ' || public.fmt_local(p_starts), '/reservas');
  end if;
  return v_b;
exception when exclusion_violation then
  raise exception 'horario_indisponivel';
end $$;

-- ---------- RPC: cancelar (regra das 24h, configurável) ---------------
create function public.cancel_booking(p_booking uuid, p_reason text default null) returns public.bookings
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_b public.bookings; v_notice int;
begin
  if v_uid is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  select * into v_b from public.bookings where id = p_booking for update;
  if not found then raise exception 'reserva_nao_encontrada'; end if;
  if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
  if not public.is_admin() then
    if v_b.professional_id <> v_uid then raise exception 'sem_permissao'; end if;
    select cancellation_notice_hours into v_notice from public.settings;
    if v_b.starts_at - make_interval(hours => v_notice) < now() then
      raise exception 'cancelamento_fora_do_prazo';   -- o app oferece "solicitar cancelamento"
    end if;
  end if;
  return public._cancel_booking(p_booking, p_reason, v_uid);
end $$;

-- ---------- RPC: remanejar (somente administradora) --------------------
create function public.reschedule_booking(p_booking uuid, p_room uuid, p_starts timestamptz, p_ends timestamptz)
returns public.bookings
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'sem_permissao'; end if;
  return public._reschedule_booking(p_booking, p_room, p_starts, p_ends, auth.uid());
end $$;

-- ---------- RPC: profissional solicita cancelamento/alteração ----------
create function public.request_booking_change(
  p_booking uuid, p_type public.request_type, p_reason text default null,
  p_room uuid default null, p_starts timestamptz default null, p_ends timestamptz default null
) returns public.booking_requests
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_b public.bookings; v_req public.booking_requests; v_name text;
begin
  if v_uid is null or not public.current_user_active() then raise exception 'nao_autenticado'; end if;
  select * into v_b from public.bookings where id = p_booking;
  if not found or v_b.professional_id <> v_uid then raise exception 'sem_permissao'; end if;
  if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
  if v_b.starts_at <= now() then raise exception 'horario_no_passado'; end if;
  if p_type = 'change' then
    if p_starts is null or p_ends is null then raise exception 'duracao_invalida'; end if;
    perform public.validate_booking_window(coalesce(p_room, v_b.room_id), p_starts, p_ends);
  end if;
  begin
    insert into public.booking_requests (booking_id, requested_by, type, reason, desired_room_id, desired_starts_at, desired_ends_at)
    values (p_booking, v_uid, p_type, nullif(trim(p_reason), ''),
            case when p_type = 'change' then coalesce(p_room, v_b.room_id) end, p_starts, p_ends)
    returning * into v_req;
  exception when unique_violation then raise exception 'solicitacao_pendente';
  end;
  select full_name into v_name from public.profiles where id = v_uid;
  perform public.notify_admins(
    case p_type when 'cancel' then 'Pedido de cancelamento' else 'Pedido de alteração' end,
    v_name || ' · reserva de ' || public.fmt_local(v_b.starts_at), '/admin/solicitacoes');
  return v_req;
end $$;

-- ---------- RPC: administradora resolve solicitação --------------------
create function public.resolve_booking_request(p_request uuid, p_approve boolean, p_note text default null)
returns public.booking_requests
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_req public.booking_requests; v_b public.bookings;
begin
  if not public.is_admin() then raise exception 'sem_permissao'; end if;
  select * into v_req from public.booking_requests where id = p_request for update;
  if not found then raise exception 'solicitacao_nao_encontrada'; end if;
  if v_req.status <> 'pending' then raise exception 'solicitacao_ja_resolvida'; end if;
  select * into v_b from public.bookings where id = v_req.booking_id;

  if p_approve then
    if v_b.status <> 'confirmed' then raise exception 'reserva_ja_cancelada'; end if;
    if v_req.type = 'cancel' then
      perform public._cancel_booking(v_req.booking_id, coalesce(p_note, v_req.reason, 'Cancelamento solicitado pelo profissional'), v_uid);
    else
      perform public._reschedule_booking(v_req.booking_id, coalesce(v_req.desired_room_id, v_b.room_id),
                                          v_req.desired_starts_at, v_req.desired_ends_at, v_uid);
    end if;
  end if;

  update public.booking_requests
     set status = case when p_approve then 'approved'::public.request_status else 'rejected'::public.request_status end,
         resolved_by = v_uid, resolved_at = now(), resolution_note = nullif(trim(p_note), '')
   where id = p_request returning * into v_req;

  perform public.notify(v_req.requested_by,
    case when p_approve then 'Solicitação aprovada' else 'Solicitação recusada' end,
    coalesce(v_req.resolution_note, 'Reserva de ' || public.fmt_local(v_b.starts_at)), '/reservas');
  return v_req;
end $$;

-- ---------- RPC: registrar pagamento/estorno (somente administradora) --
create function public.record_payment(
  p_booking uuid, p_amount_cents int, p_kind public.payment_kind default 'payment',
  p_method public.payment_method default 'pix', p_paid_at timestamptz default now(), p_notes text default null
) returns public.payments
language plpgsql security definer set search_path = public as $$
declare v_b public.bookings; v_net int; v_row public.payments;
begin
  if not public.is_admin() then raise exception 'sem_permissao'; end if;
  if p_amount_cents is null or p_amount_cents <= 0 then raise exception 'valor_invalido'; end if;
  select * into v_b from public.bookings where id = p_booking for update;   -- serializa pagamentos da mesma reserva
  if not found then raise exception 'reserva_nao_encontrada'; end if;
  select coalesce(sum(case kind when 'payment' then amount_cents else -amount_cents end), 0) into v_net
    from public.payments where booking_id = p_booking;

  if p_kind = 'payment' then
    if v_b.status <> 'confirmed' then raise exception 'reserva_cancelada_sem_pagamento'; end if;
    if v_net + p_amount_cents > v_b.amount_cents then raise exception 'pagamento_excede_valor'; end if;
  elsif p_amount_cents > v_net then
    raise exception 'estorno_excede_pago';
  end if;

  insert into public.payments (booking_id, kind, amount_cents, method, paid_at, notes, created_by)
  values (p_booking, p_kind, p_amount_cents, p_method, coalesce(p_paid_at, now()), nullif(trim(p_notes), ''), auth.uid())
  returning * into v_row;

  perform public.notify(v_b.professional_id,
    case p_kind when 'payment' then 'Pagamento registrado' else 'Estorno registrado' end,
    'Reserva de ' || public.fmt_local(v_b.starts_at) || ' · R$ ' || replace(to_char(p_amount_cents / 100.0, 'FM999990.00'), '.', ','), '/pagamentos');
  return v_row;
end $$;

-- ---------- RPC: marcar notificações como lidas -------------------------
create function public.mark_notifications_read(p_ids uuid[] default null) returns void
language sql security definer set search_path = public as $$
  update public.notifications set read_at = now()
   where user_id = auth.uid() and read_at is null and (p_ids is null or id = any (p_ids));
$$;
-- =====================================================================
-- 0003 · PERMISSÕES (GRANTs) E POLÍTICAS RLS
-- Princípios:
--  * Nada é acessível por padrão (anon não acessa nada).
--  * Administradora: acesso total; profissional: apenas os próprios dados.
--  * Reservas, pagamentos e solicitações NÃO têm escrita direta: só via RPC.
--  * Histórico (audit_log) é somente leitura e só para a administradora.
-- =====================================================================

-- 1) Fecha tudo e reabre só o necessário
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke execute on all functions in schema public from public, anon, authenticated;
alter default privileges in schema public revoke execute on functions from public;

-- 2) Funções que o app pode chamar (todas validam auth.uid() internamente)
grant execute on function
  public.is_admin(), public.current_user_active(),
  public.estimate_booking(uuid, timestamptz, timestamptz, uuid),
  public.get_room_busy(uuid, timestamptz, timestamptz),
  public.create_booking(uuid, timestamptz, timestamptz, uuid, text),
  public.cancel_booking(uuid, text),
  public.reschedule_booking(uuid, uuid, timestamptz, timestamptz),
  public.request_booking_change(uuid, public.request_type, text, uuid, timestamptz, timestamptz),
  public.resolve_booking_request(uuid, boolean, text),
  public.record_payment(uuid, int, public.payment_kind, public.payment_method, timestamptz, text),
  public.mark_notifications_read(uuid[])
to authenticated;

-- 3) Privilégios de tabela (o RLS abaixo restringe as linhas)
grant select on public.settings, public.profiles, public.rooms, public.opening_hours, public.room_rates,
                public.professional_rates, public.bookings, public.payments, public.booking_requests,
                public.notifications, public.blocks, public.audit_log, public.notification_outbox,
                public.booking_financials
  to authenticated;
grant update on public.settings                to authenticated;
grant update (full_name, phone, registration_number, role, is_active) on public.profiles to authenticated;
grant insert, update, delete on public.rooms, public.opening_hours, public.blocks,
                                public.room_rates, public.professional_rates to authenticated;

-- 4) RLS
alter table public.settings            enable row level security;
alter table public.profiles            enable row level security;
alter table public.rooms               enable row level security;
alter table public.opening_hours       enable row level security;
alter table public.blocks              enable row level security;
alter table public.room_rates          enable row level security;
alter table public.professional_rates  enable row level security;
alter table public.bookings            enable row level security;
alter table public.payments            enable row level security;
alter table public.booking_requests    enable row level security;
alter table public.audit_log           enable row level security;
alter table public.notifications       enable row level security;
alter table public.notification_outbox enable row level security;

-- settings / rooms / opening_hours / room_rates: leitura para usuários ativos, escrita só admin
create policy settings_read  on public.settings for select to authenticated using (public.current_user_active());
create policy settings_admin on public.settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy rooms_read  on public.rooms for select to authenticated using (public.current_user_active());
create policy rooms_admin on public.rooms for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy hours_read  on public.opening_hours for select to authenticated using (public.current_user_active());
create policy hours_admin on public.opening_hours for all    to authenticated using (public.is_admin()) with check (public.is_admin());

create policy room_rates_read  on public.room_rates for select to authenticated using (public.current_user_active());
create policy room_rates_admin on public.room_rates for all    to authenticated using (public.is_admin()) with check (public.is_admin());

-- blocks: só admin (motivo é interno; profissionais veem apenas "indisponível" via get_room_busy)
create policy blocks_admin on public.blocks for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- professional_rates: o profissional vê somente o próprio preço especial
create policy prof_rates_read  on public.professional_rates for select to authenticated
  using (public.is_admin() or (professional_id = auth.uid() and public.current_user_active()));
create policy prof_rates_admin on public.professional_rates for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- profiles: cada um vê/edita o próprio (o trigger bloqueia role/is_active/e-mail); admin vê/edita todos
create policy profiles_read   on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

-- bookings / payments / booking_requests: somente leitura direta
create policy bookings_read on public.bookings for select to authenticated
  using (public.is_admin() or (professional_id = auth.uid() and public.current_user_active()));

create policy payments_read on public.payments for select to authenticated
  using (public.is_admin() or (public.current_user_active()
         and exists (select 1 from public.bookings b where b.id = booking_id and b.professional_id = auth.uid())));

create policy requests_read on public.booking_requests for select to authenticated
  using (public.is_admin() or (requested_by = auth.uid() and public.current_user_active()));

-- audit_log e outbox: só admin lê; ninguém escreve diretamente (triggers/RPCs são security definer)
create policy audit_read  on public.audit_log           for select to authenticated using (public.is_admin());
create policy outbox_read on public.notification_outbox for select to authenticated using (public.is_admin());

-- notifications: cada um lê as próprias (marcar como lida via RPC)
create policy notifications_read on public.notifications for select to authenticated using (user_id = auth.uid());
-- SEED: dados mínimos de configuração (não são dados fictícios de uso).
-- Seguro para rodar uma vez após as migrations. Ajuste horários e preços depois, no painel.
insert into public.settings (id) values (true) on conflict (id) do nothing;

insert into public.rooms (name, description, color, sort_order) values
  ('Sala 1', 'Sala 1', '#0f766e', 1),
  ('Sala 2', 'Sala 2', '#2563eb', 2)
on conflict (name) do nothing;

-- Horário inicial sugerido: segunda a sexta, 08:00–20:00 (edite no painel).
insert into public.opening_hours (room_id, weekday, opens_at, closes_at)
select r.id, d, time '08:00', time '20:00'
from public.rooms r, generate_series(1, 5) d
where not exists (select 1 from public.opening_hours oh where oh.room_id = r.id);

-- ATENÇÃO: nenhuma tarifa é criada. Defina o valor da hora de cada sala no painel
-- (Salas > Tarifas) antes de aceitar reservas; sem tarifa o sistema recusa a reserva.
