// Todo o sistema usa o horário de Brasília (UTC-3, sem horário de verão desde 2019).
const OFFSET_MIN = -180;
const pad = (n: number) => String(n).padStart(2, '0');

export const WEEKDAYS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
export const WEEKDAYS_SHORT = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];
export const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

const shift = (d: Date | string) => new Date((typeof d === 'string' ? new Date(d) : d).getTime() + OFFSET_MIN * 60000);
export const ymd = (d: Date | string) => shift(d).toISOString().slice(0, 10);
export const minutesOfDay = (d: Date | string) => { const s = shift(d); return s.getUTCHours() * 60 + s.getUTCMinutes(); };
export const hhmm = (min: number) => `${pad(Math.floor(min / 60))}:${pad(min % 60)}`;
export const fmtTime = (d: Date | string) => hhmm(minutesOfDay(d));
/** data local (YYYY-MM-DD) + minutos desde 00:00 → ISO em UTC */
export const toISO = (date: string, minutes: number) =>
  new Date(new Date(`${date}T00:00:00-03:00`).getTime() + minutes * 60000).toISOString();
/** valor de <input type="datetime-local"> (horário de Brasília) → ISO em UTC */
export const localInputToISO = (v: string) => new Date(`${v}:00-03:00`).toISOString();

export const todayYmd = () => ymd(new Date());
export function addDays(date: string, n: number) { const d = new Date(`${date}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }
export const weekday = (date: string) => new Date(`${date}T12:00:00Z`).getUTCDay();
export const startOfWeek = (date: string) => addDays(date, -((weekday(date) + 6) % 7)); // segunda-feira
export const monthStart = (date: string) => `${date.slice(0, 8)}01`;
export function addMonths(date: string, n: number) { const [y, m] = date.split('-').map(Number); return new Date(Date.UTC(y, m - 1 + n, 1)).toISOString().slice(0, 10); }
export function daysInMonth(date: string) { const [y, m] = date.split('-').map(Number); return new Date(Date.UTC(y, m, 0)).getUTCDate(); }

export const fmtDate = (date: string) => date.split('-').reverse().join('/');
export const fmtDateTime = (iso: string) => `${fmtDate(ymd(iso))} ${fmtTime(iso)}`;
export const fmtDateLong = (date: string) => { const [, m, d] = date.split('-').map(Number); return `${WEEKDAYS[weekday(date)]}, ${d} de ${MONTHS[m - 1]}`; };
export const monthLabel = (date: string) => { const [y, m] = date.split('-').map(Number); return `${MONTHS[m - 1]} de ${y}`; };
export const fmtDuration = (min: number) => { const h = Math.floor(min / 60), m = min % 60; return h && m ? `${h}h${pad(m)}` : h ? `${h}h` : `${m}min`; };
export const clampMonth = (v?: string) => (v && /^\d{4}-\d{2}$/.test(v) ? v : todayYmd().slice(0, 7));
